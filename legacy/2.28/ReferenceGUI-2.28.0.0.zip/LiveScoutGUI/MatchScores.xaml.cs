﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Sportradar.GUI.LiveScout.DataProvider.Common;
using Sportradar.GUI.LiveScout.DataProvider.Models;
using System.Collections.ObjectModel;
using Sportradar.GUI.LiveScout.Controls;
using Sportradar.GUI.LiveScout.Code;

namespace Sportradar.GUI.LiveScout.Forms
{
    /// <summary>
    /// Interaction logic for MatchScores.xaml
    /// </summary>
    public partial class MatchScores : Window
    {
        private readonly MatchModelControl _MatchModelControl = null;
        private readonly ObservableCollection<ScoreModel> _Scores = null;

        public MatchScores()
        {
            InitializeComponent();
        }

        public MatchScores(MatchModelControl matchModelControl, ObservableCollection<ScoreModel> scores)
            : this()
        {
            this._MatchModelControl = matchModelControl;
            this._Scores = scores;

            this.DataContext = this;
        }

        public GuiStrings GuiStrings { get { return GuiStrings.Instance; } }
        public ObservableCollection<ScoreModel> Scores { get { return this._Scores; } }

        private void MatchScoresClosing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            try
            {
                if (this._MatchModelControl != null)
                {
                    this._MatchModelControl.MatchScores = null;
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }
    }
}
