﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Sportradar.Demo.GUI.LiveScout.Forms
{
    /// <summary>
    /// Interaction logic for MatchStatisticsWindow.xaml
    /// </summary>
    public partial class MatchStatisticsWindow : ChildWindowBase
    {
        public MatchStatisticsWindow()
        {
            InitializeComponent();
        }

        protected override string FormTitlePrefix { get { return "Match Statistics"; } }
    }
}
