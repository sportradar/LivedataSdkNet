﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.Common;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Common;
using System;
using System.Windows.Data;

namespace Sportradar.Demo.GUI.LiveScout.Code
{
    public class LocalizedStringToTranslationConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            LocalizedString localizedString = value as LocalizedString;

            if (localizedString != null)
            {
                return localizedString.GetTranslation(GuiStrings.Instance.CurrentLanguage);
            }

            return value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
