﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Common;

namespace Sportradar.Demo.GUI.LiveScout.Code
{
    public static class Extensions
    {
        public static bool ShowQuestion(this string questionMsg)
        {
            var result = MessageBox.Show(questionMsg, GuiStrings.Instance.Question, MessageBoxButton.YesNo, MessageBoxImage.Question);
            return (result == MessageBoxResult.Yes);
        }

        public static bool ShowInfo(this string infoMsg)
        {
            MessageBox.Show(infoMsg, GuiStrings.Instance.Info, MessageBoxButton.OK, MessageBoxImage.Information);
            return true;
        }

        public static bool ShowError(this string errorMsg)
        {
            MessageBox.Show(errorMsg, GuiStrings.Instance.Error, MessageBoxButton.OK, MessageBoxImage.Error);
            return true;
        }

        public static bool ShowError(this Exception exc)
        {
            MessageBox.Show(
                string.Format(
                    "{0}{1}{1}{2}{1}{1}{3}",
                    GuiStrings.Instance.UnexpectedError,
                    Environment.NewLine,
                    exc.Message,
                    exc.StackTrace),
                GuiStrings.Instance.Error,
                MessageBoxButton.OK,
                MessageBoxImage.Error);

            return true;
        }
    }
}
