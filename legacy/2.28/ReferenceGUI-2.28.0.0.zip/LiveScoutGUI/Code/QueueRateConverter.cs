﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace Sportradar.Demo.GUI.LiveScout.Code
{
    public class QueueRateConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value != null)
            {
                if (value is double)
                {
                    return String.Format("{0:0.0}", (double)value * 60.0);
                }
                else if (value is double? && ((double?)value).HasValue)
                {
                    return String.Format("{0:0.0}", ((double?)value).Value * 60.0);
                }
            }

            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
