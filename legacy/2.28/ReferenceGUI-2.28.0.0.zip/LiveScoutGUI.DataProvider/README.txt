﻿
This is the backend project of LiveScout GUI. 

Class that makes use of SDK is ChangeTracker. It subscribes to LiveOdds events
and wraps method calls to SDK for calls through GUI.
When SDK triggers events, event handlers in ChangeTracker log event and pass
event arguments to ReferencesMerger. Here we merge data depending on needs and
then store them in References. 

Model classes used for data storing are mostly 1:1 wrappers around SDK entities. 
They all extend NotifyPropertyChanged which implements INotifyPropertyChanged.
This enables us to notify data containers so GUI is updated accordingly.
Some classes also implement IComparable and IEquatable which enable us
to sort items and display them in right order. 