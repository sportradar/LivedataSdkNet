﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.Common;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Common;
using Merged::Sportradar.SDK.Services.QueueStats;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Sportradar.Demo.GUI.LiveScout.DataProvider.Models
{
    public class DispatcherQueueStatsModel : NotifyPropertyChanged
    {
        public DispatcherQueueStatsModel()
        {
        }

        public DispatcherQueueStatsModel(IList<ClientQueueStats> stats)
        {
            this.Load(stats);
        }

        public void Load(IList<ClientQueueStats> stats)
        {
            if (stats == null)
            {
                throw new ArgumentNullException("stats");
            }

            foreach(var queueStats in stats.Where(s => stats != null))
            {
                var foundQueueStats = this._Queues.FirstOrDefault(s => s.QueueName == queueStats.QueueName);
                if (foundQueueStats == null)
                {
                    this._Queues.Add(new CollectedQueueStatsModel(queueStats));
                }
                else
                {
                    foundQueueStats.Load(queueStats);
                }
            }
        }

        private readonly ObservableCollection<CollectedQueueStatsModel> _Queues = new ObservableCollection<CollectedQueueStatsModel>();

        public ObservableCollection<CollectedQueueStatsModel> Queues
        {
            get { return this._Queues; }
        }
    }
}
