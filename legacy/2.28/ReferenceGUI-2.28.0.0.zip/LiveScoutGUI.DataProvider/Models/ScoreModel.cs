﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.FeedProviders.Common;
using Merged::Sportradar.SDK.FeedProviders.LiveScout;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Common;
using System;

namespace Sportradar.Demo.GUI.LiveScout.DataProvider.Models
{
    public class ScoreModel : NotifyPropertyChanged, IComparable<ScoreModel>, IEquatable<ScoreModel>
    {
        public ScoreModel(String scoreType, HomeAway<double> score)
        {
            this.Load(scoreType, score);
        }

        public void Load(String scoreType, HomeAway<double> score)
        {
            if (score == null)
            {
                throw new ArgumentNullException("score");
            }

            this.ScoreType = scoreType;
            this.Score = score;
        }

        private String _ScoreType = "UNDEFINED";
        private HomeAway<double> _Score = null;

        public String ScoreType
        {
            get { return this.GetProperty(ref this._ScoreType); }
            private set { this.SetProperty(ref this._ScoreType, value, "ScoreType"); }
        }
        public HomeAway<double> Score
        {
            get { return this.GetProperty<HomeAway<double>>(ref this._Score); }
            private set { this.SetProperty<HomeAway<double>>(ref this._Score, value, "Score"); }
        }

        public int CompareTo(ScoreModel other)
        {
            if (other == null)
            {
                return -1;
            }

            return this.ScoreType.CompareTo(other.ScoreType);
        }

        public bool Equals(ScoreModel other)
        {
            return (this.CompareTo(other) == 0);
        }
    }
}