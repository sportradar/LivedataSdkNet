﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Common;

namespace Sportradar.Demo.GUI.LiveScout.DataProvider.Models
{
    public class NotificationModel : NotifyPropertyChanged, IComparable<NotificationModel>, IEquatable<NotificationModel>
    {
        public NotificationModel(DateTime localTimestamp, DateTime? serverTimestamp, string msg)
        {
            this.LocalTimestamp = localTimestamp;
            this.ServerTimestamp = serverTimestamp;
            this.Message = msg;
        }

        private DateTime _LocalTimestamp = DateTime.MinValue;
        private DateTime? _ServerTimestamp = null;
        private string _Message = null;

        public DateTime LocalTimestamp
        {
            get { return this.GetProperty(ref this._LocalTimestamp); }
            private set { this.SetProperty(ref this._LocalTimestamp, value, "LocalTimestamp"); }
        }
        public DateTime? ServerTimestamp
        {
            get { return this.GetProperty(ref this._ServerTimestamp); }
            private set { this.SetProperty(ref this._ServerTimestamp, value, "ServerTimestamp"); }
        }
        public string Message
        {
            get { return this.GetProperty(ref this._Message); }
            private set { this.SetProperty(ref this._Message, value, "Message"); }
        }

        public int CompareTo(NotificationModel other)
        {
            if(other == null)
            {
                return -1;
            }

            int result = other.LocalTimestamp.CompareTo(this.LocalTimestamp);
            if (result != 0)
            {
                return result;
            }
            result = other.ServerTimestamp.CompareExt(this.ServerTimestamp);
            if (result != 0)
            {
                return result;
            }

            return this.Message.CompareExt(other.Message);
        }

        public bool Equals(NotificationModel other)
        {
            return (this.CompareTo(other) == 0);
        }
    }
}
