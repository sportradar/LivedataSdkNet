﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace Sportradar.Demo.GUI.LiveScout.DataProvider.Common
{
    public abstract class NotifyPropertyChanged : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private readonly Dictionary<string, ChangeTimestamp> _LastChanges = new Dictionary<string, ChangeTimestamp>();
        private readonly Dictionary<string, bool> _IsChangedTracker = new Dictionary<string, bool>();

        protected T GetProperty<T>(ref T field)
        {
            return field;
        }
        protected T GetProperty<T>(Func<T> get)
        {
            return get();
        }
        protected bool SetProperty<T>(ref T field, T value, string propName, params string[] dependantPropNames)
        {
            bool result = false;

            if (!object.Equals(field, value))
            {
                field = value;
                this.SetLastChange(propName);
                this.OnPropertyChanged(propName);
                if ((dependantPropNames != null) && (dependantPropNames.Length > 0))
                {
                    this.OnPropertyChanged(dependantPropNames);
                }

                result = true;
            }

            this.SetIsChanged(propName, result);
            if (!result)
            {
                this.OnPropertyChanged(propName);
            }

            return result;
        }
        protected bool SetProperty<T>(Action<T> set, Func<T> get, T value, string propName, params string[] dependantPropNames)
        {
            bool result = false;

            T current = get();
            if (!object.Equals(current, value))
            {
                set(value);
                this.SetLastChange(propName);
                this.OnPropertyChanged(propName);
                if ((dependantPropNames != null) && (dependantPropNames.Length > 0))
                {
                    this.OnPropertyChanged(dependantPropNames);
                }

                result = true;
            }

            this.SetIsChanged(propName, result);
            if (!result)
            {
                this.OnPropertyChanged(propName);
            }

            return result;
        }

        private void SetLastChange(string propName)
        {
            if (!this._LastChanges.ContainsKey(propName))
            {
                this._LastChanges.Add(propName, new ChangeTimestamp());
            }

            this._LastChanges[propName].SetLastChange(DateTime.Now);
        }

        private void SetIsChanged(string propName, bool value)
        {
            if (this._IsChangedTracker.ContainsKey(propName))
            {
                this._IsChangedTracker[propName] = value;
            }
            else
            {
                this._IsChangedTracker.Add(propName, value);
            }
        }

        public bool GetIsChanged(string propName)
        {
            if (this._IsChangedTracker.ContainsKey(propName))
            {
                return this._IsChangedTracker[propName];
            }

            return false;
        }

        public DateTime GetLastChange(string propName)
        {
            if (this._LastChanges.ContainsKey(propName))
            {
                return this._LastChanges[propName].CurrentChange;
            }

            return DateTime.MinValue;
        }

        protected void OnPropertyChanged(params string[] propNames)
        {
            var propertyChanged = this.PropertyChanged;
            if (propertyChanged != null)
            {
                foreach (var propName in propNames)
                {
                    if (propName == null)
                    {
                        continue;
                    }

                    propertyChanged(this, new PropertyChangedEventArgs(propName));
                }
            }
        }
    }
}