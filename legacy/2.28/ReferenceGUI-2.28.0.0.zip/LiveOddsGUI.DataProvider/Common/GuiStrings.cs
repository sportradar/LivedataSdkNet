﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.Common;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Common
{
    /// <summary>
    /// Stores translations for different text elements of GUI
    /// </summary>
    public class GuiStrings : NotifyPropertyChanged
    {
        private readonly static Lazy<GuiStrings> _Instance = new Lazy<GuiStrings>(() => new GuiStrings(), true);

        public static GuiStrings Instance { get { return _Instance.Value; } }

        private GuiStrings()
        {
            this._Strings.Add("Question", new LocalizedString("Question"));
            this._Strings.Add("Info", new LocalizedString("Info"));
            this._Strings.Add("Error", new LocalizedString("Error"));
            this._Strings.Add("UnexpectedError", new LocalizedString("Unexpected Error"));
            this._Strings.Add("Refresh", new LocalizedString("Refresh"));
            this._Strings.Add("AvailableMatches", new LocalizedString("Available Matches"));
            this._Strings.Add("Subscribe", new LocalizedString("Subscribe"));
            this._Strings.Add("Unsubscribe", new LocalizedString("Unsubscribe"));
            this._Strings.Add("ViewOdds", new LocalizedString("Live Odds"));
            this._Strings.Add("Book", new LocalizedString("Book"));
            this._Strings.Add("Delete", new LocalizedString("Delete"));
            this._Strings.Add("ClearAll", new LocalizedString("Clear all"));
            this._Strings.Add("ClearAllInfos", new LocalizedString("Clear all infos"));
            this._Strings.Add("ViewScoresAndCards", new LocalizedString("Scores & Cards"));
            this._Strings.Add("ActivateBettype", new LocalizedString("Activate"));
            this._Strings.Add("DeactivateBettype", new LocalizedString("Deactivate"));
            this._Strings.Add("ViewMatchNotifications", new LocalizedString("Events"));
            this._Strings.Add("ViewNotificationDetails", new LocalizedString("Details"));
            this._Strings.Add("ViewMatchHeaderDetails", new LocalizedString("Match header"));
            this._Strings.Add("RefreshInfo", new LocalizedString("Refresh"));
            this._Strings.Add("ViewMatchStatus", new LocalizedString("Status"));
            this._Strings.Add("OddsSettings", new LocalizedString("OddsSettings"));
            this._Strings.Add("DispatcherQueueStats", new LocalizedString("Queues statistics"));
        }

        private readonly Dictionary<string, LocalizedString> _Strings = new Dictionary<string, LocalizedString>();

        private string _CurrentLanguage = "sl";

        public string CurrentLanguage
        {
            get { return this._CurrentLanguage; }
            set
            {
                if (this._CurrentLanguage != value)
                {
                    this._CurrentLanguage = value;
                    this.OnPropertyChanged("CurrentLanguage");
                    this.OnPropertyChanged(this._Strings.Keys.ToArray());
                }
            }
        }

        public string Question { get { return this._Strings["Question"].GetTranslation(this._CurrentLanguage); } }

        public string Info { get { return this._Strings["Info"].GetTranslation(this._CurrentLanguage); } }

        public string Error { get { return this._Strings["Error"].GetTranslation(this._CurrentLanguage); } }

        public string UnexpectedError { get { return this._Strings["UnexpectedError"].GetTranslation(this._CurrentLanguage); } }

        public string Refresh { get { return this._Strings["Refresh"].GetTranslation(this._CurrentLanguage); } }

        public string AvailableMatches { get { return this._Strings["AvailableMatches"].GetTranslation(this._CurrentLanguage); } }

        public string Subscribe { get { return this._Strings["Subscribe"].GetTranslation(this._CurrentLanguage); } }

        public string Unsubscribe { get { return this._Strings["Unsubscribe"].GetTranslation(this._CurrentLanguage); } }

        public string ViewOdds { get { return this._Strings["ViewOdds"].GetTranslation(this._CurrentLanguage); } }

        public string OddsSettings { get { return this._Strings["OddsSettings"].GetTranslation(this._CurrentLanguage); } }

        public string Book { get { return this._Strings["Book"].GetTranslation(this._CurrentLanguage); } }

        public string Delete { get { return this._Strings["Delete"].GetTranslation(this._CurrentLanguage); } }

        public string ClearAll { get { return this._Strings["ClearAll"].GetTranslation(this._CurrentLanguage); } }

        public string ClearAllInfos { get { return this._Strings["ClearAllInfos"].GetTranslation(this._CurrentLanguage); } }

        public string ViewScoresAndCards { get { return this._Strings["ViewScoresAndCards"].GetTranslation(this._CurrentLanguage); } }

        public string ActivateBettype { get { return this._Strings["ActivateBettype"].GetTranslation(this._CurrentLanguage); } }

        public string DeactivateBettype { get { return this._Strings["DeactivateBettype"].GetTranslation(this._CurrentLanguage); } }

        public string ViewMatchNotifications { get { return this._Strings["ViewMatchNotifications"].GetTranslation(this._CurrentLanguage); } }

        public string ViewNotificationDetails { get { return this._Strings["ViewNotificationDetails"].GetTranslation(this._CurrentLanguage); } }

        public string ViewMatchHeaderDetails { get { return this._Strings["ViewMatchHeaderDetails"].GetTranslation(this._CurrentLanguage); } }

        public string RefreshInfo { get { return this._Strings["RefreshInfo"].GetTranslation(this._CurrentLanguage); } }

        public string ViewMatchStatus { get { return this._Strings["ViewMatchStatus"].GetTranslation(this._CurrentLanguage); } }

        public string DispatcherQueueStats { get { return this._Strings["DispatcherQueueStats"].GetTranslation(this._CurrentLanguage); } }
    }
}
