/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.Common;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Common
{
    public class FilterNameCombo
    {
        public LocalizedString Sport { get; set; }
        public LocalizedString Category { get; set; }
        public LocalizedString Tournament { get; set; }

        public FilterNameCombo(LocalizedString sport, LocalizedString category, LocalizedString tournament)
        {
            Sport = sport;
            Category = category;
            Tournament = tournament;
        }
    }
}
