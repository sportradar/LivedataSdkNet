﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Collections.ObjectModel;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Common
{
    public static class HelperClass
    {
        public static Grid PropertiesGridFromObject(object obj, int numberOfColumns)
        {
            Grid grid = new Grid();
            FillGridWithObjectProperties(obj, grid, numberOfColumns);
            return grid;
        }


        public static void FillGridWithObjectProperties(object obj, Grid grid, int numberOfColumns)
        {
            PropertyInfo[] properties = obj
                   .GetType()
                   .GetProperties(BindingFlags.Public | BindingFlags.Instance)
                   .Where(x => x.GetValue(obj, null) != null && !typeof(IEnumerable).IsAssignableFrom(x.PropertyType))
                   .ToArray();
            var properties_to_strings = new Collection<string>();
            foreach (PropertyInfo t in properties)
            {
                properties_to_strings.Add(String.Format("{0} : {1}", t.Name, t.GetValue(obj, null)));
            }
            BuildGridFromStringArray(properties_to_strings, grid, numberOfColumns);
        }


        public static void BuildGridFromStringArray(IList<string> content, Grid grid, int numberOfColumns)
        {
            int cellCount = content.Count;
            int numRows = (int)Math.Floor((double)(cellCount / numberOfColumns)) + 1;

            for (int i = 0; i < numberOfColumns; ++i)
                grid.ColumnDefinitions.Add(new ColumnDefinition());
            for (int i = 0; i < numRows; ++i)
                grid.RowDefinitions.Add(new RowDefinition());

            foreach (var g in grid.RowDefinitions)
            {
                g.Height = GridLength.Auto;
            }

            foreach (var g in grid.ColumnDefinitions)
            {
                g.Width = GridLength.Auto;
            }

            for (int i = 0; i < cellCount; ++i)
            {
                int idx = grid.Children.Add(new Label());
                Label x = grid.Children[idx] as Label;

                x.Content = content[i];
                x.SetValue(Grid.RowProperty, i / numberOfColumns);
                x.SetValue(Grid.ColumnProperty, i % numberOfColumns);
            }
        }
    }
}
