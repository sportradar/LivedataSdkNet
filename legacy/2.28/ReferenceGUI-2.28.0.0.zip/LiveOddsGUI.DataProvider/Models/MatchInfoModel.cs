﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.Common;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Models
{
    public class MatchInfoModel : NotifyPropertyChanged, IComparable<MatchInfoModel>, IEquatable<MatchInfoModel>
    {
        public MatchInfoModel(long matchId)
        {
            this.MatchId = matchId;
        }

        public MatchInfoModel(MatchInfo matchInfo)
        {
            this.Load(matchInfo);
        }

        public void Load(MatchInfo matchInfo)
        {
            if (matchInfo == null)
            {
                throw new ArgumentNullException("matchInfo");
            }

            this.DateOfMatch = (matchInfo.DateOfMatch == null) ? this.DateOfMatch : matchInfo.DateOfMatch;
            this.HomeTeamId = (matchInfo.HomeTeam == null || matchInfo.HomeTeam.Id == null || matchInfo.HomeTeam.Id.Value == 0) ? this.HomeTeamId : matchInfo.HomeTeam.Id.Value;
            this.HomeTeamName = (matchInfo.HomeTeam == null || matchInfo.HomeTeam.Name == null) ? this.HomeTeamName : matchInfo.HomeTeam.Name;
            this.AwayTeamId = (matchInfo.AwayTeam == null || matchInfo.AwayTeam.Id == null || matchInfo.AwayTeam.Id.Value == 0) ? this.AwayTeamId : matchInfo.AwayTeam.Id.Value;
            this.AwayTeamName = (matchInfo.AwayTeam == null || matchInfo.AwayTeam.Name == null) ? this.AwayTeamName : matchInfo.AwayTeam.Name;
            this.SportId = (matchInfo.Sport == null || matchInfo.Sport.Id == null || matchInfo.Sport.Id.Value == 0) ? this.SportId : matchInfo.Sport.Id.Value;
            this.SportName = (matchInfo.Sport == null || matchInfo.Sport.Name == null) ? this.SportName : matchInfo.Sport.Name;
            this.CategoryId = (matchInfo.Category == null || matchInfo.Category.Id == null || matchInfo.Category.Id.Value == 0) ? this.CategoryId : matchInfo.Category.Id.Value;
            this.CategoryName = (matchInfo.Category == null || matchInfo.Category.Name == null) ? this.CategoryName : matchInfo.Category.Name;
            this.TournamentId = (matchInfo.Tournament == null || matchInfo.Tournament.Id == null || matchInfo.Tournament.Id.Value == 0) ? this.TournamentId : matchInfo.Tournament.Id.Value;
            this.TournamentName = (matchInfo.Tournament == null || matchInfo.Tournament.Name == null) ? this.TournamentName : matchInfo.Tournament.Name;

            this.TvChannels.Clear();
            foreach (var tvChannel in matchInfo.TvChannels ?? new List<string>())
            {
                this.TvChannels.Add(tvChannel);
            }
            this.ExtraInfo.Clear();
            foreach (var extraInfo in matchInfo.ExtraInfo ?? new List<ExtraMatchInfo>())
            {
                this.ExtraInfo.Add(new InfoModel(extraInfo));
            }
        }

        private long _AwayTeamId = 0;
        private LocalizedString _AwayTeamName = null;
        private long _CategoryId = 0;
        private LocalizedString _CategoryName = null;
        private DateTime? _DateOfMatch = null;
        private long _HomeTeamId = 0;
        private LocalizedString _HomeTeamName = null;
        private long? _MatchId;
        private long _SportId = 0;
        private LocalizedString _SportName = null;
        private long _TournamentId = 0;
        private LocalizedString _TournamentName = null;
        private ObservableCollection<InfoModel> _ExtraInfo = new ObservableCollection<InfoModel>();
        private ObservableCollection<string> _TvChannels = new ObservableCollection<string>();

        public long AwayTeamId
        {
            get { return this.GetProperty(ref this._AwayTeamId); }
            private set { this.SetProperty(ref this._AwayTeamId, value, "AwayTeamId"); }
        }
        public LocalizedString AwayTeamName
        {
            get { return this.GetProperty(ref this._AwayTeamName); }
            private set { this.SetProperty(ref this._AwayTeamName, value, "AwayTeamName"); }
        }
        public long CategoryId
        {
            get { return this.GetProperty(ref this._CategoryId); }
            private set { this.SetProperty(ref this._CategoryId, value, "CategoryId"); }
        }
        public LocalizedString CategoryName
        {
            get { return this.GetProperty(ref this._CategoryName); }
            private set { this.SetProperty(ref this._CategoryName, value, "CategoryName"); }
        }
        public DateTime? DateOfMatch
        {
            get { return this.GetProperty(ref this._DateOfMatch); }
            private set { this.SetProperty(ref this._DateOfMatch, value, "DateOfMatch"); }
        }
        public ObservableCollection<InfoModel> ExtraInfo
        {
            get { return this.GetProperty<ObservableCollection<InfoModel>>(ref this._ExtraInfo); }
        }
        public long HomeTeamId
        {
            get { return this.GetProperty(ref this._HomeTeamId); }
            private set { this.SetProperty(ref this._HomeTeamId, value, "HomeTeamId"); }
        }
        public LocalizedString HomeTeamName
        {
            get { return this.GetProperty(ref this._HomeTeamName); }
            private set { this.SetProperty(ref this._HomeTeamName, value, "HomeTeamName"); }
        }
        public long? MatchId
        {
            get { return this.GetProperty(ref this._MatchId); }
            private set { this.SetProperty(ref this._MatchId, value, "MatchId"); }
        }
        public long SportId
        {
            get { return this.GetProperty(ref this._SportId); }
            private set { this.SetProperty(ref this._SportId, value, "SportId"); }
        }
        public LocalizedString SportName
        {
            get { return this.GetProperty(ref this._SportName); }
            private set { this.SetProperty(ref this._SportName, value, "SportName"); }
        }
        public long TournamentId
        {
            get { return this.GetProperty(ref this._TournamentId); }
            private set { this.SetProperty(ref this._TournamentId, value, "TournamentId"); }
        }
        public LocalizedString TournamentName
        {
            get { return this.GetProperty(ref this._TournamentName); }
            private set { this.SetProperty(ref this._TournamentName, value, "TournamentName"); }
        }
        public ObservableCollection<string> TvChannels
        {
            get { return this.GetProperty<ObservableCollection<string>>(ref this._TvChannels); }
        }



        public int CompareTo(MatchInfoModel other)
        {
            return -1;
        }

        public bool Equals(MatchInfoModel other)
        {
            return (this.CompareTo(other) == 0);
        }
    }
}