﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.Common;
using System;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Models
{
    public class OddsFieldValueModel : NotifyPropertyChanged, IComparable<OddsFieldValueModel>, IEquatable<OddsFieldValueModel>
    {
        public OddsFieldValueModel(string key, EventOddsField oddsFieldValue)
        {
            this._Key = key;
            this.Load(oddsFieldValue);
        }

        public void Load(EventOddsField oddsFieldValue)
        {
            if (oddsFieldValue == null)
            {
                throw new ArgumentNullException("oddsFieldValue");
            }

            this.Active = oddsFieldValue.Active;
            this.Outcome = (oddsFieldValue.Outcome == null) ? this.Outcome : oddsFieldValue.Outcome;
            this.Type = (oddsFieldValue.Type == null) ? this.Type : oddsFieldValue.Type.International;
            this.Value = (oddsFieldValue.Value == null) ? this.Value : oddsFieldValue.Value;
            this.VoidFactor = (oddsFieldValue.VoidFactor == null) ? this.VoidFactor : oddsFieldValue.VoidFactor;
        }

        private readonly string _Key = null;
        private bool _Active = false;
        private bool? _Outcome = null;
        private string _Type = null;
        private decimal? _Value = null;
        private double? _VoidFactor = null;

        public string Key
        {
            get { return this._Key; }
        }
        public bool Active
        {
            get { return this.GetProperty(ref this._Active); }
            private set { this.SetProperty(ref this._Active, value, "Active"); }
        }
        public bool? Outcome
        {
            get { return this.GetProperty(ref this._Outcome); }
            private set { this.SetProperty(ref this._Outcome, value, "Outcome"); }
        }
        public string Type
        {
            get { return this.GetProperty(ref this._Type); }
            private set { this.SetProperty(ref this._Type, value, "Type"); }
        }
        public decimal? Value
        {
            get { return this.GetProperty(ref this._Value); }
            private set { this.SetProperty(ref this._Value, value, "Value"); }
        }
        public double? VoidFactor
        {
            get { return this.GetProperty(ref this._VoidFactor); }
            private set { this.SetProperty(ref this._VoidFactor, value, "VoidFactor"); }
        }

        public bool Equals(OddsFieldValueModel other)
        {
            return (this.CompareTo(other) == 0);
        }

        public int CompareTo(OddsFieldValueModel other)
        {
            if (other == null)
            {
                return -1;
            }

            int result = this.Key.CompareExt(other.Key);
            if (result != 0)
            {
                return result;
            }

            return this.Type.CompareExt(other.Type);
        }
    }
}
