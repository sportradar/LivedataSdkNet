﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Models.Base
{
    public abstract class EntityBaseModel : NotifyPropertyChanged
    {
        protected void Load(EntityBase entityBase)
        {
            if (entityBase == null)
            {
                throw new ArgumentNullException("entityBase");
            }

            foreach (var entry in entityBase.AdditionalData ?? new Dictionary<string, string>())
            {
                var additionalDataModel = this.AdditionalData.SingleOrDefault(ad => ad.Key == entry.Key);
                if (additionalDataModel == null)
                {
                    this.AdditionalData.Add(new AdditionalDataModel(entry.Key, entry.Value));
                }
                else
                {
                    additionalDataModel.Load(entry.Value);
                }
            }
        }

        private ObservableCollection<AdditionalDataModel> _AdditionalData = new ObservableCollection<AdditionalDataModel>();

        public ObservableCollection<AdditionalDataModel> AdditionalData
        {
            get { return this.GetProperty<ObservableCollection<AdditionalDataModel>>(ref this._AdditionalData); }
        }
    }
}
