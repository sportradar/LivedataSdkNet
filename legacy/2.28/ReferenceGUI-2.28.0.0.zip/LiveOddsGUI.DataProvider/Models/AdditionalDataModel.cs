﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Models
{
    public class AdditionalDataModel : NotifyPropertyChanged, IComparable<AdditionalDataModel>, IEquatable<AdditionalDataModel>
    {
        public AdditionalDataModel(string key, string value)
        {
            this._Key = key;
            this.Load(value);
        }

        public void Load(string value)
        {
            this.Value = (value == null) ? this.Value : value;
        }

        private readonly string _Key = null;
        private string _Value = null;

        public string Key
        {
            get { return this._Key; }
        }
        public string Value
        {
            get { return this.GetProperty(ref this._Value); }
            private set { this.SetProperty(ref this._Value, value, "Value"); }
        }

        public bool Equals(AdditionalDataModel other)
        {
            return (this.CompareTo(other) == 0);
        }

        public int CompareTo(AdditionalDataModel other)
        {
            if (other == null)
            {
                return -1;
            }

            return string.Compare(this.Value, other.Value);
        }
    }
}