﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Enums;
using System;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Models
{
    public class NotificationDisplayModel : NotifyPropertyChanged, IComparable<NotificationDisplayModel>, IEquatable<NotificationDisplayModel>
    {
        private NotificationSeverity _NotificationSeverity = NotificationSeverity.Unknown;
        private Guid _Id = Guid.Empty;
        private EventArgs _eventArgs;
        private long? _matchid;
        private NotificationType _notificationType;
        private string _Message;
        private DateTime _LocalTimestamp = DateTime.MinValue;


        public NotificationDisplayModel(
                    NotificationType notificationType,
                    NotificationSeverity notificationSeverity,
                    EventArgs eventArgs,
                    string message = null,
                    long? matchid = null)
        {
            this._notificationType = notificationType;
            this.NotificationSeverity = notificationSeverity;
            this.Id = Guid.NewGuid();
            _eventArgs = eventArgs;
            _matchid = matchid;
            _Message = message;
            _LocalTimestamp = DateTime.Now;
        }

        public NotificationType NotificationType
        {
            get { return this.GetProperty(ref this._notificationType); }
            private set { this.SetProperty(ref this._notificationType, value, "NotificationType"); }
        }
        public NotificationSeverity NotificationSeverity
        {
            get { return this.GetProperty(ref this._NotificationSeverity); }
            private set { this.SetProperty(ref this._NotificationSeverity, value, "NotificationSeverity"); }
        }

        public string Message
        {
            get { return this.GetProperty(ref this._Message); }
            private set { this.SetProperty(ref this._Message, value, "Message"); }
        }


        public EventArgs EventArgs
        {
            get { return this.GetProperty(ref this._eventArgs); }
            private set { this.SetProperty(ref this._eventArgs, value, "EventArgs"); }
        }

        public DateTime LocalTimestamp
        {
            get { return this.GetProperty(ref this._LocalTimestamp); }
            private set { this.SetProperty(ref this._LocalTimestamp, value, "LocalTimestamp"); }
        }

        public long? MatchId
        {
            get { return this.GetProperty(ref this._matchid); }
            private set { this.SetProperty(ref this._matchid, value, "MatchId"); }
        }

        public Guid Id
        {
            get { return this.GetProperty(ref this._Id); }
            private set { this.SetProperty(ref this._Id, value, "Id"); }
        }

        public bool Equals(NotificationDisplayModel other)
        {
            return (this.CompareTo(other) == 0);
        }

        public int CompareTo(NotificationDisplayModel other)
        {
            if (other == null)
            {
                return -1;
            }

            int result = this.Id.CompareTo(other.Id);
            if (result == 0)
            {
                // equal
                return result;
            }

            // reverse order (switched this and other instance) to
            // achieve desc ordering
            result = other.LocalTimestamp.CompareTo(this.LocalTimestamp);
            if (result != 0)
            {
                return result;
            }
            result = this.NotificationSeverity.CompareTo(other.NotificationSeverity);
            if (result != 0)
            {
                return result;
            }
            if (result != 0)
            {
                return result;
            }

            return this.Message.CompareExt(other.Message);
        }
    }
}
