﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.Common;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using System;
using System.Collections.ObjectModel;
using System.Linq;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Models
{
    public class ScoreCardSummaryModel : Base.OddsEntityBaseModel, IComparable<ScoreCardSummaryModel>, IEquatable<ScoreCardSummaryModel>
    {
        public ScoreCardSummaryModel(long matchId)
        {
        }

        public ScoreCardSummaryModel(ScoreCardSummary scoreCardSummary)
        {
            this.Load(scoreCardSummary);
        }

        public void Load(ScoreCardSummary scoreCardSummary)
        {
            if (scoreCardSummary == null)
            {
                throw new ArgumentNullException("scoreCardSummary");
            }

            this.Load(scoreCardSummary as OddsEntityBase);

            this.MatchHeader = (MatchHeader)scoreCardSummary.EventHeader;

            if (scoreCardSummary.CardsByTime != null && scoreCardSummary.CardsByTime.Count > 0)
            {
                foreach (var cardSummary in scoreCardSummary.CardsByTime)
                {
                    if (cardSummary == null)
                    {
                        continue;
                    }

                    CardEntryModel model = new CardEntryModel(cardSummary);

                    var oldModel = this.CardSummaryByTime.FirstOrDefault(om => om.Equals(model));
                    if (oldModel != null)
                    {
                        oldModel.Load(cardSummary);
                    }
                    else
                    {
                        this.CardSummaryByTime.InsertInOrder(model);
                    }
                }
            }

            if (scoreCardSummary.ScoresByTime != null && scoreCardSummary.ScoresByTime.Count > 0)
            {
                foreach (var scoreSummary in scoreCardSummary.ScoresByTime)
                {
                    if (scoreSummary == null)
                    {
                        continue;
                    }

                    ScoreEntryModel model = new ScoreEntryModel(scoreSummary);

                    var oldModel = this.ScoreSummaryByTime.FirstOrDefault(om => om.Equals(model));
                    if (oldModel != null)
                    {
                        oldModel.Load(scoreSummary);
                    }
                    else
                    {
                        this.ScoreSummaryByTime.InsertInOrder(model);
                    }
                }
            }
        }

        private MatchHeader _MatchHeader = null;
        private ObservableCollection<CardEntryModel> _CardSummaryByTime = new ObservableCollection<CardEntryModel>();
        private ObservableCollection<ScoreEntryModel> _ScoreSummaryByTime = new ObservableCollection<ScoreEntryModel>();

        public ObservableCollection<CardEntryModel> CardSummaryByTime
        {
            get { return this.GetProperty<ObservableCollection<CardEntryModel>>(ref this._CardSummaryByTime); }
        }
        public MatchHeader MatchHeader
        {
            get { return this.GetProperty(ref this._MatchHeader); }
            private set { this.SetProperty(ref this._MatchHeader, value, "MatchHeader"); }
        }
        public ObservableCollection<ScoreEntryModel> ScoreSummaryByTime
        {
            get { return this.GetProperty<ObservableCollection<ScoreEntryModel>>(ref this._ScoreSummaryByTime); }
        }

        public bool Equals(ScoreCardSummaryModel other)
        {
            return (this.CompareTo(other) == 0);
        }

        public int CompareTo(ScoreCardSummaryModel other)
        {
            throw new NotImplementedException();
        }
    }
}