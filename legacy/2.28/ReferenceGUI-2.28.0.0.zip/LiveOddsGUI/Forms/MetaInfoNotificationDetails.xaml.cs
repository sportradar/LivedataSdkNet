﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.Common;
using Sportradar.Demo.GUI.LiveOdds.Code;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;

namespace Sportradar.Demo.GUI.LiveOdds.Forms
{
    /// <summary>
    /// Interaction logic for MetaInfoNotificationDetails.xaml
    /// </summary>
    public partial class MetaInfoNotificationDetails : Window
    {
        private readonly MatchHeaderInfo[] _matchHeaderInfos;


        public MetaInfoNotificationDetails(DateTime timeOfEvent, MetaInfoEventArgs eventArgs)
        {
            InitializeComponent();
            this._matchHeaderInfos = ((LiveOddsMetaData)eventArgs.MetaInfo.MetaInfoDataContainer).MatchHeaderInfos.OrderBy(x => x.MatchHeader.Id).ToArray();
            this.TimeOfEvent = timeOfEvent.ToString("dd/MM/yyyy H:mm:ss");
            this.DataContext = this;
        }

        public ObservableCollection<MatchHeaderInfo> MatchHeaderInfos
        {
            get
            {
                if (_matchHeaderInfos == null) return null;
                return new ObservableCollection<MatchHeaderInfo>(_matchHeaderInfos);
            }
        }

        public string TimeOfEvent
        {
            get;
            private set;
        }

        private void ViewMatchHeaderDetailsCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                var matchHeader = e.Parameter as MatchHeader;
                if (matchHeader != null)
                {
                    var window = new MatchHeaderDetails(matchHeader);
                    window.Show();
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }

        private void ViewMatchInfoDetailsCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                var matchInfo = e.Parameter as MatchInfo;
                if (matchInfo != null)
                {
                    var window = new MatchInfoDetails(matchInfo);
                    window.Show();
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }

    }
}
