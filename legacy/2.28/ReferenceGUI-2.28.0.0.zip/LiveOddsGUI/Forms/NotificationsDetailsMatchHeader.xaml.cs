﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System.Windows;

namespace Sportradar.Demo.GUI.LiveOdds.Forms
{
    /// <summary>
    /// Interaction logic for NotificationsDetailsMatchHeader.xaml
    /// </summary>
    public partial class NotificationsDetailsMatchHeader : Window
    {
        public NotificationsDetailsMatchHeader()
        {
            InitializeComponent();
        }
    }
}
