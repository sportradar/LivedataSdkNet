﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.Common;
using Sportradar.Demo.GUI.LiveOdds.Code;
using Sportradar.Demo.GUI.LiveOdds.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Enums;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Models;
using System;
using System.Collections.Concurrent;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Threading;

namespace Sportradar.Demo.GUI.LiveOdds.Forms
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private readonly ConcurrentDictionary<long, MatchCardSummary> _LoadedMatchCardSummaries = new ConcurrentDictionary<long, MatchCardSummary>();
        private readonly ImprovedObservableCollection<MatchInfoModel> _LoadedMatches = new ImprovedObservableCollection<MatchInfoModel>();
        private readonly ImprovedObservableCollection<MatchInfoModel> _LoadedMatchesView = new ImprovedObservableCollection<MatchInfoModel>();
        private readonly ListCollectionView _ListGlobalNotificationsView;
        private CheckableObservableCollection<NotificationType> _event_filters;

        private ImprovedObservableCollection<FilterElement> _MatchingCategoryItems = new ImprovedObservableCollection<FilterElement>();
        private ImprovedObservableCollection<FilterElement> _MatchingTournamentItems = new ImprovedObservableCollection<FilterElement>();


        public MainWindow()
        {
            //Ensure the current culture passed into bindings is the OS culture. 
            //By default, WPF uses en-US as the culture, regardless of the system settings.
            FrameworkElement.LanguageProperty.OverrideMetadata(
                typeof(FrameworkElement), 
                new FrameworkPropertyMetadata(XmlLanguage.GetLanguage(CultureInfo.CurrentCulture.IetfLanguageTag)));


            InitializeComponent();
            this.WindowState = WindowState.Maximized;
            References.Instance.LoadedMatchIds.CollectionChanged += LoadedMatchIdsCollectionChanged;
            _event_filters = new CheckableObservableCollection<NotificationType>();

            this._ListGlobalNotificationsView = new ListCollectionView(References.Instance.GlobalNotifications);
            _ListGlobalNotificationsView.Filter = GlobalNotificationsFilter;
            _ListGlobalNotificationsView.Refresh();
            References.Instance.GlobalNotifications.CollectionChanged += (sender, args) => RefreshFilters();

            References.Instance.ServerTimeModel.PropertyChanged += ServerTimeModelPropertyChanged;

            ChangeTracker.Instance.OnConnected += (t) => OnPropertyChanged("Connected");
            ChangeTracker.Instance.OnDisconnected += (t) => OnPropertyChanged("Connected");
            DataContext = this;
        }

        protected void OnPropertyChanged(params string[] propNames)
        {
            var propertyChanged = this.PropertyChanged;
            if (propertyChanged != null)
            {
                foreach (var propName in propNames)
                {
                    if (propName == null)
                    {
                        continue;
                    }

                    propertyChanged(this, new PropertyChangedEventArgs(propName));
                }
            }
        }

        private void ServerTimeModelPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if ((e != null) && ((e.PropertyName == "ServerTime") || (e.PropertyName == "LocalTime")))
            {
                this.OnPropertyChanged(e.PropertyName);
            }
        }


        private void FilterChange(object sender, DataTransferEventArgs e)
        {
            _ListGlobalNotificationsView.Refresh();
        }

        private void RefreshFilters()
        {
            foreach (var notification in References.Instance.GlobalNotifications)
            {
                var type = notification.NotificationType;
                if (!_event_filters.Any(x => x.Value == type))
                {
                    _event_filters.Add(type);
                    _event_filters.First(x => x.Value == type).IsChecked = true;
                }
            }

            //ToList to get loose of "Collection was modified; enumeration operation may not execute" exception
            foreach (var eventFilter in _event_filters.ToList())
            {
                if (!References.Instance.GlobalNotifications.Any(x => x.NotificationType == eventFilter.Value))
                {
                    _event_filters.Remove(eventFilter);
                }
            }

            _ListGlobalNotificationsView.Refresh();
            InvalidateVisual();
        }


        public ImprovedObservableCollection<FilterElement> SportItems
        {
            get
            {
                return References.Instance.AllSportFilters;
            }
        }


        public ImprovedObservableCollection<FilterElement> CategoryItems
        {
            get
            {
                return _MatchingCategoryItems;
            }
        }


        public ImprovedObservableCollection<FilterElement> TournamentItems
        {
            get
            {
                return _MatchingTournamentItems;
            }
        }

        public DateTime? ServerTime
        {
            get { return References.Instance.ServerTimeModel.ServerTime; }
        }

        public DateTime? LocalTime
        {
            get { return References.Instance.ServerTimeModel.LocalTime; }
        }

        private bool GlobalNotificationsFilter(object o)
        {
            var model = o as NotificationDisplayModel;
            if (model != null && model.Message != null)
            {
                var filter = _event_filters.FirstOrDefault(x => x.Value == model.NotificationType);
                if (filter != null && filter.IsChecked == false)
                {
                    return false;
                }
            }

            return true;
        }

        private void LoadedMatchIdsCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            _LoadedMatches.BeginEdit();
            switch (e.Action)
            {
                case NotifyCollectionChangedAction.Add:
                    {
                        for (int i = 0; i < e.NewItems.Count; i++)
                        {
                            MatchInfoModel match;
                            if (References.Instance.MatchInfos.TryGetValue((long)e.NewItems[i], out match))
                            {
                                this._LoadedMatches.Insert(e.NewStartingIndex + i, match);
                            }
                        }

                        break;
                    }
                case NotifyCollectionChangedAction.Move:
                    {
                        for (int i = 0; i < e.OldItems.Count; i++)
                        {
                            this._LoadedMatches.RemoveAt(e.OldStartingIndex);
                        }
                        // add
                        goto case NotifyCollectionChangedAction.Add;
                    }

                case NotifyCollectionChangedAction.Remove:
                    {
                        for (int i = 0; i < e.OldItems.Count; i++)
                        {
                            this._LoadedMatches.RemoveAt(e.OldStartingIndex);
                        }

                        break;
                    }

                case NotifyCollectionChangedAction.Replace:
                    {
                        for (int i = 0; i < e.OldItems.Count; i++)
                        {
                            this._LoadedMatches.RemoveAt(e.OldStartingIndex);
                        }
                        // add
                        goto case NotifyCollectionChangedAction.Add;
                    }

                case NotifyCollectionChangedAction.Reset:
                    {
                        this._LoadedMatches.Clear();
                        foreach (var loadedMatchId in this.LoadedMatchIds)
                        {
                            MatchInfoModel match;
                            if (References.Instance.MatchInfos.TryGetValue(loadedMatchId, out match))
                            {
                                this._LoadedMatches.Add(match);
                            }
                        }
                        break;
                    }

                default:
                    break;
            }
            _LoadedMatches.EndEdit();
        }

        public GuiStrings GuiStrings
        {
            get
            {
                return GuiStrings.Instance;
            }
        }

        public ImprovedObservableCollection<long> LoadedMatchIds
        {
            get
            {
                return References.Instance.LoadedMatchIds;
            }
        }

        public ListCollectionView GlobalNotifications
        {
            get
            {
                return _ListGlobalNotificationsView;
            }
        }


        public ImprovedObservableCollection<MatchInfoModel> LoadedMatches
        {
            get
            {
                return this._LoadedMatchesView;
            }
        }


        public ConcurrentDictionary<long, MatchCardSummary> LoadedMatchCardSummaries
        {
            get
            {
                return this._LoadedMatchCardSummaries;
            }
        }

        public ImprovedObservableCollection<CollectedQueueStatsModel> DispatcherQueueStats
        {
            get
            {
                return References.Instance.DispatcherQueueStatsModel.Queues;
            }
        }

        public CheckableObservableCollection<NotificationType> EventFilters
        {
            get
            {
                return _event_filters;
            }
        }

        public LanguagesHandler LanguagesHandler
        {
            get { return References.Instance.LanguagesHandler; }
        }

        public bool Connected
        {
            get { return ChangeTracker.Instance.Connected; }
        }

        private void SubscribeMatchCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if (e.Parameter is long)
                {
                    long matchId = (long)e.Parameter;

                    // release GUI thread ASAP
                    Task.Factory.StartNew(() => ChangeTracker.Instance.SubscribeToMatch(matchId))
                        .ContinueWith((task) => task.Exception.InnerException.ShowError(), TaskContinuationOptions.OnlyOnFaulted);
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }

        private void UnsubscribeMatchCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if (e.Parameter is long)
                {
                    long matchId = (long)e.Parameter;

                    // release GUI thread ASAP
                    Task.Factory.StartNew(() => ChangeTracker.Instance.UnsubscribeFromMatch(matchId))
                        .ContinueWith((task) => task.Exception.InnerException.ShowError(), TaskContinuationOptions.OnlyOnFaulted);
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }

        private void ViewMatchOddsCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if (e.Parameter is long)
                {
                    long matchId = (long)e.Parameter;
                    var detailsForm = new MatchOdds(matchId);
                    detailsForm.Show();
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }

        private void BookMatchCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if (e.Parameter is long)
                {
                    long matchId = (long)e.Parameter;

                    // release GUI thread ASAP
                    Task.Factory.StartNew(() => ChangeTracker.Instance.BookMatch(matchId))
                        .ContinueWith((task) => task.Exception.InnerException.ShowError(), TaskContinuationOptions.OnlyOnFaulted);
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }


        private void ViewMatchCardSummaryCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if (e.Parameter is long)
                {
                    long matchId = (long)e.Parameter;

                    // release GUI thread ASAP
                    Task.Factory.StartNew(() =>
                    {
                        ManualResetEventSlim wait_for_reply = new ManualResetEventSlim();
                        ChangeTracker.Instance.GetScoreAndCardSummary(matchId);
                        ChangeTracker.Instance.ScoreCardEvent += id =>
                        {
                            if (id == matchId)
                            {
                                wait_for_reply.Set();
                            }
                        };
                        wait_for_reply.Wait(2000);
                        this._LoadedMatchCardSummaries.AddOrUpdate(matchId,
                            (matchIdParam) =>
                            {
                                return (MatchCardSummary)this.Dispatcher.Invoke((Func<MatchCardSummary>)(() =>
                                {
                                    var detailsForm = new MatchCardSummary(this, matchIdParam);
                                    detailsForm.WindowState = this.WindowState;
                                    detailsForm.Show();

                                    return detailsForm;
                                }));
                            },
                            (oldMatchIdParam, oldMatchDetails) =>
                            {
                                return (MatchCardSummary)this.Dispatcher.Invoke((Func<MatchCardSummary>)(() =>
                                {
                                    oldMatchDetails.Activate();
                                    return oldMatchDetails;
                                }));
                            });
                    })
                    .ContinueWith((task) => task.Exception.InnerException.ShowError(), TaskContinuationOptions.OnlyOnFaulted);
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }



        private void ViewMatchNotificationsCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if (e.Parameter is long)
                {
                    long matchId = (long)e.Parameter;

                    var notifications = new MatchNotifications(this, matchId);
                    notifications.Show();
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }

        private void btnGlobalNotificationClearAll(object sender, RoutedEventArgs e)
        {
            try
            {
                var notifications = References.Instance.GlobalNotifications
                    .ToArray();
                if (notifications != null && notifications.Length > 0)
                {
                    foreach (var notification in notifications)
                    {
                        References.Instance.GlobalNotifications.Remove(notification);
                    }
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }


        private void btnClearPersistentStore(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                // release GUI thread ASAP

                Task.Factory.StartNew(() => ChangeTracker.Instance.ClearState())
                .ContinueWith((task) => task.Exception.InnerException.ShowError(), TaskContinuationOptions.OnlyOnFaulted);
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }



        private void ViewNotificationDetailsCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if (e.Parameter is Guid)
                {
                    Guid notificationId = (Guid)e.Parameter;

                    var notification = References.Instance.GlobalNotifications.FirstOrDefault(n => n.Id == notificationId);
                    if (notification != null)
                    {
                        switch (notification.NotificationType)
                        {
                            case NotificationType.Alive:
                                {
                                    var notifications = new AliveNotificationDetails(notification.LocalTimestamp, notification.EventArgs as AliveEventArgs);
                                    notifications.Show();
                                    break;
                                }
                            case NotificationType.MetaInfo:
                                {
                                    var notifications = new MetaInfoNotificationDetails(notification.LocalTimestamp, notification.EventArgs as MetaInfoEventArgs);
                                    notifications.Show();
                                    break;
                                }
                            case NotificationType.ScoreCardSummary:
                                {
                                    var notifications = new ScoreCardSummaryNotificationDetails(notification.LocalTimestamp, notification.EventArgs as ScoreCardSummaryEventArgs);
                                    notifications.Show();
                                    break;
                                }

                        }
                    }
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }

        private void DeleteNotificationCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if (e.Parameter is Guid)
                {
                    Guid notificationId = (Guid)e.Parameter;

                    var notification = References.Instance.GlobalNotifications.FirstOrDefault(n => n.Id == notificationId);
                    if (notification != null)
                    {
                        References.Instance.GlobalNotifications.Remove(notification);
                    }
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }


        private void GetMetaInfoCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if (e.Parameter is long)
                {
                    long matchid = (long)e.Parameter;
                    Task.Factory.StartNew(() => ChangeTracker.Instance.GetMatchList(null, null, new[] { matchid }, false))
                     .ContinueWith((task) => task.Exception.InnerException.ShowError(), TaskContinuationOptions.OnlyOnFaulted);
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }


        private void ctrSelectedSportChanged(object sender, SelectionChangedEventArgs e)
        {
            var sport = SportComboBox.SelectedItem as FilterElement;
            if (sport != null)
            {
                CategoryItems.BeginEdit();
                CategoryComboBox.SelectedItem = null;
                TournamentComboBox.SelectedItem = null;
                CategoryItems.Clear();
                TournamentItems.Clear();
                foreach (var categoryFilter in References.Instance.AllCategoryFilters.OrderBy(x => x.Name.GetTranslation(References.Instance.LanguagesHandler.CurrentLanguage)))
                {
                    if (References.Instance.MatchFiltersCombinations.Any(x => x.Sport == sport.Name && x.Category == categoryFilter.Name))
                    {
                        if (!CategoryItems.Any(x => x.Name == categoryFilter.Name))
                        {
                            CategoryItems.Add(categoryFilter);
                        }
                    }
                }
                CategoryItems.EndEdit();
            }
        }

        private void ctrSelectedCategoryChanged(object sender, SelectionChangedEventArgs e)
        {
            var sport = SportComboBox.SelectedItem as FilterElement;
            var category = CategoryComboBox.SelectedItem as FilterElement;
            if (category != null && sport != null)
            {
                TournamentItems.BeginEdit();
                TournamentComboBox.SelectedItem = null;
                TournamentItems.Clear();
                foreach (var tournamentFilter in References.Instance.AllTournamentFilters.OrderBy(x => x.Name.GetTranslation(GuiStrings.Instance.CurrentLanguage)))
                {
                    if (References.Instance.MatchFiltersCombinations.Any(
                        x => x.Sport == sport.Name &&
                            x.Category == category.Name &&
                            x.Tournament == tournamentFilter.Name) &&
                        !TournamentItems.Any(x => x.Name == tournamentFilter.Name))
                    {
                        TournamentItems.Add(tournamentFilter);
                    }
                }
                TournamentItems.EndEdit();
            }
        }

        private void ctrSelectedTournamentChanged(object sender, SelectionChangedEventArgs e)
        {
            var sport = SportComboBox.SelectedItem as FilterElement;
            var category = CategoryComboBox.SelectedItem as FilterElement;
            var tournament = TournamentComboBox.SelectedItem as FilterElement;
            if (sport != null && category != null && tournament != null)
            {
                _LoadedMatchesView.Clear();
                var filtered_matches = _LoadedMatches.Where(
                    x =>
                        x.SportName == sport.Name &&
                        x.CategoryName == category.Name &&
                        x.TournamentName == tournament.Name);

                _LoadedMatchesView.AddRange(filtered_matches);
            }
        }

        private DateTime? currently_selected_date = DateTime.Today;

        private void ctrMatchListInvoke(object sender, RoutedEventArgs e)
        {
            try
            {
                DateTime? selectedDay = this.dpMatchListSelectedDay.SelectedDate;
                if (selectedDay == null || currently_selected_date==selectedDay)
                {
                    return;
                }
                currently_selected_date = selectedDay;

                bool includeAvailable = false;
                if (this.chxMatchListIncludeAvailable != null)
                {
                    includeAvailable = this.chxMatchListIncludeAvailable.IsChecked ?? false;
                }

                TournamentComboBox.SelectedItem = null;
                CategoryComboBox.SelectedItem = null;
                SportComboBox.SelectedItem = null;
                ReferencesMerger.Instance.ClearAll();
                TournamentItems.Clear();
                CategoryItems.Clear();
                _LoadedMatchesView.Clear();

                var time = DateTime.SpecifyKind(selectedDay.Value, DateTimeKind.Local);

                ChangeTracker.Instance.GetMatchList(time, time.AddDays(1), null, includeAvailable);
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }

        private void ViewMatchOddsSettingsCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Parameter is long)
            {
                long matchId = (long)e.Parameter;

                var detailsForm = new MatchOddsSettings(matchId);
                detailsForm.Show();
            }
        }

        private void GetMatchStatusCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if(e.Parameter is long)
                {
                    long matchid = (long)e.Parameter;
                    Task.Factory.StartNew(() => ChangeTracker.Instance.GetCurrentMatchStatus(matchid, null))
                     .ContinueWith((task) => task.Exception.InnerException.ShowError(), TaskContinuationOptions.OnlyOnFaulted);
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }


        private void LanguageChanged(object sender, RoutedEventArgs e)
        {
            var language = ((MenuItem)e.OriginalSource).Header as string;
            if (language != null)
            {
                References.Instance.LanguagesHandler.CurrentLanguage = language;
                this.InvalidateVisual();
                MatchListDataGrid.Items.Refresh();
                SportComboBox.Items.Refresh();
                CategoryComboBox.Items.Refresh();
                TournamentComboBox.Items.Refresh();

                //HACK to refresh selected items languages
                var sportitem = SportComboBox.SelectedItem;
                var categoryitem = CategoryComboBox.SelectedItem;
                var tournamentitem = TournamentComboBox.SelectedItem;
                SportComboBox.SelectedItem = null;
                SportComboBox.SelectedItem = sportitem;
                CategoryComboBox.SelectedItem = categoryitem;
                TournamentComboBox.SelectedItem = tournamentitem;
            }
        }

        private void ExitClick(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
