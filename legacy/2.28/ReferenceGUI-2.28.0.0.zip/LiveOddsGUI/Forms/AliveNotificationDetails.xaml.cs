﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using System.Collections.Generic;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.Common;
using Sportradar.Demo.GUI.LiveOdds.Code;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;

namespace Sportradar.Demo.GUI.LiveOdds.Forms
{
    /// <summary>
    /// Interaction logic for AliveNotificationDetails.xaml
    /// </summary>
    public partial class AliveNotificationDetails : Window
    {
        private DateTime _time_of_event;
        private List<MatchHeader> _matchHeaders;


        public AliveNotificationDetails(DateTime localTimestamp, AliveEventArgs eventArgs)
        {
            InitializeComponent();
            _time_of_event = localTimestamp;
            var eventHeaders = eventArgs.Alive.EventHeaders;
            _matchHeaders = new List<MatchHeader>(eventHeaders.Count);
            foreach (var eventHeader in eventHeaders.OrderBy(x=>x.Id))
            {
                _matchHeaders.Add((MatchHeader)eventHeader);
            }
            this.DataContext = this;
        }

        public DateTime LocalTime
        {
            get { return _time_of_event; }
        }

        public ObservableCollection<MatchHeader> MatchHeaders
        {
            get { return new ObservableCollection<MatchHeader>(_matchHeaders); }
        }

        public void ViewMatchHeaderDetailsCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if (e.Parameter is long)
                {
                    long matchId = (long)e.Parameter;
                    var window = new MatchHeaderDetails(_matchHeaders.First(x => x.Id == matchId));
                    window.Show();
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }

        }
    }
}
