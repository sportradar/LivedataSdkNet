﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Sportradar.Demo.GUI.LiveOdds.Code;
using Sportradar.Demo.GUI.LiveOdds.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Models;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.Common;

namespace Sportradar.Demo.GUI.LiveOdds.Forms
{
    /// <summary>
    /// Interaction logic for MatchOddsSettings.xaml
    /// </summary>
    public partial class MatchOddsSettings : Window
    {
        private readonly long _MatchId;
        private readonly ImprovedObservableCollection<MatchOddsModel> _FilteredMatchOdds;
        private readonly ImprovedObservableCollection<MatchOddsModel> _AllMatchOdds;

        public MatchOddsSettings()
        {
            InitializeComponent();
        }

        public MatchOddsSettings(long matchId)
            : this()
        {
            this._MatchId = matchId;
            _FilteredMatchOdds = new ImprovedObservableCollection<MatchOddsModel>();
            ImprovedObservableCollection<MatchOddsModel> matchOdds;
            References.Instance.MatchOdds.TryGetValue(this._MatchId, out matchOdds);
            if (matchOdds != null)
            {
                this._AllMatchOdds = matchOdds;
            }
            RefreshOddsSettings();
            _AllMatchOdds.CollectionChanged += (sender, args) => RefreshOddsSettings();
            this.DataContext = this;
        }

        private void RefreshOddsSettings()
        {
            _FilteredMatchOdds.BeginEdit();
            foreach (var odd in _AllMatchOdds)
            {
                if (!_FilteredMatchOdds.Any(x => x.TypeId == odd.TypeId && x.SubType == odd.SubType))
                {
                    _FilteredMatchOdds.Add(odd);
                }
            }
            _FilteredMatchOdds.EndEdit();
        }

        public ImprovedObservableCollection<MatchOddsModel> LoadedMatchOdds
        {
            get { return this._FilteredMatchOdds; }
        }

        public long MatchId
        {
            get { return _MatchId; }
        }

        public GuiStrings GuiStrings
        {
            get
            {
                return GuiStrings.Instance;
            }
        }

        private void ActivateBettypeCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if (e.Parameter is OddsBetTypeDataHolder)
                {
                    OddsBetTypeDataHolder odds = (OddsBetTypeDataHolder)e.Parameter;
                    // release GUI thread ASAP
                    Task.Factory.StartNew(
                        () =>
                        {
                            var betTypes = new[]{new RegisterUnregisterBetType 
                                                     {
                                                         MatchId = MatchId,
                                                         BetTypes = new List<EventOddsLite>()
                                                     }};
                            betTypes[0].BetTypes.Add(new EventOddsLite()
                            {
                                Type = odds.OddsBetType,
                                SubType = odds.OddsBetSubtype,
                            });
                            if (odds.HasOddsField)
                            {
                                //TODO : When OddsField type is OddsTypeFieldType
                                //betTypes[0].BetTypes[0].AddOddsField(new OddsFieldLite { Type = (OddsTypeFieldType)1 });
                            }
                            ChangeTracker.Instance.RegisterBetTypes(betTypes);
                            //Request current match status to get fresh odds
                            ChangeTracker.Instance.GetCurrentMatchStatus(MatchId, null);
                        })
                        .ContinueWith((task) => task.Exception.InnerException.ShowError(), TaskContinuationOptions.OnlyOnFaulted);
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }

        private void DeactivateBettypeCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if (e.Parameter is OddsBetTypeDataHolder)
                {
                    OddsBetTypeDataHolder odds = (OddsBetTypeDataHolder)e.Parameter;
                    // release GUI thread ASAP
                    Task.Factory.StartNew(
                        () =>
                        {
                            var betTypes = new[]{new RegisterUnregisterBetType
                                                     {
                                                         MatchId = MatchId,
                                                         BetTypes = new List<EventOddsLite>()
                                                     }};
                            betTypes[0].BetTypes.Add(new EventOddsLite()
                            {
                                Type = odds.OddsBetType,
                                SubType = odds.OddsBetSubtype,
                            });
                            ChangeTracker.Instance.UnregisterBetTypes(betTypes);
                            //Request current match status to get fresh odds
                            ChangeTracker.Instance.GetCurrentMatchStatus(MatchId, null);
                        })
                        .ContinueWith((task) => task.Exception.InnerException.ShowError(), TaskContinuationOptions.OnlyOnFaulted);
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }

        private void ExpandCollapseRowDetails(object sender, MouseButtonEventArgs e)
        {
            var row = (DataGridRow)sender;
            if (row.DetailsVisibility == Visibility.Visible)
            {
                row.DetailsVisibility = Visibility.Collapsed;
            }
            else
            {
                row.DetailsVisibility = Visibility.Visible;
            }
        }

        private void CollapseAll(object sender, RoutedEventArgs e)
        {
            foreach (var item in OddsDataGrid.Items)
            {
                var row = OddsDataGrid.ItemContainerGenerator.ContainerFromItem(item) as DataGridRow;
                if (null != row)
                {
                    row.DetailsVisibility = Visibility.Collapsed;
                }
            }
        }

    }
}
