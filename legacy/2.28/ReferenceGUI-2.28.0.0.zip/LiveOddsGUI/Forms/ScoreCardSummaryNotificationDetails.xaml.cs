﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Models;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.Common;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Data;

namespace Sportradar.Demo.GUI.LiveOdds.Forms
{
    /// <summary>
    /// Interaction logic for ScoreCardSummaryNotificationDetails.xaml
    /// </summary>
    public partial class ScoreCardSummaryNotificationDetails : Window
    {

        private DateTime _local_timestamp;
        private ScoreCardSummaryModel _scoreCardSummary;


        public ScoreCardSummaryNotificationDetails(DateTime timeOfEvent, ScoreCardSummaryEventArgs eventArgs)
        {
            DataContext = this;
            _scoreCardSummary = new ScoreCardSummaryModel(eventArgs.ScoreCardSummary);
            _local_timestamp = timeOfEvent;
            InitializeComponent();
            if (ScoreCardSummaryModel.MatchHeader != null)
            {
                var mh = new MatchHeaderModel(ScoreCardSummaryModel.MatchHeader);
                HelperClass.FillGridWithObjectProperties(mh, MatchHeaderGrid, 6);
                if (mh.SetScores != null && mh.SetScores.Count > 0)
                {
                    HelperClass.BuildGridFromStringArray(mh.SetScores.Where(x => x != null).ToList(), SetScoresGrid, 1);
                }
                if (mh.Message != null && mh.Message.Count > 0)
                {
                    HelperClass.BuildGridFromStringArray(mh.Message, MessagesGrid, 1);
                }
            }
        }

        public DateTime LocalTimestamp
        {
            get { return _local_timestamp; }
        }
        public ScoreCardSummaryModel ScoreCardSummaryModel
        {
            get { return _scoreCardSummary; }
        }

        public ListCollectionView LoadedCardSummaryByTime
        {
            get { return new ListCollectionView(CardSummaryByTime); }
        }

        public ListCollectionView LoadedScoreSummaryByTime
        {
            get { return new ListCollectionView(ScoreSummaryByTime); }
        }

        private ObservableCollection<CardEntryModel> CardSummaryByTime
        {
            get
            {
                ScoreCardSummaryModel scoreCardSummaryModel = this.ScoreCardSummaryModel;
                if (scoreCardSummaryModel == null)
                {
                    return null;
                }
                return scoreCardSummaryModel.CardSummaryByTime;
            }
        }

        private ObservableCollection<ScoreEntryModel> ScoreSummaryByTime
        {
            get
            {
                ScoreCardSummaryModel scoreCardSummaryModel = this.ScoreCardSummaryModel;
                if (scoreCardSummaryModel == null)
                {
                    return null;
                }
                return scoreCardSummaryModel.ScoreSummaryByTime;
            }
        }
    }
}
