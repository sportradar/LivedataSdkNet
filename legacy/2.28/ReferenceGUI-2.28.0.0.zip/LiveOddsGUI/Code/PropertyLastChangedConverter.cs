﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Windows.Data;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;

namespace Sportradar.Demo.GUI.LiveOdds.Code
{
    public class PropertyLastChangedConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            string additionalValue = string.Empty;

            object value = ((values != null && values.Length > 0) ? values[0] : null);
            if ((value != null)
                && (value is NotifyPropertyChanged))
            {
                if ((parameter != null)
                    && (parameter is string))
                {
                    additionalValue = ((NotifyPropertyChanged)value).GetLastChange((string)parameter).ToString("O");
                }
            }

            return additionalValue;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
