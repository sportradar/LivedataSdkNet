﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using Sportradar.Demo.GUI.LiveOdds.DataProvider;
using Merged::Sportradar.SDK.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;

namespace Sportradar.Demo.GUI.LiveOdds.Code
{
    public class LocalizedStringToTranslationConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            LocalizedString localizedString = value as LocalizedString;

            if (localizedString != null)
            {
                return localizedString.GetTranslation(References.Instance.LanguagesHandler.CurrentLanguage);
            }

            return value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
