﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using Sportradar.Demo.GUI.LiveOdds.DataProvider;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Models;
using Sportradar.Demo.GUI.LiveOdds.Forms;

namespace Sportradar.Demo.GUI.LiveOdds.Code
{
    public class AvailableToUnsubscribeConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter,
            System.Globalization.CultureInfo culture)
        {
            if (value is bool)
            {
                bool active = (bool)value;
                if (active)
                {
                    return System.Windows.Visibility.Visible;
                }
            }
            return System.Windows.Visibility.Collapsed;
        }

        public object ConvertBack(object value, Type targetType, object parameter,
            System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
