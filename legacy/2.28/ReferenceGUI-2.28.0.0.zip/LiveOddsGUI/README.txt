﻿
This is the front-end project of LiveOdds GUI. 

Main form is MainWindow which contains matches, notifications, persistent store / dead letter queue and monitoring / statistics tabs. 

When GUI is started a match list for current day is requested so the GUI contains all available matches. User can also request match list
of all the matches for a specific day. If include available is checked matches that the client hasn't booked will also be send. 
When a new request is made, old matches are cleared. 

For every match in match list the user has option to book a match, request meta info, subscribe to the match, request current status, 
view odds, odds settings, score and card summary.
We also track all received events for every match.

To display specific matches user has to select desired sport, category and tournament in that order. 
Filtered matches are displayed with basic info and available actions.  

When user clicks on "Live Odds" button a new window opens which contains all received odds for that match. 
With double click on odd type details open up containing odd type fields. 

"Odds settings" button window is similar to "Live Odds" window. Here user can activate/deactivate whole odd type or just one odd type field.

"Scores & Cards" button sends score card summary request and when reply arrives a new window is opened. 

"Events" button open up a window containing all the event notifications for selected match. Filtering by type is possible. 
Every notification has "Details" button which opens up details about event with event data. 
"Delete" button deletes corresponding notification. 

"Notifications" tab contains notifications that aren’t match specific. Filtering by type is also possible.

In "Monitoring/Statistics" tab we display statistics for all dispatcher and error recovery queues.


