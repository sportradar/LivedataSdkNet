Bookmaker SDK short introduction and tutorial.

For more information please see the MSDN style CHM documentation of the Bookmaker SDK interface and data contracts. 


1) Configuration

In your app.config / web.config you need at least to set-up the following:
(Note that configSection needs to be on top of the file and that you need to replace xxx with actual credentials).

<configSections>
 <section name="Sdk" type="Sportradar.SDK.Services.SdkConfiguration.SdkConfigurationSection, BookmakerSdk"/>
</configSections>

<Sdk>
  <Common BookmakerId="xxx"/>
  <LiveOdds BookmakerKey="xxx" Test="true|false" TestScenario="1..12" />
  <LiveScout ScoutUsername="xxx" ScoutPassword="xxx" Test="true|false" />
</Sdk>

For more configuration options please refer to the documentation under Sportradar.SDK.Services.SdkConfiguration section.


2) Reference the library

You need to add a "Reference" to BookmakerSdk.dll in the project that is built for the .NET 4 framework. For Intellisense the BookmakerSdk.xml file is used (should be in the same directory as DLL).


3) Sqlite dependency

SDK is using SQLite library to store the current state of latest match events received in a local database. This is why you need to add the X86 and X64 directories with corresponding SQLite.Interop.dll native libraries to the project as artefacts - NOT as references but as "Existing items" with "Copy to output directory" set to "Always". 

We recommend installing "System.Data.Sqlite (x86/x64)" package instead using the NuGet package manager that does everything for you.

If you prefer you can also implement your own persistent state storage this way eliminating the Sqlite dependency by using a database of your own choice. One database table is enough to store complete SDK state.


4) The code 

Bookmaker SDK is a singleton. There should be only one SDK instance per process. When using multiple processes avoid running multiple SDK instances, especially if the same access credentials are used. You may end up in an inconsistent state and get problems due to limits on the server side. Use IPC instead in such cases.


4.1) Initialize the SDK:

Sdk.Instance.Initialize();

Here you might want to pass a different configuration section name or pass on your implementation of the IDeadLetterQueue interface if you would like to log and/or report all invalid/undelivered SDK messages and events.


4.2) Start the SDK instance and register for global SDK events:

Sdk.Instance.OnQueueLimitReached += OnQueueLimitReached;
Sdk.Instance.OnQueueLimitRetreated += OnQueueLimitRetreated;

Sdk.Instance.Start();

Queue limit notifications are useful to give you alerts when message queue congestion starts to build up (or has settled down) so that you can be proactive about it.


4.3) Monitor SDK queue statistics

By looking at the Sdk.Instance.QueueStats you can see various performance characteristics and statistics of the underlying SDK dispatcher queues.


4.4) Start the actual SDK provider(s) (e.g. LiveOdds, LiveScout) and register for provider events:

if (Sdk.Instance.LiveOdds != null)
{
	Sdk.Instance.LiveOdds.OnConnectionStable += ConnectionStable;
	Sdk.Instance.LiveOdds.OnMatchRemovedFromAlive += MatchRemovedFromAlive;

	Sdk.Instance.LiveOdds.OnAliveReceived += AliveReceived;
	Sdk.Instance.LiveOdds.OnFeedError += FeedErrorOccurred;
	Sdk.Instance.LiveOdds.OnBetCancel += MatchBetCancelled;
	Sdk.Instance.LiveOdds.OnBetCancelUndone += MatchBetCancelUndone;
	Sdk.Instance.LiveOdds.OnBetClear += MatchBetCleared;
	Sdk.Instance.LiveOdds.OnBetClearRollback += MatchBetClearRollbacked;
	Sdk.Instance.LiveOdds.OnBetStart += BetStarted;
	Sdk.Instance.LiveOdds.OnBetStop += BetStopped;
	Sdk.Instance.LiveOdds.OnMetaInfoReceived += MetaInfoReceived;
	Sdk.Instance.LiveOdds.OnOddsChange += OddsChanged;
	Sdk.Instance.LiveOdds.OnScoreCardReceived += ScoreCardReceived;

	Sdk.Instance.LiveOdds.Start();
}
else
{
	throw new ApplicationException("Error initializing SDK.LiveOdds provider");
}

If you didn't call Sdk.Instance.Initialize() accessing Sdk.Instance.LiveOdds will throw an InitException.
SDK provider(s) will try to connect to the corresponding XML feed server and keep the connection alive. If the connection is lost the provider will try to reconnect automatically - you will be informed of this through the corresponding events.


4.5) Stop SDK provider(s) (e.g. LiveOdds, LiveScout) and unregister from provider events:

if (Sdk.Instance.LiveOdds != null)
{
	Sdk.Instance.LiveOdds.Stop();

	Sdk.Instance.LiveOdds.OnConnectionStable -= ConnectionStable;
	Sdk.Instance.LiveOdds.OnMatchRemovedFromAlive -= MatchRemovedFromAlive;
	
	Sdk.Instance.LiveOdds.OnAliveReceived -= AliveReceived;
	Sdk.Instance.LiveOdds.OnFeedError -= FeedErrorOccurred;
	Sdk.Instance.LiveOdds.OnBetCancel -= MatchBetCancelled;
	Sdk.Instance.LiveOdds.OnBetCancelUndone -= MatchBetCancelUndone;
	Sdk.Instance.LiveOdds.OnBetClear -= MatchBetCleared;
	Sdk.Instance.LiveOdds.OnBetClearRollback -= MatchBetClearRollbacked;
	Sdk.Instance.LiveOdds.OnBetStart -= BetStarted;
	Sdk.Instance.LiveOdds.OnBetStop -= BetStopped;
	Sdk.Instance.LiveOdds.OnMetaInfoReceived -= MetaInfoReceived;
	Sdk.Instance.LiveOdds.OnOddsChange -= OddsChanged;
	Sdk.Instance.LiveOdds.OnScoreCardReceived -= ScoreCardReceived;
}

4.6) Stop the SDK instance and unregister from global SDK events:

Sdk.Instance.OnQueueLimitReached -= OnQueueLimitReached;
Sdk.Instance.OnQueueLimitRetreated -= OnQueueLimitRetreated;

Sdk.Instance.Stop();


4.7) With C# 5 and .NET 4.5 you can also use asynchronous awaitable SDK interface (extension methods)

All async methods have the Async method name postfix, accept an optional timeout parameter and return a Task object that can be waited upon. These extension methods are be available only through BookmakerSdkExt.dll that is built for the .NET 4.5 framework.

ScoreCardSummary ret = await Sdk.Instance.LiveOdds.GetScoreAndCardSummaryAsync(match_id);


4.8) SDK logs

SDK will make various logs during its operation. Logs are organized into various categories, based on whether these are critical alerts, invalid messages received, periodical queue stats dumps, configuration updates, message traffic, etc. Level of logging can be configured through "SdkLogger" configuration element in the "Sdk" configuration section.

5.) Gotchas

SDK generates implicit "bet stop" message after disconnect and does automatic error recovery. It does however NOT keep track of bet clearings!

If you are disconnected for a long time it may happen that after you come back the match is already over. In that time-frame bets were not accepted (so you are safe) but it might still be 
necessary to clear the bets placed at the begining of the match. In that (rare) case you will receive OnMatchRemovedFromAlive and it is up to you to invoke GetMatchStatus method to obtain bet clearings to do correct pay-outs
(if / when required). You could also decide for some time based "expiration" and just ignore OnMatchRemovedFromAlive event or even do pay-out after a grace period (to handle outcome changes after a match is finished to decrease risk).

If match is suspended or cancelled you will receive OnMetaInfoReceived and see the change periodically in OnAliveReceived as AliveEventArgs.MatchHeader[].Status. But again you can be disconnected too long and miss that.
So same logic as before applies, you need to be sure to do some sort of "garbage-collection" and delete stale matches.

SDK NEVER generates implicit "bet start". You should not rely on OnBetStart to start accepting bets again but check MatchState.BetStatus (also from for instance OnOddsChangeEventArgs)!