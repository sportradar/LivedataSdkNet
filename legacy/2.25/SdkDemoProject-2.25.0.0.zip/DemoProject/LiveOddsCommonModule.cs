﻿using log4net;
using Sportradar.SDK.FeedProviders.LiveOdds.Common;
using System;

namespace Sportradar.DemoProject
{
    public abstract class LiveOddsCommonModule : LiveOddsCommonBaseModule
    {
        private static readonly ILog g_log = LogManager.GetLogger(typeof(LiveOddsCommonModule));
        private readonly ILiveOddsCommon m_live_odds;

        protected LiveOddsCommonModule(ILiveOddsCommon live_odds, string feed_name, TimeSpan meta_interval)
            :base(live_odds, feed_name, meta_interval)
        {
            m_live_odds = live_odds;
            m_live_odds.OnAlive += AliveHandler;
        }

        protected virtual void AliveHandler(object sender, AliveEventArgs e)
        {
            g_log.InfoFormat("{0}: Received alive with {1} events", m_feed_name, e.Alive.EventHeaders.Count);
        }
    }
}