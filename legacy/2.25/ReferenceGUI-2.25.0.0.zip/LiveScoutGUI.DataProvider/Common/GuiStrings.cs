﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.Common;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Sportradar.Demo.GUI.LiveScout.DataProvider.Common
{
    public class GuiStrings : NotifyPropertyChanged
    {
        private readonly static Lazy<GuiStrings> _Instance = new Lazy<GuiStrings>(() => new GuiStrings(), true);
        public static GuiStrings Instance { get { return _Instance.Value; } }
        private GuiStrings()
        {
            this._Strings.Add("Question", new LocalizedString("Question"));
            this._Strings.Add("Info", new LocalizedString("Info"));
            this._Strings.Add("Error", new LocalizedString("Error"));
            this._Strings.Add("UnexpectedError", new LocalizedString("Unexpected Error"));
            this._Strings.Add("GO", new LocalizedString("GO"));
            this._Strings.Add("AvailableMatches", new LocalizedString("Available matches"));
            this._Strings.Add("SubscribedMatches", new LocalizedString("Subscribed matches"));
            this._Strings.Add("Subscribe", new LocalizedString("Subscribe"));
            this._Strings.Add("Unsubscribe", new LocalizedString("Unsubscribe"));
            this._Strings.Add("MainQueueStats", new LocalizedString("Main queue stats"));
            this._Strings.Add("DispatcherQueueStats", new LocalizedString("Dispatcher queue stats"));
            this._Strings.Add("Refresh", new LocalizedString("Refresh"));
            this._Strings.Add("Book", new LocalizedString("Book"));
            this._Strings.Add("ViewMatchEvents", new LocalizedString("Events"));
            this._Strings.Add("ViewMatchInfo", new LocalizedString("Infos"));
            this._Strings.Add("ViewMatchOddsSuggestions", new LocalizedString("Odds"));
            this._Strings.Add("ViewMatchStatistics", new LocalizedString("Stats"));
            this._Strings.Add("FilterBy", new LocalizedString("Filter By"));
            this._Strings.Add("Sport", new LocalizedString("Sport"));
            this._Strings.Add("Category", new LocalizedString("Category"));
            this._Strings.Add("Tournament", new LocalizedString("Tournament"));
        }

        private readonly Dictionary<string, LocalizedString> _Strings = new Dictionary<string, LocalizedString>();
        private string _CurrentLanguage = "sl";

        public string CurrentLanguage
        {
            get { return this._CurrentLanguage; }
            set
            {
                if (this._CurrentLanguage != value)
                {
                    this._CurrentLanguage = value;
                    this.OnPropertyChanged("CurrentLanguage");
                    this.OnPropertyChanged(this._Strings.Keys.ToArray());
                }
            }
        }

        public string Question { get { return this._Strings["Question"].GetTranslation(this._CurrentLanguage); } }
        public string Info { get { return this._Strings["Info"].GetTranslation(this._CurrentLanguage); } }
        public string Error { get { return this._Strings["Error"].GetTranslation(this._CurrentLanguage); } }
        public string UnexpectedError { get { return this._Strings["UnexpectedError"].GetTranslation(this._CurrentLanguage); } }
        public string GO { get { return this._Strings["GO"].GetTranslation(this._CurrentLanguage); } }
        public string AvailableMatches { get { return this._Strings["AvailableMatches"].GetTranslation(this._CurrentLanguage); } }
        public string SubscribedMatches { get { return this._Strings["SubscribedMatches"].GetTranslation(this._CurrentLanguage); } }
        public string Subscribe { get { return this._Strings["Subscribe"].GetTranslation(this._CurrentLanguage); } }
        public string Unsubscribe { get { return this._Strings["Unsubscribe"].GetTranslation(this._CurrentLanguage); } }
        public string MainQueueStats { get { return this._Strings["MainQueueStats"].GetTranslation(this._CurrentLanguage); } }
        public string DispatcherQueueStats { get { return this._Strings["DispatcherQueueStats"].GetTranslation(this._CurrentLanguage); } }
        public string Refresh { get { return this._Strings["Refresh"].GetTranslation(this._CurrentLanguage); } }
        public string Book { get { return this._Strings["Book"].GetTranslation(this._CurrentLanguage); } }
        public string ViewMatchEvents { get { return this._Strings["ViewMatchEvents"].GetTranslation(this._CurrentLanguage); } }
        public string ViewMatchInfo { get { return this._Strings["ViewMatchInfo"].GetTranslation(this._CurrentLanguage); } }
        public string ViewMatchOddsSuggestions { get { return this._Strings["ViewMatchOddsSuggestions"].GetTranslation(this._CurrentLanguage); } }
        public string ViewMatchStatistics { get { return this._Strings["ViewMatchStatistics"].GetTranslation(this._CurrentLanguage); } }
        public string FilterBy { get { return this._Strings["FilterBy"].GetTranslation(this._CurrentLanguage); } }
        public string Sport { get { return this._Strings["Sport"].GetTranslation(this._CurrentLanguage); } }
        public string Category { get { return this._Strings["Category"].GetTranslation(this._CurrentLanguage); } }
        public string Tournament { get { return this._Strings["Tournament"].GetTranslation(this._CurrentLanguage); } }
    }
}
