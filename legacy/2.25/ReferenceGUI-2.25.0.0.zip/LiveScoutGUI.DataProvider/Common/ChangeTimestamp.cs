﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sportradar.Demo.GUI.LiveScout.DataProvider.Common
{
    public class ChangeTimestamp
    {
        public DateTime PreviousChange { get; private set; }
        public DateTime CurrentChange { get; private set; }

        public void SetLastChange(DateTime dateTime)
        {
            this.PreviousChange = this.CurrentChange;
            this.CurrentChange = dateTime;
        }
    }
}