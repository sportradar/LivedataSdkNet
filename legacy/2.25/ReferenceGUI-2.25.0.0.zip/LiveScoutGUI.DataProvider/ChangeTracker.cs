﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using log4net;
using Merged::Sportradar.SDK.Common.Interfaces;
using Merged::Sportradar.SDK.FeedProviders.Common;
using Merged::Sportradar.SDK.FeedProviders.LiveScout;
using Merged::Sportradar.SDK.Services.Sdk;
using Merged::Sportradar.SDK.Services.SdkConfiguration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Timers;

namespace Sportradar.Demo.GUI.LiveScout.DataProvider
{
    /// <summary>
    /// Main data singleton class.
    /// It hooks on instance of SDK and subscribes to all possible LiveScout events.
    /// All data received from SDK events is passed to ReferenceMerger, which merges data into References.
    /// Enables calling all possible SDK requests with wrapped SDK method.
    /// </summary>
    public class ChangeTracker
    {
        private readonly static Lazy<ChangeTracker> _Instance = new Lazy<ChangeTracker>(() => new ChangeTracker(), true);

        /// <summary>
        /// Gets the (singleton) instance of ChangeTracker class.
        /// </summary>
        public static ChangeTracker Instance { get { return _Instance.Value; } }
        
        
        
        private ChangeTracker()
        {
            //Timer to refresh queue statistics
            this._QueueStatsRefreshTimer = new Timer();
            this._QueueStatsRefreshTimer.AutoReset = true;
            this._QueueStatsRefreshTimer.Enabled = false;
            this._QueueStatsRefreshTimer.Interval = (1000 * 1);
            this._QueueStatsRefreshTimer.Elapsed += QueueStatsRefreshTimerElapsed;
            this._QueueStatsRefreshTimer.Start();
        }

        private readonly ILog _Logger = LogManager.GetLogger(typeof(ChangeTracker));
        private readonly Timer _QueueStatsRefreshTimer;

        private void QueueStatsRefreshTimerElapsed(object sender, ElapsedEventArgs e)
        {
            if (!Sdk.Instance.IsInitialized)
            {
                return;
            }

            var stats = Sdk.Instance.QueueStats;
            if (stats != null)
            {
                ReferencesMerger.Instance.MergeDispatcherQueueStats(stats);
            }
            
            ReferencesMerger.Instance.MergeServerTime(Sdk.Instance.LiveScout.ServerTime);
        }

        #region --- ILiveScout, ILiveFeeds ---


        /// <summary>
        /// Starts instance of SDK and LiveScout provider. Also subscribes to all LiveScout events
        /// </summary>
        /// <remarks>Uses Sqlite implementation of <see cref="IDeadLetterQueue"/></remarks>
        /// <exception cref="DataProviderException">Failed to initialize LiveScout provider.</exception>
        public void StartTracking()
        {
            _Logger.Info("StartTracking");

            Sdk.Instance.Initialize(AppConfigFactory.FromSection("Sdk"));
            Sdk.Instance.Start();

            Sdk.Instance.OnQueueLimits += OnQueueLimits;

            if (Sdk.Instance.LiveScout != null)
            {

                //Subscribes to all events
                //Event handlers log event and pass event arguments
                //to ReferencesMerger which takes care of merging data
                Sdk.Instance.LiveScout.OnMatchList += OnMatchList;
                Sdk.Instance.LiveScout.OnMatchStop += OnMatchStop;
                Sdk.Instance.LiveScout.OnMatchUpdate += OnMatchUpdate;
                Sdk.Instance.LiveScout.OnOddsSuggestion += OnOddsSuggestion;
                Sdk.Instance.LiveScout.OnScoutInfo += OnScoutInfo;
                Sdk.Instance.LiveScout.OnFeedError += OnFeedError;
                Sdk.Instance.LiveScout.OnMatchBookingReply += OnMatchBookingReply;

                //Starts LiveScout provider
                Sdk.Instance.LiveScout.Start();
            }
            else
            {
                throw new DataProviderException("Failed to initialize LiveScout provider.");
            }
        }

        /// <summary>
        /// Stops the LiveScout provider and SDK. Also unsubscribes from all LiveScout events
        /// </summary>
        public void StopTracking()
        {
            _Logger.Info("StopTracking");

            if (Sdk.Instance.LiveScout != null)
            {
                Sdk.Instance.LiveScout.Stop();

                Sdk.Instance.LiveScout.OnMatchList -= OnMatchList;
                Sdk.Instance.LiveScout.OnMatchStop -= OnMatchStop;
                Sdk.Instance.LiveScout.OnMatchUpdate -= OnMatchUpdate;
                Sdk.Instance.LiveScout.OnOddsSuggestion -= OnOddsSuggestion;
                Sdk.Instance.LiveScout.OnScoutInfo -= OnScoutInfo;
                Sdk.Instance.LiveScout.OnFeedError -= OnFeedError;
                Sdk.Instance.LiveScout.OnMatchBookingReply -= OnMatchBookingReply;
            }

            Sdk.Instance.OnQueueLimits -= OnQueueLimits;

            Sdk.Instance.Stop();
        }

        /// <summary>
        /// Refreshes match list with available scout matches. Wraps SDK LiveScout.GetMatchList.
        /// </summary>
        public void Refresh()
        {
            Refresh(false);
        }


        /// <summary>
        /// Refreshes match list with available scout matches. Wraps SDK LiveScout.GetMatchList.
        /// </summary>
        /// <param name="includeAvailable">if set to <c>true</c> also includes matches that are open for booking</param>
        public void Refresh(bool includeAvailable)
        {
            //ReferencesMerger.Instance.ClearLoadedMatches();

            _Logger.InfoFormat("Refresh: back hrs: {0} forward hrs: {1}", 4, 8);

            Sdk.Instance.LiveScout.GetMatchList(4, 8, includeAvailable);
        }


        /// <summary>
        /// Subscribe to specified match.
        /// </summary>
        /// <param name="matchId">Match id</param>
        /// <remarks>
        /// SDK enables subscription to multiple matches at once
        /// but for the needs of GUI we only need one at once
        /// </remarks>
        public void SubscribeToMatch(long matchId)
        {
            _Logger.InfoFormat("SubscribeToMatch: matchId: {0}", matchId);

            ReferencesMerger.Instance.SubscribeMatch(matchId);
            Sdk.Instance.LiveScout.Subscribe(new long[1] { matchId });

            ReferencesMerger.Instance.MergeNotification(
                matchId,
                DateTime.Now,
                null,
                string.Format("Subscribe to match request sent for matchId: {0}", matchId));
        }

        /// <summary>
        /// Unsubscribe from specified match.
        /// </summary>
        /// <param name="matchId">Match id</param>
        /// <remarks>
        /// SDK enables unsubscription to multiple matches at once
        /// but for the needs of GUI we only need one at once
        /// Expect <see cref="MatchStop"/> message response
        /// </remarks>
        public void UnsubscribeFromMatch(long matchId)
        {
            _Logger.InfoFormat("UnsubscribeFromMatch: matchId: {0}", matchId);

            Sdk.Instance.LiveScout.Unsubscribe(new long[1] { matchId });
            ReferencesMerger.Instance.UnsubscribeMatch(matchId);

            ReferencesMerger.Instance.MergeNotification(
                matchId,
                DateTime.Now,
                null,
                string.Format("Unsubscribe to match request sent for matchId: {0}", matchId));
        }

        /// <summary>
        /// Book the specified match.
        /// </summary>
        /// <param name="matchId">Match id</param>
        /// <remarks>
        /// SDK enables booking to multiple matches at once
        /// but for the needs of GUI we only need one at once
        /// </remarks>
        /// <para>
        /// Note that booking matches will have a cost depending on the type of agreement you have with Sportradar.
        /// </para>
        public void BookMatch(long matchId)
        {
            _Logger.InfoFormat("BookMatch: matchId: {0}", matchId);
            Sdk.Instance.LiveScout.BookEvents(new long[1] { matchId });

            ReferencesMerger.Instance.MergeNotification(
                matchId,
                DateTime.Now,
                null,
                string.Format("Book match request sent for matchId: {0}", matchId));
        }

        #endregion

        #region --- Event handlers ---

        private void OnQueueLimits(object sender, QueueLimitEventArgs event_args)
        {
            _Logger.InfoFormat(
                "OnQueueLimits: queue_name {0}",
                event_args.QueueName);
        }

        private void OnScoutInfo(object sender, ScoutInfoEventArgs eventArgs)
        {
            _Logger.InfoFormat(
                "OnScoutInfo: matchId {0}",
                eventArgs.MatchId);

            // release SDK thread ASAP
            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeScoutInfo(eventArgs.MatchId, eventArgs.ScoutInfos))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);

            // release SDK thread ASAP
            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeNotification(eventArgs.MatchId, DateTime.Now, null, string.Format("Scout infos received. Count: {0}", eventArgs.ScoutInfos.Length)))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);
        }

        private void OnOddsSuggestion(object sender, OddsSuggestionEventArgs eventArgs)
        {
            _Logger.InfoFormat(
                "OnOddsSuggestion: matchId {0}",
                eventArgs.MatchId);

            // release SDK thread ASAP
            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeOddsSuggestion(eventArgs.MatchId, eventArgs.Odds))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);

            // release SDK thread ASAP
            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeNotification(eventArgs.MatchId, DateTime.Now, null, string.Format("Match odds suggestions received. Count: {0}", eventArgs.Odds.Length)))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);
        }

        private void OnMatchUpdate(object sender, MatchUpdateEventArgs eventArgs)
        {
            _Logger.InfoFormat(
                "OnMatchUpdate: matchId {0}",
                ((eventArgs.MatchUpdate == null) || (eventArgs.MatchUpdate.MatchHeader == null)) ? 0 : eventArgs.MatchUpdate.MatchHeader.MatchId);

            // release SDK thread ASAP
            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeMatchUpdate(eventArgs.MatchUpdate))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);

            // release SDK thread ASAP
            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeNotification(eventArgs.MatchUpdate.MatchHeader.MatchId, DateTime.Now, null, string.Format("Match update received. Type: {0}", eventArgs.MatchUpdate.MatchHeader.TypeOfFeed)))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);
        }

        private void OnMatchStop(object sender, MatchStopEventArgs eventArgs)
        {
            _Logger.InfoFormat(
                "OnMatchStop: match id {0}, reason {1}",
                eventArgs.MatchId, eventArgs.Reason);

            // release SDK thread ASAP
            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeMatchStop(eventArgs.MatchId, eventArgs.Reason))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);

            // release SDK thread ASAP
            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeNotification(eventArgs.MatchId, DateTime.Now, null, string.Format("Match stop received. Reason: {0}", eventArgs.Reason)))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);
        }

        private void OnMatchList(object sender, MatchListEventArgs eventArgs)
        {
            _Logger.InfoFormat(
                "OnMatchList: {0} match updates",
                (eventArgs == null) ? 0 : eventArgs.MatchList.Length);

            // release SDK thread ASAP
            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeMatchList(eventArgs.MatchList))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);

            // release SDK thread ASAP
            Task.Factory.StartNew(() =>
                {
                    List<Tuple<long, DateTime, DateTime?, string>> notifications = new List<Tuple<long, DateTime, DateTime?, string>>();

                    foreach (var match in eventArgs.MatchList)
                    {
                        notifications.Add(new Tuple<long, DateTime, DateTime?, string>(
                            match.MatchHeader.MatchId,
                            DateTime.Now,
                            null,
                            string.Format("Match listed. Type: {0}", match.MatchHeader.TypeOfFeed)));
                    }

                    foreach (var notification in notifications)
                    {
                        ReferencesMerger.Instance.MergeNotification(notification.Item1, notification.Item2, notification.Item3, notification.Item4);
                    }
                })
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);
        }

        private void OnMatchBookingReply(object sender, MatchBookingReplyEventArgs eventArgs)
        {
            _Logger.InfoFormat(
                "OnMatchBookingReply: matchId: {0}, result: {1}, msg: {2}, additionalData: {3}",
                (eventArgs == null || eventArgs.MatchBooking == null || eventArgs.MatchBooking.MatchId == null) ? "[NA]" : eventArgs.MatchBooking.MatchId.ToString(),
                (eventArgs == null || eventArgs.MatchBooking == null) ? "[NA]" : eventArgs.MatchBooking.Result.ToString(),
                (eventArgs == null || eventArgs.MatchBooking == null) ? "[NA]" : eventArgs.MatchBooking.Message,
                (eventArgs == null || eventArgs.MatchBooking == null || eventArgs.MatchBooking.AdditionalData == null) ? "[NA]" : string.Join(", ", eventArgs.MatchBooking.AdditionalData.Select(kv => string.Format("[{0} : {1}]", kv.Key, kv.Value))));

            // release SDK thread ASAP
            Task.Factory.StartNew(() => 
                {
                    long matchId = (eventArgs == null || eventArgs.MatchBooking == null || eventArgs.MatchBooking.MatchId == null) ? 0 : eventArgs.MatchBooking.MatchId.Value;

                    ReferencesMerger.Instance.MergeNotification(
                        matchId,
                        DateTime.Now,
                        null,
                        string.Format(
                            "Match book: success: {0}, msg: {1}, additionalData: {2}",
                            (eventArgs == null || eventArgs.MatchBooking == null) ? "[NA]" : eventArgs.MatchBooking.Result.ToString(),
                            (eventArgs == null || eventArgs.MatchBooking == null) ? "[NA]" : eventArgs.MatchBooking.Message,
                            (eventArgs == null || eventArgs.MatchBooking == null || eventArgs.MatchBooking.AdditionalData == null) ? "[NA]" : string.Join(", ", eventArgs.MatchBooking.AdditionalData.Select(kv => string.Format("[{0} : {1}]", kv.Key, kv.Value)))));
                })
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);

            // release SDK thread ASAP
            // hack to mark Match as booked (IsBooked == true). This information is missing in all feeds except fullfeed.
            if ((eventArgs != null) && (eventArgs.MatchBooking != null) && (eventArgs.MatchBooking.Result == BookMatchResult.VALID))
            {
                if (eventArgs.MatchBooking.MatchId == null)
                {
                    Task.Factory.StartNew(() => ChangeTracker.Instance.Refresh(true));
                }
                else
                {
                    Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeMatchAsBooked(eventArgs.MatchBooking.MatchId.Value));
                }
            }
        }

        private void OnFeedError(object sender, FeedErrorEventArgs eventArgs)
        {
            _Logger.InfoFormat(
                "OnFeedError: severity: {0}, timestamp: {1}, cause: {2}, msg: {3}",
                (eventArgs == null) ? "[NA]" : eventArgs.Severity.ToString(),
                (eventArgs == null) ? "[NA]" : eventArgs.LocalTimestamp.ToString(),
                (eventArgs == null) ? "[NA]" : eventArgs.Cause.ToString(),
                (eventArgs == null) ? "[NA]" : eventArgs.ErrorMessage);
        }


        #endregion
    }
}
