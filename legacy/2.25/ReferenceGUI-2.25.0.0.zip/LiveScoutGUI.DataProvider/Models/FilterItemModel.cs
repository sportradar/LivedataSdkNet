﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.Common;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Common;

namespace Sportradar.Demo.GUI.LiveScout.DataProvider.Models
{
    public class FilterItemModel : NotifyPropertyChanged
    {
        public FilterItemModel(long itemId, LocalizedString name)
        {
            this.Load(itemId, name);
        }

        public FilterItemModel(long itemId)
            : this(itemId, null)
        {
        }

        public void Load(long itemId, LocalizedString name)
        {
            this.ItemId = itemId;
            this.Name = name;
        }

        private long _ItemId = 0;
        private LocalizedString _Name = null;
        private bool _IsActive = true;

        public long ItemId
        {
            get { return this.GetProperty(ref this._ItemId); }
            private set { this.SetProperty(ref this._ItemId, value, "ItemId"); }
        }
        public LocalizedString Name
        {
            get { return this.GetProperty(ref this._Name); }
            private set { this.SetProperty(ref this._Name, value, "Name"); }
        }
        public bool IsActive
        {
            get { return this.GetProperty(ref this._IsActive); }
            private set { this.SetProperty(ref this._IsActive, value, "IsActive"); }
        }
    }
}