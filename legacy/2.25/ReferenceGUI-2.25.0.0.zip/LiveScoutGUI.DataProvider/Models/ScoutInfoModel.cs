﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.FeedProviders.LiveScout;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Common;
using System;

namespace Sportradar.Demo.GUI.LiveScout.DataProvider.Models
{
    public class ScoutInfoModel : NotifyPropertyChanged, IComparable<ScoutInfoModel>, IEquatable<ScoutInfoModel>
    {
        public ScoutInfoModel(ScoutInfo scoutInfo)
        {
            this.Load(scoutInfo);
        }

        public void Load(ScoutInfo scoutInfo)
        {
            if (scoutInfo == null)
            {
                throw new ArgumentNullException("scoutInfo");
            }

            this.Value = ((scoutInfo.Value == null) ? this.Value : scoutInfo.Value);
            this.Order = ((scoutInfo.Order == 0) ? this.Order : scoutInfo.Order);
            this.Link = ((scoutInfo.Link == null) ? this.Link : scoutInfo.Link);
            this.Header = ((scoutInfo.Header == null) ? this.Header : scoutInfo.Header);
        }

        private string _Value = null;
        private int _Order = 0;
        private bool? _Link = null;
        private string _Header = null;

        public string Value
        {
            get { return this.GetProperty(ref this._Value); }
            private set { this.SetProperty(ref this._Value, value, "Value"); }
        }
        public int Order
        {
            get { return this.GetProperty(ref this._Order); }
            private set { this.SetProperty(ref this._Order, value, "Order"); }
        }
        public bool? Link
        {
            get { return this.GetProperty(ref this._Link); }
            private set { this.SetProperty(ref this._Link, value, "Link"); }
        }
        public string Header
        {
            get { return this.GetProperty(ref this._Header); }
            private set { this.SetProperty(ref this._Header, value, "Header"); }
        }

        public int CompareTo(ScoutInfoModel other)
        {
            if (other == null)
            {
                return -1;
            }

            return this.Header.CompareExt(other.Header);
        }

        public bool Equals(ScoutInfoModel other)
        {
            return (this.CompareTo(other) == 0);
        }
    }
}