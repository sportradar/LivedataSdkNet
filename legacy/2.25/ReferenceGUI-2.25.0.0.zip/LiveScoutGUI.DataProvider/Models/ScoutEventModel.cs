﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.FeedProviders.Common;
using Merged::Sportradar.SDK.FeedProviders.LiveScout;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Common;
using System;

namespace Sportradar.Demo.GUI.LiveScout.DataProvider.Models
{
    public class ScoutEventModel : NotifyPropertyChanged, IComparable<ScoutEventModel>, IEquatable<ScoutEventModel>
    {
        public ScoutEventModel(ScoutEvent scoutEvent)
        {
            this.Load(scoutEvent);
        }

        public void Load(ScoutEvent scoutEvent)
        {
            if (scoutEvent == null)
            {
                throw new ArgumentNullException("scoutEvent");
            }

            this.Id = scoutEvent.Id;
            this.Type = ((scoutEvent.Type == 0) ? this.Type : scoutEvent.Type);
            this.ServerTime = ((scoutEvent.ServerTime == DateTime.MinValue) ? this.ServerTime : scoutEvent.ServerTime);
            this.Side = ((scoutEvent.Side == Team.UNDEFINED) ? this.Side : scoutEvent.Side);
            this.MatchTime = ((scoutEvent.MatchTime == null) ? this.MatchTime : scoutEvent.MatchTime);
            this.Info = ((scoutEvent.Info == null) ? this.Info : scoutEvent.Info);
            this.ExtraInfo = ((scoutEvent.ExtraInfo == null) ? this.ExtraInfo : scoutEvent.ExtraInfo);
            this.PosX = ((scoutEvent.PosX == null) ? this.PosX : scoutEvent.PosX);
            this.PosY = ((scoutEvent.PosY == null) ? this.PosY : scoutEvent.PosY);
            this.Player1Id = ((scoutEvent.Player1Id == null) ? this.Player1Id : scoutEvent.Player1Id);
            this.Player2Id = ((scoutEvent.Player2Id == null) ? this.Player2Id : scoutEvent.Player2Id);
            this.GameNumber = ((scoutEvent.GameNumber == null) ? this.GameNumber : scoutEvent.GameNumber);
            this.SetNumber = ((scoutEvent.SetNumber == null) ? this.SetNumber : scoutEvent.SetNumber);
            this.GameScore = ((scoutEvent.GameScore == null) ? this.GameScore : scoutEvent.GameScore);
            this.SetScore = ((scoutEvent.SetScore == null) ? this.SetScore : scoutEvent.SetScore);
            this.MatchScore = ((scoutEvent.MatchScore == null) ? this.MatchScore : scoutEvent.MatchScore);
            this.RemainingTimeInPeriod = ((scoutEvent.RemainingTimeInPeriod == null) ? this.RemainingTimeInPeriod : scoutEvent.RemainingTimeInPeriod);
            this.PeriodNumber = ((scoutEvent.PeriodNumber == null) ? this.PeriodNumber : scoutEvent.PeriodNumber);
            this.Automatic = ((scoutEvent.Automatic == null) ? this.Automatic : scoutEvent.Automatic);
        }

        private long _Id = 0;
        private EventType _Type = EventType.UNDEFINED;
        private DateTime _ServerTime = DateTime.MinValue;
        private Team _Side = Team.UNDEFINED;
        private string _MatchTime = null;
        private string _Info = null;
        private long? _ExtraInfo = null;
        private int? _PosX = null;
        private int? _PosY = null;
        private int? _Player1Id = null;
        private int? _Player2Id = null;
        private int? _GameNumber = null;
        private int? _SetNumber = null;
        private string _GameScore = null;
        private string _SetScore = null;
        private string _MatchScore = null;
        private string _RemainingTimeInPeriod = null;
        private int? _PeriodNumber = null;
        private int? _Automatic = null;

        public long Id
        {
            get { return this.GetProperty(ref this._Id); }
            private set { this.SetProperty(ref this._Id, value, "Id"); }
        }
        public EventType Type
        {
            get { return this.GetProperty(ref this._Type); }
            private set { this.SetProperty(ref this._Type, value, "Type"); }
        }
        public DateTime ServerTime
        {
            get { return this.GetProperty(ref this._ServerTime); }
            private set { this.SetProperty(ref this._ServerTime, value, "ServerTime"); }
        }
        public Team Side
        {
            get { return this.GetProperty(ref this._Side); }
            private set { this.SetProperty(ref this._Side, value, "Side"); }
        }
        public string MatchTime
        {
            get { return this.GetProperty(ref this._MatchTime); }
            private set { this.SetProperty(ref this._MatchTime, value, "MatchTime"); }
        }
        public string Info
        {
            get { return this.GetProperty(ref this._Info); }
            private set { this.SetProperty(ref this._Info, value, "Info"); }
        }
        public long? ExtraInfo
        {
            get { return this.GetProperty(ref this._ExtraInfo); }
            private set { this.SetProperty(ref this._ExtraInfo, value, "ExtraInfo"); }
        }
        public int? PosX
        {
            get { return this.GetProperty(ref this._PosX); }
            private set { this.SetProperty(ref this._PosX, value, "PosX"); }
        }
        public int? PosY
        {
            get { return this.GetProperty(ref this._PosY); }
            private set { this.SetProperty(ref this._PosY, value, "PosY"); }
        }
        public int? Player1Id
        {
            get { return this.GetProperty(ref this._Player1Id); }
            private set { this.SetProperty(ref this._Player1Id, value, "Player1Id"); }
        }
        public int? Player2Id
        {
            get { return this.GetProperty(ref this._Player2Id); }
            private set { this.SetProperty(ref this._Player2Id, value, "Player2Id"); }
        }
        public int? GameNumber
        {
            get { return this.GetProperty(ref this._GameNumber); }
            private set { this.SetProperty(ref this._GameNumber, value, "GameNumber"); }
        }
        public int? SetNumber
        {
            get { return this.GetProperty(ref this._SetNumber); }
            private set { this.SetProperty(ref this._SetNumber, value, "SetNumber"); }
        }
        public string GameScore
        {
            get { return this.GetProperty(ref this._GameScore); }
            private set { this.SetProperty(ref this._GameScore, value, "GameScore"); }
        }
        public string SetScore
        {
            get { return this.GetProperty(ref this._SetScore); }
            private set { this.SetProperty(ref this._SetScore, value, "SetScore"); }
        }
        public string MatchScore
        {
            get { return this.GetProperty(ref this._MatchScore); }
            private set { this.SetProperty(ref this._MatchScore, value, "MatchScore"); }
        }
        public string RemainingTimeInPeriod
        {
            get { return this.GetProperty(ref this._RemainingTimeInPeriod); }
            private set { this.SetProperty(ref this._RemainingTimeInPeriod, value, "RemainingTimeInPeriod"); }
        }
        public int? PeriodNumber
        {
            get { return this.GetProperty(ref this._PeriodNumber); }
            private set { this.SetProperty(ref this._PeriodNumber, value, "PeriodNumber"); }
        }
        public int? Automatic
        {
            get { return this.GetProperty(ref this._Automatic); }
            private set { this.SetProperty(ref this._Automatic, value, "Automatic"); }
        }

        public int CompareTo(ScoutEventModel other)
        {
            if (other == null)
            {
                return -1;
            }

            return other.Id.CompareTo(this.Id);
        }

        public bool Equals(ScoutEventModel other)
        {
            return (this.CompareTo(other) == 0);
        }
    }
}
