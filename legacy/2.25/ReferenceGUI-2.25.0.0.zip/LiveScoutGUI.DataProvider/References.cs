﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using log4net;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Sportradar.Demo.GUI.LiveScout.DataProvider
{
    /// <summary>
    /// Contains object references (kind of cache)
    /// </summary>
    public class References
    {
        private References()
        {
        }

        private readonly ILog _Logger = LogManager.GetLogger(typeof(References));

        private readonly static Lazy<References> _Instance = new Lazy<References>(() => new References(), true);

        /// <summary>
        /// Instance of <see cref="References"/> class
        /// </summary>
        public static References Instance { get { return _Instance.Value; } }

        private readonly Dictionary<long, ObservableCollection<OddsValueModel>> _OddsValuesPerMatch =
            new Dictionary<long, ObservableCollection<OddsValueModel>>();

        private readonly Dictionary<long, ObservableCollection<ScoutInfoModel>> _ScoutInfosPerMatch =
            new Dictionary<long, ObservableCollection<ScoutInfoModel>>();

        private readonly ObservableCollection<long> _SubscribedMatchIds = new ObservableCollection<long>();

        private readonly ObservableCollection<long> _LoadedMatchIds = new ObservableCollection<long>();

        private readonly Dictionary<long, MatchModel> _Matches = new Dictionary<long, MatchModel>();

        private readonly ObservableCollection<FilterItemModel> _Sports = new ObservableCollection<FilterItemModel>();

        private readonly ObservableCollection<FilterItemModel> _Categories = new ObservableCollection<FilterItemModel>();

        private readonly ObservableCollection<FilterItemModel> _Tournaments = new ObservableCollection<FilterItemModel>();

        private readonly Dictionary<long, ObservableCollection<NotificationModel>> _NotificationsPerMatch = new Dictionary<long, ObservableCollection<NotificationModel>>();

        private readonly DispatcherQueueStatsModel _DispatcherQueueStatsModel = new DispatcherQueueStatsModel();

        private readonly ServerTimeModel _ServerTimeModel = new ServerTimeModel();

        /// <summary>
        /// Dictionary of all the odds for all the matches. Key is match id
        /// </summary>
        public Dictionary<long, ObservableCollection<OddsValueModel>> OddsValuesPerMatch { get { return this._OddsValuesPerMatch; } }

        /// <summary>
        /// Dictionary of all scout infos for all the matches. Key is match id
        /// </summary>
        public Dictionary<long, ObservableCollection<ScoutInfoModel>> ScoutInfosPerMatch { get { return this._ScoutInfosPerMatch; } }

        /// <summary>
        /// Collection of matches that the user subscribed to through GUI
        /// </summary>
        public ObservableCollection<long> SubscribedMatchIds { get { return this._SubscribedMatchIds; } }

        /// <summary>
        /// Collection of matches that were received through events
        /// </summary>
        public ObservableCollection<long> LoadedMatchIds { get { return this._LoadedMatchIds; } }

        /// <summary>
        /// Dictionary of all matches. Key is match id
        /// </summary>
        public Dictionary<long, MatchModel> Matches { get { return this._Matches; } }

        /// <summary>
        /// Collection of all sport names.
        /// </summary>
        public ObservableCollection<FilterItemModel> Sports { get { return this._Sports; } }

        /// <summary>
        /// Collection of all category names.
        /// </summary>
        public ObservableCollection<FilterItemModel> Categories { get { return this._Categories; } }

        /// <summary>
        /// Collection of all tournament names.
        /// </summary>
        public ObservableCollection<FilterItemModel> Tournaments { get { return this._Tournaments; } }

        /// <summary>
        /// Dictionary of all notifications for all the matches. Key is match id
        /// </summary>
        public Dictionary<long, ObservableCollection<NotificationModel>> NotificationsPerMatch { get { return this._NotificationsPerMatch; } }

        /// <summary>
        /// Contains queues statistics
        /// </summary>
        public DispatcherQueueStatsModel DispatcherQueueStatsModel { get { return this._DispatcherQueueStatsModel; } }

        /// <summary>
        /// Server time
        /// </summary>
        public ServerTimeModel ServerTimeModel { get { return _ServerTimeModel; } }
    }
}
