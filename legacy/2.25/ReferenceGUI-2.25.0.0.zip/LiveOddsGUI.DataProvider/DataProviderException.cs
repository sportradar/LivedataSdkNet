﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider
{
    [Serializable]
    public class DataProviderException : ApplicationException, ISerializable
    {
        public DataProviderException(string message)
            : base(message)
        {
        }

        public DataProviderException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        public DataProviderException(SerializationInfo serializationInfo, StreamingContext streamingContext)
            : base(serializationInfo, streamingContext)
        {
        }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);
        }
    }
}
