﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Sportradar.Demo.GUI.LiveOdds.DataProvider")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyProduct("Sportradar.Demo.GUI.LiveOdds.DataProvider")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyCopyright("Copyright © Sportradar AG 2013")]
[assembly: AssemblyCompany("Sportradar AG")]
[assembly: AssemblyVersion("2.25.0.0")]
[assembly: AssemblyFileVersion("2.25.0.0")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("eee990df-a7ce-4726-b069-544f904765c0")]
