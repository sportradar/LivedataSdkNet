﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Enums
{
    public enum NotificationType
    {
        UNKNOWN,
        Error,
        Alive,
        QueueLimitRetreated,
        QueueLimitReached,
        ScoreCardSummary,
        MetaInfo,
        BetStart,
        BetStop, 
        BetClear,
        BetClearRollback,
        BetCancel,
        BetCancelUndo,
        OddsChange, 

    }
}
