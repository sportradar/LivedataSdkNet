﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;

namespace Sportradar.Demo.GUI.LiveOdds.Common
{
    public class LanguagesHandler : NotifyPropertyChanged
    {
        public LanguagesHandler(string currentLanguage, string[] allLanguages) :this()
        {
            this.CurrentLanguage = currentLanguage;
            this.AllLanguages.AddRange(allLanguages);
        }

        public LanguagesHandler()
        {
            _AllLanguages = new ImprovedObservableCollection<string>();
            AllLanguages.Add("International");
        }

        private ImprovedObservableCollection<string> _AllLanguages;

        private string _CurrentLanguage;

        public ImprovedObservableCollection<string> AllLanguages
        {
            get { return GetProperty<ImprovedObservableCollection<string>>(ref this._AllLanguages); }
        }


        public string CurrentLanguage
        {
            get { return GetProperty(ref this._CurrentLanguage); }
            set { SetProperty(ref this._CurrentLanguage, value, "CurrentLanguage"); }
        }
    }
}
