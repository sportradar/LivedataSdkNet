﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Common
{
    /// <summary>
    /// Stores last and second to last update 
    /// </summary>
    public class ChangeTimestamp
    {
        public DateTime PreviousChange { get; private set; }
        public DateTime CurrentChange { get; private set; }

        public void SetLastChange(DateTime dateTime)
        {
            this.PreviousChange = this.CurrentChange;
            this.CurrentChange = dateTime;
        }
    }
}
