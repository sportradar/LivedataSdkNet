﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.Common;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using System;
using System.Collections.ObjectModel;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Models
{
    public class MatchHeaderModel : NotifyPropertyChanged, IComparable<MatchHeaderModel>, IEquatable<MatchHeaderModel>
    {
        public MatchHeaderModel(long matchId)
        {
            this.MatchId = matchId;
        }

        public MatchHeaderModel(MatchHeader matchHeader)
        {
            if(matchHeader!=null)this.Load(matchHeader);
        }

        public void Load(MatchHeader matchHeader)
        {
            if (matchHeader == null)
            {
                throw new ArgumentNullException("matchHeader");
            }

            this.Active = matchHeader.Active;
            this.AwayBatter = (matchHeader.Batter == null || matchHeader.Batter.Team2 == null) ? this.AwayBatter : matchHeader.Batter.Team2;
            this.Balls = (matchHeader.Balls == null) ? this.Balls : matchHeader.Balls;
            this.Bases = (matchHeader.Bases == null) ? this.Bases : matchHeader.Bases;
            this.BetStatus = (matchHeader.BetStatus == null) ? this.BetStatus : matchHeader.BetStatus;
            this.Booked = (matchHeader.Booked == null) ? this.Booked : matchHeader.Booked;
            this.ClearedScore = (matchHeader.ClearedScore == null) ? this.ClearedScore : matchHeader.ClearedScore;
            this.ClockStopped = (matchHeader.ClockStopped == null) ? this.ClockStopped : matchHeader.ClockStopped;
            this.CornersAway = (matchHeader.Corners==null || matchHeader.Corners.Team2 == null) ? this.CornersAway : matchHeader.Corners.Team2;
            this.CornersHome = (matchHeader.Corners == null || matchHeader.Corners.Team1 == null) ? this.CornersHome : matchHeader.Corners.Team1;
            this.EarlyBetStatus = (matchHeader.EarlyBetStatus == null) ? this.EarlyBetStatus : matchHeader.EarlyBetStatus;
            this.GameScore = (matchHeader.GameScore == null) ? this.GameScore : matchHeader.GameScore;
            this.HomeBatter = (matchHeader.Batter == null || matchHeader.Batter.Team1 == null) ? this.HomeBatter : matchHeader.Batter.Team1;
            this.MatchId = (matchHeader.Id == 0) ? this.MatchId : matchHeader.Id;
            this.MatchTime = (matchHeader.MatchTime == null) ? this.MatchTime : matchHeader.MatchTime;
            this.Msgnr = (matchHeader.Msgnr == null) ? this.Msgnr : matchHeader.Msgnr;
            this.Outs = (matchHeader.Outs == null) ? this.Outs : matchHeader.Outs;
            this.RedCardsAway = (matchHeader.RedCards == null || matchHeader.RedCards.Team2 == null) ? this.RedCardsAway : matchHeader.RedCards.Team2;
            this.RedCardsHome = (matchHeader.RedCards == null || matchHeader.RedCards.Team1 == null) ? this.RedCardsHome : matchHeader.RedCards.Team1;
            this.RemainingTime = (matchHeader.RemainingTime == null) ? this.RemainingTime : matchHeader.RemainingTime;
            this.RemainingTimeInPeriod = (matchHeader.RemainingTimeInPeriod == null) ? this.RemainingTimeInPeriod : matchHeader.RemainingTimeInPeriod;
            this.Score = (matchHeader.Score == null) ? this.Score : matchHeader.Score;
            this.Server = (matchHeader.Server == null) ? this.Server : matchHeader.Server;
            this.SourceId = (matchHeader.SourceId == null) ? this.SourceId : matchHeader.SourceId;
            this.Status = (matchHeader.Status == EventStatus.UNDEFINED) ? this.Status : matchHeader.Status;
            this.Strikes = (matchHeader.Strikes == null) ? this.Strikes : matchHeader.Strikes;
            this.SuspendAway = (matchHeader.Suspend == null || matchHeader.Suspend.Team2 == null) ? this.SuspendAway : matchHeader.Suspend.Team2;
            this.SuspendHome = (matchHeader.Suspend == null || matchHeader.Suspend.Team1 == null) ? this.SuspendHome : matchHeader.Suspend.Team1;
            this.TieBreak = (matchHeader.TieBreak == null) ? this.TieBreak : matchHeader.TieBreak;
            this.YellowCardsAway = (matchHeader.YellowCards == null || matchHeader.YellowCards.Team2 == null) ? this.YellowCardsAway : matchHeader.YellowCards.Team2;
            this.YellowCardsHome = (matchHeader.YellowCards == null || matchHeader.YellowCards.Team1 == null) ? this.YellowCardsHome : matchHeader.YellowCards.Team1;
            this.YellowRedCardsAway = (matchHeader.YellowRedCards == null || matchHeader.YellowRedCards.Team2 == null) ? this.YellowRedCardsAway : matchHeader.YellowRedCards.Team2;
            this.YellowRedCardsHome = (matchHeader.YellowRedCards == null || matchHeader.YellowRedCards.Team1 == null) ? this.YellowRedCardsHome : matchHeader.YellowRedCards.Team1;

            this.Message.Clear();
            foreach (var msg in matchHeader.Message ?? new string[0])
            {
                this.Message.Add(msg);
            }
            this.SetScores.Clear();
            foreach (var setScore in matchHeader.SetScores ?? new string[0])
            {
                this.SetScores.Add(setScore);
            }
        }

        private bool _Active = false;
        private int? _AwayBatter = null;
        private int? _Balls = null;
        private string _Bases = null;
        private EventBetStatus? _BetStatus = null;
        private bool? _Booked = null;
        private string _ClearedScore = null;
        private bool? _ClockStopped = null;
        private int? _CornersAway = null;
        private int? _CornersHome = null;
        private OddsMatchEarlyBetStatus? _EarlyBetStatus = null;
        private string _GameScore = null;
        private int? _HomeBatter = null;
        private long _MatchId = 0;
        private long? _MatchTime = null;
        private ObservableCollection<string> _Message = new ObservableCollection<string>();
        private long? _Msgnr = null;
        private int? _Outs = null;
        private int? _RedCardsAway = null;
        private int? _RedCardsHome = null;
        private string _RemainingTime = null;
        private string _RemainingTimeInPeriod = null;
        private string _Score = null;
        private int? _Server = null;
        private ObservableCollection<string> _SetScores = new ObservableCollection<string>();
        private string _SourceId = null;
        private EventStatus _Status = EventStatus.UNDEFINED;
        private int? _Strikes = null;
        private int? _SuspendAway = null;
        private int? _SuspendHome = null;
        private bool? _TieBreak = null;
        private int? _YellowCardsAway = null;
        private int? _YellowCardsHome = null;
        private int? _YellowRedCardsAway = null;
        private int? _YellowRedCardsHome = null;

        public bool Active
        {
            get { return this.GetProperty(ref this._Active); }
            private set { this.SetProperty(ref this._Active, value, "Active"); }
        }
        public int? AwayBatter
        {
            get { return this.GetProperty(ref this._AwayBatter); }
            private set { this.SetProperty(ref this._AwayBatter, value, "AwayBatter"); }
        }
        public int? Balls
        {
            get { return this.GetProperty(ref this._Balls); }
            private set { this.SetProperty(ref this._Balls, value, "Balls"); }
        }
        public string Bases
        {
            get { return this.GetProperty(ref this._Bases); }
            private set { this.SetProperty(ref this._Bases, value, "Bases"); }
        }
        public EventBetStatus? BetStatus
        {
            get { return this.GetProperty(ref this._BetStatus); }
            private set { this.SetProperty(ref this._BetStatus, value, "BetStatus"); }
        }
        public bool? Booked
        {
            get { return this.GetProperty(ref this._Booked); }
            private set { this.SetProperty(ref this._Booked, value, "Booked"); }
        }
        public string ClearedScore
        {
            get { return this.GetProperty(ref this._ClearedScore); }
            private set { this.SetProperty(ref this._ClearedScore, value, "ClearedScore"); }
        }
        public bool? ClockStopped
        {
            get { return this.GetProperty(ref this._ClockStopped); }
            private set { this.SetProperty(ref this._ClockStopped, value, "ClockStopped"); }
        }
        public int? CornersAway
        {
            get { return this.GetProperty(ref this._CornersAway); }
            private set { this.SetProperty(ref this._CornersAway, value, "CornersAway"); }
        }
        public int? CornersHome
        {
            get { return this.GetProperty(ref this._CornersHome); }
            private set { this.SetProperty(ref this._CornersHome, value, "CornersHome"); }
        }
        public OddsMatchEarlyBetStatus? EarlyBetStatus
        {
            get { return this.GetProperty(ref this._EarlyBetStatus); }
            private set { this.SetProperty(ref this._EarlyBetStatus, value, "EarlyBetStatus"); }
        }
        public string GameScore
        {
            get { return this.GetProperty(ref this._GameScore); }
            private set { this.SetProperty(ref this._GameScore, value, "GameScore"); }
        }
        public int? HomeBatter
        {
            get { return this.GetProperty(ref this._HomeBatter); }
            private set { this.SetProperty(ref this._HomeBatter, value, "HomeBatter"); }
        }
        public long MatchId
        {
            get { return this.GetProperty(ref this._MatchId); }
            private set { this.SetProperty(ref this._MatchId, value, "MatchId"); }
        }
        public long? MatchTime
        {
            get { return this.GetProperty(ref this._MatchTime); }
            private set { this.SetProperty(ref this._MatchTime, value, "MatchTime"); }
        }
        public ObservableCollection<string> Message
        {
            get { return this.GetProperty<ObservableCollection<string>>(ref this._Message); }
        }
        public long? Msgnr
        {
            get { return this.GetProperty(ref this._Msgnr); }
            private set { this.SetProperty(ref this._Msgnr, value, "Msgnr"); }
        }
        public int? Outs
        {
            get { return this.GetProperty(ref this._Outs); }
            private set { this.SetProperty(ref this._Outs, value, "Outs"); }
        }
        public int? RedCardsAway
        {
            get { return this.GetProperty(ref this._RedCardsAway); }
            private set { this.SetProperty(ref this._RedCardsAway, value, "RedCardsAway"); }
        }
        public int? RedCardsHome
        {
            get { return this.GetProperty(ref this._RedCardsHome); }
            private set { this.SetProperty(ref this._RedCardsHome, value, "RedCardsHome"); }
        }
        public string RemainingTime
        {
            get { return this.GetProperty(ref this._RemainingTime); }
            private set { this.SetProperty(ref this._RemainingTime, value, "RemainingTime"); }
        }
        public string RemainingTimeInPeriod
        {
            get { return this.GetProperty(ref this._RemainingTimeInPeriod); }
            private set { this.SetProperty(ref this._RemainingTimeInPeriod, value, "RemainingTimeInPeriod"); }
        }
        public string Score
        {
            get { return this.GetProperty(ref this._Score); }
            private set { this.SetProperty(ref this._Score, value, "Score"); }
        }
        public int? Server
        {
            get { return this.GetProperty(ref this._Server); }
            private set { this.SetProperty(ref this._Server, value, "Server"); }
        }
        public ObservableCollection<string> SetScores
        {
            get { return this.GetProperty<ObservableCollection<string>>(ref this._SetScores); }
        }
        public string SourceId
        {
            get { return this.GetProperty(ref this._SourceId); }
            private set { this.SetProperty(ref this._SourceId, value, "SourceId"); }
        }
        public EventStatus Status
        {
            get { return this.GetProperty(ref this._Status); }
            private set { this.SetProperty(ref this._Status, value, "Status"); }
        }
        public int? Strikes
        {
            get { return this.GetProperty(ref this._Strikes); }
            private set { this.SetProperty(ref this._Strikes, value, "Strikes"); }
        }
        public int? SuspendAway
        {
            get { return this.GetProperty(ref this._SuspendAway); }
            private set { this.SetProperty(ref this._SuspendAway, value, "SuspendAway"); }
        }
        public int? SuspendHome
        {
            get { return this.GetProperty(ref this._SuspendHome); }
            private set { this.SetProperty(ref this._SuspendHome, value, "SuspendHome"); }
        }
        public bool? TieBreak
        {
            get { return this.GetProperty(ref this._TieBreak); }
            private set { this.SetProperty(ref this._TieBreak, value, "TieBreak"); }
        }
        public int? YellowCardsAway
        {
            get { return this.GetProperty(ref this._YellowCardsAway); }
            private set { this.SetProperty(ref this._YellowCardsAway, value, "YellowCardsAway"); }
        }
        public int? YellowCardsHome
        {
            get { return this.GetProperty(ref this._YellowCardsHome); }
            private set { this.SetProperty(ref this._YellowCardsHome, value, "YellowCardsHome"); }
        }
        public int? YellowRedCardsAway
        {
            get { return this.GetProperty(ref this._YellowRedCardsAway); }
            private set { this.SetProperty(ref this._YellowRedCardsAway, value, "YellowRedCardsAway"); }
        }
        public int? YellowRedCardsHome
        {
            get { return this.GetProperty(ref this._YellowRedCardsHome); }
            private set { this.SetProperty(ref this._YellowRedCardsHome, value, "YellowRedCardsHome"); }
        }

        public bool Equals(MatchHeaderModel other)
        {
            return (this.CompareTo(other) == 0);
        }

        public int CompareTo(MatchHeaderModel other)
        {
            throw new NotImplementedException();
        }
    }
}
