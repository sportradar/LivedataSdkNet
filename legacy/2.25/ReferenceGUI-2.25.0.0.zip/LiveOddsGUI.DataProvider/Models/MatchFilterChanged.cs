﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using System.ComponentModel;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Models
{
    public class MatchFilterChanged : NotifyPropertyChanged
    {
        public void Notify(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "IsChecked")
            {
                this.OnPropertyChanged("");
            }
        }
    }
}
