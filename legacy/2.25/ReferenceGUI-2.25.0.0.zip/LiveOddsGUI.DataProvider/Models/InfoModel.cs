﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.Common;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using System;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Models
{
    public class InfoModel : NotifyPropertyChanged, IComparable<InfoModel>, IEquatable<InfoModel>
    {
        public InfoModel(ExtraMatchInfo info)
        {
            this.Load(info);
        }

        public void Load(ExtraMatchInfo info)
        {
            if (info == null)
            {
                throw new ArgumentNullException("info");
            }

            this.Type = (info.Type == null) ? this.Type : info.Type;
            this.Value = (info.Value == null) ? this.Value : info.Value;
        }

        private string _Type = null;
        private string _Value = null;

        public string Type
        {
            get { return this.GetProperty(ref this._Type); }
            private set { this.SetProperty(ref this._Type, value, "Type"); }
        }
        public string Value
        {
            get { return this.GetProperty(ref this._Value); }
            private set { this.SetProperty(ref this._Value, value, "Value"); }
        }

        public bool Equals(InfoModel other)
        {
            return (this.CompareTo(other) == 0);
        }

        public int CompareTo(InfoModel other)
        {
            return -1;
        }
    }
}
