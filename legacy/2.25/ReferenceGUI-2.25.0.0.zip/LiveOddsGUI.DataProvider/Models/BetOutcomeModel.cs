﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;

namespace Sportradar.Demo.GUI.LiveOdds.Models
{
    public class BetOutcomeModel : NotifyPropertyChanged
    {
        private string _Type;
        private LocalizedString _Translation;

        public BetOutcomeModel(BetOutcome betOutcome)
        {
            _Translation = betOutcome.Translation;
            _Type = betOutcome.Type;
        }


        public LocalizedString Translation
        {
            get { return this.GetProperty(ref this._Translation); }
            private set { this.SetProperty(ref this._Translation, value, "Translation"); }
        }

        public string Type
        {
            get { return this.GetProperty(ref this._Type); }
            private set { this.SetProperty(ref this._Type, value, "Type"); }
        }

    }
}
