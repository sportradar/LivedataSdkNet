﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using Merged::Sportradar.SDK.Services.QueueStats;
using System;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Models
{
    public class CollectedQueueStatsModel : NotifyPropertyChanged
    {
        public CollectedQueueStatsModel()
        {
        }

        public CollectedQueueStatsModel(ClientQueueStats stats)
        {
            this.Load(stats);
        }

        public void Load(ClientQueueStats stats)
        {
            if (stats == null)
            {
                throw new ArgumentNullException("stats");
            }

            this.QueueName = ((stats.QueueName == null) ? this.QueueName : stats.QueueName);
            if (stats.DailyStats != null)
            {
                this._DailyStats.Load(stats.DailyStats);
            }
            if (stats.HourlyStats != null)
            {
                this._HourlyStats.Load(stats.HourlyStats);
            }
            if (stats.MinutelyStats != null)
            {
                this._MinutelyStats.Load(stats.MinutelyStats);
            }
            if (stats.TotalStats != null)
            {
                this._TotalStats.Load(stats.TotalStats);
            }
            if (stats.PrevDailyStats != null)
            {
                this._PrevDailyStats.Load(stats.PrevDailyStats);
            }
            if (stats.PrevHourlyStats != null)
            {
                this._PrevHourlyStats.Load(stats.PrevHourlyStats);
            }
            if (stats.PrevMinutelyStats != null)
            {
                this._PrevMinutelyStats.Load(stats.PrevMinutelyStats);
            }
        }

        private string _QueueName = null;
        private QueueStatsModel _MinutelyStats = new QueueStatsModel();
        private QueueStatsModel _HourlyStats = new QueueStatsModel();
        private QueueStatsModel _DailyStats = new QueueStatsModel();
        private QueueStatsModel _TotalStats = new QueueStatsModel();
        private QueueStatsModel _PrevMinutelyStats = new QueueStatsModel();
        private QueueStatsModel _PrevHourlyStats = new QueueStatsModel();
        private QueueStatsModel _PrevDailyStats = new QueueStatsModel();

        public string QueueName
        {
            get { return this.GetProperty(ref this._QueueName); }
            private set { this.SetProperty(ref this._QueueName, value, "QueueName"); }
        }
        public QueueStatsModel MinutelyStats
        {
            get { return this.GetProperty(ref this._MinutelyStats); }
        }
        public QueueStatsModel HourlyStats
        {
            get { return this.GetProperty(ref this._HourlyStats); }
        }
        public QueueStatsModel DailyStats
        {
            get { return this.GetProperty(ref this._DailyStats); }
        }
        public QueueStatsModel TotalStats
        {
            get { return this.GetProperty(ref this._TotalStats); }
        }
        public QueueStatsModel PrevMinutelyStats
        {
            get { return this.GetProperty(ref this._PrevMinutelyStats); }
        }
        public QueueStatsModel PrevHourlyStats
        {
            get { return this.GetProperty(ref this._PrevHourlyStats); }
        }
        public QueueStatsModel PrevDailyStats
        {
            get { return this.GetProperty(ref this._PrevDailyStats); }
        }
    }
}
