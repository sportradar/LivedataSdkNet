﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.Common;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.Common;
using System;
using System.Collections.ObjectModel;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Models.Base
{
    public abstract class OddsEntityBaseModel : EntityBaseModel
    {
        protected void Load(OddsEntityBase oddsEntityBase)
        {
            if (oddsEntityBase == null)
            {
                throw new ArgumentNullException("oddsEntityBase");
            }

            this.Load(oddsEntityBase as EntityBase);

            this.Msgnr = (oddsEntityBase.Msgnr == null) ? this.Msgnr : oddsEntityBase.Msgnr;
            this.ReplyNr = (oddsEntityBase.ReplyNr == null) ? this.ReplyNr : oddsEntityBase.ReplyNr;
            this.ReplyType = (oddsEntityBase.ReplyType == null) ? this.ReplyType : oddsEntityBase.ReplyType;
            this.ServerType = (oddsEntityBase.ServerType == null) ? this.ServerType : oddsEntityBase.ServerType;
            this.Time = (oddsEntityBase.Time == null) ? this.Time : oddsEntityBase.Time;
            this.Timestamp = (oddsEntityBase.Timestamp == DateTime.MinValue) ? this.Timestamp : oddsEntityBase.Timestamp;

            this.Messages.Clear();
            foreach (var msg in oddsEntityBase.Messages ?? new string[0])
            {
                this.Messages.Add(msg);
            }
        }

        private bool? _MatchActive = null;
        private ObservableCollection<string> _Messages = new ObservableCollection<string>();
        private long? _Msgnr = null;
        private long? _ReplyNr = null;
        private OddsReplyType? _ReplyType = null;
        private OddsServerType? _ServerType = null;
        private long? _Time = null;
        private DateTime _Timestamp = DateTime.MinValue;

        public ObservableCollection<string> Messages
        {
            get { return this.GetProperty<ObservableCollection<string>>(ref this._Messages); }
        }
        public long? Msgnr
        {
            get { return this.GetProperty(ref this._Msgnr); }
            private set { this.SetProperty(ref this._Msgnr, value, "Msgnr"); }
        }
        public long? ReplyNr
        {
            get { return this.GetProperty(ref this._ReplyNr); }
            private set { this.SetProperty(ref this._ReplyNr, value, "ReplyNr"); }
        }
        public OddsReplyType? ReplyType
        {
            get { return this.GetProperty(ref this._ReplyType); }
            private set { this.SetProperty(ref this._ReplyType, value, "ReplyType"); }
        }
        public OddsServerType? ServerType
        {
            get { return this.GetProperty(ref this._ServerType); }
            private set { this.SetProperty(ref this._ServerType, value, "ServerType"); }
        }
        public long? Time
        {
            get { return this.GetProperty(ref this._Time); }
            private set { this.SetProperty(ref this._Time, value, "Time"); }
        }
        public DateTime Timestamp
        {
            get { return this.GetProperty(ref this._Timestamp); }
            private set { this.SetProperty(ref this._Timestamp, value, "Timestamp"); }
        }
    }
}