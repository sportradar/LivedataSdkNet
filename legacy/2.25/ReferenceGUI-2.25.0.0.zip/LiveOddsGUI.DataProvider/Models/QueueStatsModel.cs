﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.Common;
using Merged::Sportradar.SDK.Services.QueueStats;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using System;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Models
{
    public class QueueStatsModel : NotifyPropertyChanged
    {
        public QueueStatsModel()
        {
        }

        public QueueStatsModel(QueueStats stats)
        {
            this.Load(stats);
        }

        public void Load(QueueStats stats)
        {
            if (stats == null)
            {
                throw new ArgumentNullException("stats");
            }

            this.QueueName = ((stats.QueueName == null) ? this.QueueName : stats.QueueName);
            this.Description = ((stats.Description == null) ? this.Description : stats.Description);
            this.MinItemsInQueue = ((stats.ItemsInQueue.Min == null) ? this.MinItemsInQueue : stats.ItemsInQueue.Min);
            this.AvgItemsInQueue = ((stats.ItemsInQueue.Avg == null) ? this.AvgItemsInQueue : stats.ItemsInQueue.Avg);
            this.MaxItemsInQueue = ((stats.ItemsInQueue.Max == null) ? this.MaxItemsInQueue : stats.ItemsInQueue.Max);
            this.MinTimeInQueue = ((stats.TimeInQueue.Min == null) ? this.MinTimeInQueue : stats.TimeInQueue.Min);
            this.AvgTimeInQueue = ((stats.TimeInQueue.Avg == null) ? this.AvgTimeInQueue : stats.TimeInQueue.Avg);
            this.MaxTimeInQueue = ((stats.TimeInQueue.Max == null) ? this.MaxTimeInQueue : stats.TimeInQueue.Max);
            this.MinTimeToProcess = ((stats.TimeToProcess.Min == null) ? this.MinTimeToProcess : stats.TimeToProcess.Min);
            this.AvgTimeToProcess = ((stats.TimeToProcess.Avg == null) ? this.AvgTimeToProcess : stats.TimeToProcess.Avg);
            this.MaxTimeToProcess = ((stats.TimeToProcess.Max == null) ? this.MaxTimeToProcess : stats.TimeToProcess.Max);
            this.AvgEnqueueRate = ((stats.AvgEnqueueRate == null) ? this.AvgEnqueueRate : stats.AvgEnqueueRate);
            this.AvgDequeueRate = ((stats.AvgDequeueRate == null) ? this.AvgDequeueRate : stats.AvgDequeueRate);
            this.TotalDropped = ((stats.TotalDropped == 0) ? this.TotalDropped : stats.TotalDropped);
            this.TotalEnqueued = ((stats.TotalEnqueued == 0) ? this.TotalEnqueued : stats.TotalEnqueued);
            this.TotalDequeued = ((stats.TotalDequeued == 0) ? this.TotalDequeued : stats.TotalDequeued);
            this.TotalDequeued = ((stats.TotalDequeued == 0) ? this.TotalDequeued : stats.TotalDequeued);
            this.CreatedOn = ((stats.CreatedOn == DateTime.MinValue) ? this.CreatedOn : stats.CreatedOn);
        }

        private string _QueueName = null;
        private string _Description = null;
        private long? _MinItemsInQueue = null;
        private long? _AvgItemsInQueue = null;
        private long? _MaxItemsInQueue = null;
        private TimeSpan? _MinTimeInQueue = null;
        private TimeSpan? _AvgTimeInQueue = null;
        private TimeSpan? _MaxTimeInQueue = null;
        private TimeSpan? _MinTimeToProcess = null;
        private TimeSpan? _AvgTimeToProcess = null;
        private TimeSpan? _MaxTimeToProcess = null;
        private double? _AvgEnqueueRate = null;
        private double? _AvgDequeueRate = null;
        private long _TotalDropped = 0;
        private long _TotalEnqueued = 0;
        private long _TotalDequeued = 0;
        private DateTime _CreatedOn = DateTime.MinValue;

        public string QueueName
        {
            get { return this.GetProperty(ref this._QueueName); }
            private set { this.SetProperty(ref this._QueueName, value, "QueueName"); }
        }
        public string Description
        {
            get { return this.GetProperty(ref this._Description); }
            private set { this.SetProperty(ref this._Description, value, "Description"); }
        }
        public long? MinItemsInQueue
        {
            get { return this.GetProperty(ref this._MinItemsInQueue); }
            private set { this.SetProperty(ref this._MinItemsInQueue, value, "MinItemsInQueue"); }
        }
        public long? AvgItemsInQueue
        {
            get { return this.GetProperty(ref this._AvgItemsInQueue); }
            private set { this.SetProperty(ref this._AvgItemsInQueue, value, "AvgItemsInQueue"); }
        }
        public long? MaxItemsInQueue
        {
            get { return this.GetProperty(ref this._MaxItemsInQueue); }
            private set { this.SetProperty(ref this._MaxItemsInQueue, value, "MaxItemsInQueue"); }
        }
        public TimeSpan? MinTimeInQueue
        {
            get { return this.GetProperty(ref this._MinTimeInQueue); }
            private set { this.SetProperty(ref this._MinTimeInQueue, value, "MinTimeInQueue"); }
        }
        public TimeSpan? AvgTimeInQueue
        {
            get { return this.GetProperty(ref this._AvgTimeInQueue); }
            private set { this.SetProperty(ref this._AvgTimeInQueue, value, "AvgTimeInQueue"); }
        }
        public TimeSpan? MaxTimeInQueue
        {
            get { return this.GetProperty(ref this._MaxTimeInQueue); }
            private set { this.SetProperty(ref this._MaxTimeInQueue, value, "MaxTimeInQueue"); }
        }
        public TimeSpan? MinTimeToProcess
        {
            get { return this.GetProperty(ref this._MinTimeToProcess); }
            private set { this.SetProperty(ref this._MinTimeToProcess, value, "MinTimeToProcess"); }
        }
        public TimeSpan? AvgTimeToProcess
        {
            get { return this.GetProperty(ref this._AvgTimeToProcess); }
            private set { this.SetProperty(ref this._AvgTimeToProcess, value, "AvgTimeToProcess"); }
        }
        public TimeSpan? MaxTimeToProcess
        {
            get { return this.GetProperty(ref this._MaxTimeToProcess); }
            private set { this.SetProperty(ref this._MaxTimeToProcess, value, "MaxTimeToProcess"); }
        }
        public double? AvgEnqueueRate
        {
            get { return this.GetProperty(ref this._AvgEnqueueRate); }
            private set { this.SetProperty(ref this._AvgEnqueueRate, value, "AvgEnqueueRate"); }
        }
        public double? AvgDequeueRate
        {
            get { return this.GetProperty(ref this._AvgDequeueRate); }
            private set { this.SetProperty(ref this._AvgDequeueRate, value, "AvgDequeueRate"); }
        }
        public long TotalDropped
        {
            get { return this.GetProperty(ref this._TotalDropped); }
            private set { this.SetProperty(ref this._TotalDropped, value, "TotalDropped"); }
        }
        public long TotalEnqueued
        {
            get { return this.GetProperty(ref this._TotalEnqueued); }
            private set { this.SetProperty(ref this._TotalEnqueued, value, "TotalEnqueued"); }
        }
        public long TotalDequeued
        {
            get { return this.GetProperty(ref this._TotalDequeued); }
            private set { this.SetProperty(ref this._TotalDequeued, value, "TotalDequeued"); }
        }
        public DateTime CreatedOn
        {
            get { return this.GetProperty(ref this._CreatedOn); }
            private set { this.SetProperty(ref this._CreatedOn, value, "CreatedOn"); }
        }
    }
}
