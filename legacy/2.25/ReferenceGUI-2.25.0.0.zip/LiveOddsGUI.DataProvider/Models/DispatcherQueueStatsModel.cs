﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using System;
using System.Collections.Generic;
using System.Linq;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Models
{
    public class DispatcherQueueStatsModel : NotifyPropertyChanged
    {
        public DispatcherQueueStatsModel()
        {
        }

        public DispatcherQueueStatsModel(IList<Merged::Sportradar.SDK.Services.QueueStats.ClientQueueStats> stats)
        {
            this.Load(stats);
        }

        public void Load(IEnumerable<Merged::Sportradar.SDK.Services.QueueStats.ClientQueueStats> stats)
        {
            if (stats == null)
            {
                throw new ArgumentNullException("stats");
            }

            foreach (var queueStats in stats.Where(s => stats != null))
            {
                var foundQueueStats = this._Queues.FirstOrDefault(s => s.QueueName == queueStats.QueueName);
                if (foundQueueStats == null)
                {
                    this._Queues.Add(new CollectedQueueStatsModel(queueStats));
                }
                else
                {
                    foundQueueStats.Load(queueStats);
                }
            }
        }

        private readonly ImprovedObservableCollection<CollectedQueueStatsModel> _Queues = new ImprovedObservableCollection<CollectedQueueStatsModel>();

        public ImprovedObservableCollection<CollectedQueueStatsModel> Queues
        {
            get { return this._Queues; }
        }
    }
}
