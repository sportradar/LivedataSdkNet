﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using System;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Models
{
    public class CardEntryModel : Base.CardEntryModel, IComparable<CardEntryModel>, IEquatable<CardEntryModel>
    {
        public CardEntryModel(CardEntry cardEntry)
        {
            this.Load(cardEntry);
        }

        public void Load(CardEntry cardEntry)
        {
            if (cardEntry == null)
            {
                throw new ArgumentNullException("cardEntry");
            }

            this.Load(cardEntry as BaseScoreCardEntry);

            this.Type = cardEntry.Type;
        }

        private Card _Type = 0;

        public Card Type
        {
            get { return this.GetProperty(ref this._Type); }
            private set { this.SetProperty(ref this._Type, value, "Type"); }
        }

        public bool Equals(CardEntryModel other)
        {
            return (this.CompareTo(other) == 0);
        }

        public int CompareTo(CardEntryModel other)
        {
            if (other == null)
            {
                return -1;
            }
            else
            {
                int result = this.Time.CompareTo(other.Time);
                if (result != 0)
                {
                    return result;
                }
                if (this.Id.HasValue && other.Id.HasValue)
                {
                    return this.Id.Value.CompareTo(other.Id.Value);
                }
                else if (this.Id.HasValue)
                {
                    return -1;
                }
                else if (other.Id.HasValue)
                {
                    return 1;
                }
                result = this.AffectedTeam.CompareTo(other.AffectedTeam);
                if (result != 0)
                {
                    return result;
                }
                result = this.AffectedPlayer.CompareExt(other.AffectedPlayer);
                if (result != 0)
                {
                    return result;
                }
                result = this.Type.CompareTo(other.Type);
                if (result != 0)
                {
                    return result;
                }

                return this.Cancelled.CompareTo(other.Cancelled);
            }
        }
    }
}
