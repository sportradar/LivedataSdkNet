﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.Common;
using Sportradar.Demo.GUI.LiveOdds.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Models
{
    public class MatchOddsModel : NotifyPropertyChanged, IComparable<MatchOddsModel>, IEquatable<MatchOddsModel>
    {
        public MatchOddsModel(EventOdds matchOdds)
        {
            this.Load(matchOdds);
        }

        public void Load(EventOdds matchOdds)
        {
            if (matchOdds == null)
            {
                throw new ArgumentNullException("matchOdds");
            }

            this.Active = matchOdds.Active;
            this._BetValue = new BetValueModel(matchOdds.Name, matchOdds.OddsFields);
            this.Changed = (matchOdds.Changed == null) ? this.Changed : matchOdds.Changed;
            this.Combination = matchOdds.Combination;
            this.FreeText = (matchOdds.Name == null) ? this.FreeText : matchOdds.Name.International;
            this.Id = matchOdds.Id;
            this.MostBalanced = (matchOdds.MostBalanced == null) ? this.MostBalanced : matchOdds.MostBalanced;
            this.SpecialOddsValue = (matchOdds.SpecialOddsValue == null) ? this.SpecialOddsValue : matchOdds.SpecialOddsValue;
            this.SubType = (matchOdds.SubType == null) ? this.SubType : matchOdds.SubType;
            this.Type = matchOdds.Type;
            this.TypeId = matchOdds.TypeId;

            foreach (var entry in matchOdds.OddsFields ?? new Dictionary<string, EventOddsField>())
            {
                var oddsFieldValueModel = this.OddsFields.SingleOrDefault(ofvm => ofvm.Key == entry.Key);
                if (oddsFieldValueModel == null)
                {
                    this.OddsFields.Add(new OddsFieldValueModel(entry.Key, entry.Value));
                }
                else
                {
                    oddsFieldValueModel.Load(entry.Value);
                }
            }
        }

        private bool _Active = false;
        private BetValueModel _BetValue;
        private bool? _Changed = null;
        private long? _Combination = 0;
        private string _FreeText = null;
        private long _Id = 0;
        private bool? _MostBalanced = null;
        private ObservableCollection<OddsFieldValueModel> _OddsFields = new ObservableCollection<OddsFieldValueModel>();
        private string _SpecialOddsValue = null;
        private long? _SubType = null;
        private EventOddsType _Type = EventOddsType.UNDEFINED;
        private long _TypeId = 0;

        public bool Active
        {
            get { return this.GetProperty(ref this._Active); }
            private set { this.SetProperty(ref this._Active, value, "Active"); }
        }

        public BetValueModel BetValue
        {
            get { return this.GetProperty(ref this._BetValue); }
            private set { this.SetProperty(ref this._BetValue, value, "BetValue"); }
        }

        public bool? Changed
        {
            get { return this.GetProperty(ref this._Changed); }
            private set { this.SetProperty(ref this._Changed, value, "Changed"); }
        }
        public long? Combination
        {
            get { return this.GetProperty(ref this._Combination); }
            private set { this.SetProperty(ref this._Combination, value, "Combination"); }
        }
        public string FreeText
        {
            get { return this.GetProperty(ref this._FreeText); }
            private set { this.SetProperty(ref this._FreeText, value, "FreeText"); }
        }
        public long Id
        {
            get { return this.GetProperty(ref this._Id); }
            private set { this.SetProperty(ref this._Id, value, "Id"); }
        }
        public bool? MostBalanced
        {
            get { return this.GetProperty(ref this._MostBalanced); }
            private set { this.SetProperty(ref this._MostBalanced, value, "MostBalanced"); }
        }
        public ObservableCollection<OddsFieldValueModel> OddsFields
        {
            get { return this.GetProperty<ObservableCollection<OddsFieldValueModel>>(ref this._OddsFields); }
        }
        public string SpecialOddsValue
        {
            get { return this.GetProperty(ref this._SpecialOddsValue); }
            private set { this.SetProperty(ref this._SpecialOddsValue, value, "SpecialOddsValue"); }
        }
        public long? SubType
        {
            get { return this.GetProperty(ref this._SubType); }
            private set { this.SetProperty(ref this._SubType, value, "SubType"); }
        }
        public EventOddsType Type
        {
            get { return this.GetProperty(ref this._Type); }
            private set { this.SetProperty(ref this._Type, value, "Type"); }
        }
        public long TypeId
        {
            get { return this.GetProperty(ref this._TypeId); }
            private set { this.SetProperty(ref this._TypeId, value, "TypeId"); }
        }

        public bool Equals(MatchOddsModel other)
        {
            return (this.CompareTo(other) == 0);
        }

        public int CompareTo(MatchOddsModel other)
        {
            if (other == null)
            {
                return -1;
            }

            int type_compare = this.TypeId.CompareTo(other.TypeId);
            if (type_compare!=0) return type_compare;

            if (this.SubType != null && other.SubType != null)
            {
                int subtype_compare = ((long)this.SubType).CompareTo((long)other.SubType);
                if (subtype_compare != 0) return subtype_compare;
            }

            if (this.FreeText != null)
            {
                int freetext_compare = this.FreeText.CompareTo(other.FreeText);
                if (freetext_compare != 0) return freetext_compare;
            }

            if (this.SpecialOddsValue != null)
            {
                var specaloddsvalue_compare = this.SpecialOddsValue.CompareTo(other.SpecialOddsValue);
                if (specaloddsvalue_compare != 0) return specaloddsvalue_compare;
            }
            return this.Id.CompareTo(other.Id);
        }
    }
}