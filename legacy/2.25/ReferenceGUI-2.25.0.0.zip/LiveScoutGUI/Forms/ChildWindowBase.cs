﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using Sportradar.Demo.GUI.LiveScout.DataProvider;
using Sportradar.Demo.GUI.LiveScout.Code;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Common;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Models;
using System.ComponentModel;
using System.Collections.ObjectModel;

namespace Sportradar.Demo.GUI.LiveScout.Forms
{
    public abstract class ChildWindowBase : Window, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private long _MatchId = 0;
        private ConcurrentDictionary<long, Window> _OpenedChildWindows;

        public ChildWindowBase()
            : base()
        {
            this.DataContext = this;
            this.Closing += ChildWindowBaseClosing;
        }

        protected abstract string FormTitlePrefix { get; }

        public long MatchId { get { return this._MatchId; } }
        public GuiStrings GuiStrings { get { return GuiStrings.Instance; } }
        public MatchModel MatchModel
        {
            get
            {
                MatchModel matchModel;
                if (References.Instance.Matches.TryGetValue(this._MatchId, out matchModel))
                {
                    return matchModel;
                }
                return null;
            }
        }
        public ObservableCollection<OddsValueModel> OddsSuggestions
        {
            get
            {
                ObservableCollection<OddsValueModel> oddsSuggestions;
                if (References.Instance.OddsValuesPerMatch.TryGetValue(this._MatchId, out oddsSuggestions))
                {
                    return oddsSuggestions;
                }
                return null;
            }
        }
        public ObservableCollection<ScoutInfoModel> ScoutInfos
        {
            get
            {
                ObservableCollection<ScoutInfoModel> scoutInfos;
                if (References.Instance.ScoutInfosPerMatch.TryGetValue(this._MatchId, out scoutInfos))
                {
                    return scoutInfos;
                }
                return null;
            }
        }
        public ObservableCollection<ScoreModel> Scores
        {
            get
            {
                var match = this.MatchModel;
                if (match != null)
                {
                    return match.Scores;
                }

                return null;
            }
        }
        public ObservableCollection<ScoutEventModel> ScountEvents
        {
            get
            {
                var match = this.MatchModel;
                if (match != null)
                {
                    return match.ScountEvents;
                }

                return null;
            }
        }
        public string MatchQuickDescription
        {
            get
            {
                var match = this.MatchModel;
                if (match != null
                    && match.Team1Name != null
                    && match.Team2Name != null)
                {
                    return string.Format(
                        " - {0} : {1} [id: {2}]",
                        match.Team1Name.GetTranslation(GuiStrings.Instance.CurrentLanguage),
                        match.Team2Name.GetTranslation(GuiStrings.Instance.CurrentLanguage),
                        match.MatchId);
                }

                return null;
            }
        }
        public string FormTitle
        {
            get
            {
                return string.Format("{0}{1}", this.FormTitlePrefix ?? string.Empty, this.MatchQuickDescription ?? string.Empty);
            }
        }
        public ObservableCollection<NotificationModel> Notifications
        {
            get
            {
                ObservableCollection<NotificationModel> notifications;
                if (References.Instance.NotificationsPerMatch.TryGetValue(this._MatchId, out notifications))
                {
                    return notifications;
                }
                return null;
            }
        }

        public void SetMatchId(long matchId)
        {
            if (!References.Instance.LoadedMatchIds.Contains(matchId))
            {
                throw new Exception(string.Format("Cache does not contain match with id: {0}", matchId));
            }

            this._MatchId = matchId;
            this.OnPropertyChanged("MatchId", "MatchModel", "OddsSuggestions", "ScoutInfos", "Scores", "ScountEvents", "MatchQuickDescription", "FormTitle", "Notifications");
        }

        public void SetChildWindows(ConcurrentDictionary<long, Window> childWindows)
        {
            if (childWindows == null)
            {
                throw new ArgumentNullException("childWindows");
            }

            this._OpenedChildWindows = childWindows;
        }

        private void ChildWindowBaseClosing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            try
            {
                if (this._OpenedChildWindows != null)
                {
                    Window window;
                    if (this._OpenedChildWindows.TryRemove(this._MatchId, out window))
                    {
                        this.PerformAdditionalCleanUpOnClosing(window);
                    }
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }

        protected virtual void PerformAdditionalCleanUpOnClosing(Window window)
        {
        }

        protected void OnPropertyChanged(params string[] propNames)
        {
            var propertyChanged = this.PropertyChanged;
            if (propertyChanged != null)
            {
                foreach (var propName in propNames)
                {
                    if (propName == null)
                    {
                        continue;
                    }

                    propertyChanged(this, new PropertyChangedEventArgs(propName));
                }
            }
        }

    }
}