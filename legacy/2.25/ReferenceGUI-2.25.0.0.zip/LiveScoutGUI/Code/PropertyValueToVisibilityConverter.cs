﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Data;

namespace Sportradar.Demo.GUI.LiveScout.Code
{
    public class PropertyValueToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if ((value == null)
                || ((value.ToString() ?? string.Empty).Trim().ToLower() == "undefined")
                || ((value is DateTime) && (((DateTime)value) == DateTime.MinValue)))
            {
                return Visibility.Collapsed;
            }

            return Visibility.Visible;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
