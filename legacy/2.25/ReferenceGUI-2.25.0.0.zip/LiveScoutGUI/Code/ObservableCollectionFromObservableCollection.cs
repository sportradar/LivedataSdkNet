﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Sportradar.Demo.GUI.LiveScout.Code
{
    public class ObservableCollectionFromObservableCollection<T, TSource> : IList<T>, IList, INotifyCollectionChanged, INotifyPropertyChanged
    {
        private readonly ObservableCollection<TSource> _Source;
        private readonly Func<T, TSource> _ThisToSourceConverter;
        private readonly Func<TSource, T> _SourceToThisConverter;

        public ObservableCollectionFromObservableCollection(
            ObservableCollection<TSource> source,
            Func<T, TSource> thisToSourceConverter,
            Func<TSource, T> sourceToThisConverter)
        {
            if (source == null)
            {
                throw new ArgumentNullException("source");
            }
            if (thisToSourceConverter == null)
            {
                throw new ArgumentNullException("thisToSourceConverter");
            }
            if (sourceToThisConverter == null)
            {
                throw new ArgumentNullException("sourceToThisConverter");
            }

            this._Source = source;
            this._ThisToSourceConverter = thisToSourceConverter;
            this._SourceToThisConverter = sourceToThisConverter;

            this._Source.CollectionChanged += OnCollectionChanged;
            ((INotifyPropertyChanged)this._Source).PropertyChanged += OnPropertyChanged;
        }

        private void OnPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            var propertyChanged = this.PropertyChanged;
            if (propertyChanged != null)
            {
                propertyChanged(this, new PropertyChangedEventArgs(e.PropertyName));
            }
        }

        private void OnCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            var collectionChanged = this.CollectionChanged;
            if (collectionChanged != null)
            {
                switch (e.Action)
                {
                    case NotifyCollectionChangedAction.Add:
                        {
                            collectionChanged(this, new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Add, Convert(e.NewItems), e.NewStartingIndex));
                            break;
                        }
                    case NotifyCollectionChangedAction.Move:
                        {
                            collectionChanged(this, new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Move, Convert(e.NewItems), e.NewStartingIndex, e.OldStartingIndex));
                            break;
                        }
                    case NotifyCollectionChangedAction.Remove:
                        {
                            collectionChanged(this, new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Remove, Convert(e.OldItems), e.OldStartingIndex));
                            break;
                        }
                    case NotifyCollectionChangedAction.Replace:
                        {
                            collectionChanged(this, new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Replace, Convert(e.NewItems), Convert(e.OldItems), e.NewStartingIndex));
                            break;
                        }
                    case NotifyCollectionChangedAction.Reset:
                        {
                            collectionChanged(this, new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
                            break;
                        }
                }
            }
        }

        private IList Convert(IList old)
        {
            if (old == null)
            {
                return null;
            }

            IList result = new ArrayList();

            foreach (var item in old)
            {
                if (item == null)
                {
                    result.Add(null);
                }
                else
                {
                    result.Add(this._SourceToThisConverter((TSource)item));
                }
            }

            return result;
        }

        public event NotifyCollectionChangedEventHandler CollectionChanged;
        protected event PropertyChangedEventHandler PropertyChanged;

        public int IndexOf(T item)
        {
            return this._Source.IndexOf(this._ThisToSourceConverter(item));
        }

        public void Insert(int index, T item)
        {
            this._Source.Insert(index, this._ThisToSourceConverter(item));
        }

        public void RemoveAt(int index)
        {
            this._Source.RemoveAt(index);
        }

        public T this[int index]
        {
            get
            {
                return this._SourceToThisConverter(this._Source[index]);
            }
            set
            {
                this._Source[index] = this._ThisToSourceConverter(value);
            }
        }

        public void Add(T item)
        {
            this._Source.Add(this._ThisToSourceConverter(item));
        }

        public void Clear()
        {
            this._Source.Clear();
        }

        public bool Contains(T item)
        {
            return this._Source.Contains(this._ThisToSourceConverter(item));
        }

        public void CopyTo(T[] array, int arrayIndex)
        {
            var thisArray = this.ToArray();
            thisArray.CopyTo(array, arrayIndex);
        }

        public int Count
        {
            get { return this._Source.Count; }
        }

        public bool IsReadOnly
        {
            get { return ((IList<TSource>)this._Source).IsReadOnly; }
        }

        public bool Remove(T item)
        {
            return this._Source.Remove(this._ThisToSourceConverter(item));
        }

        public IEnumerator<T> GetEnumerator()
        {
            foreach (var sourceItem in this._Source)
            {
                yield return this._SourceToThisConverter(sourceItem);
            }

            yield break;
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        event PropertyChangedEventHandler INotifyPropertyChanged.PropertyChanged
        {
            add
            {
                this.PropertyChanged += value;
            }
            remove
            {
                this.PropertyChanged -= value;
            }
        }


        int IList.Add(object value)
        {
            this.Add((T)value);
            return this.Count - 1;
        }

        void IList.Clear()
        {
            this.Clear();
        }

        bool IList.Contains(object value)
        {
            return this.Contains((T)value);
        }

        int IList.IndexOf(object value)
        {
            return this.IndexOf((T)value);
        }

        void IList.Insert(int index, object value)
        {
            this.Insert(index, (T)value);
        }

        bool IList.IsFixedSize
        {
            get { return false; }
        }

        bool IList.IsReadOnly
        {
            get { return false; }
        }

        void IList.Remove(object value)
        {
            this.Remove((T)value);
        }

        void IList.RemoveAt(int index)
        {
            this.RemoveAt(index);
        }

        object IList.this[int index]
        {
            get
            {
                return this[index];
            }
            set
            {
                this[index] = (T)value;
            }
        }

        void ICollection.CopyTo(Array array, int index)
        {
            var thisArray = this.ToArray();
            thisArray.CopyTo(array, index);
        }

        int ICollection.Count
        {
            get { return this.Count; }
        }

        bool ICollection.IsSynchronized
        {
            get { return false; }
        }

        object ICollection.SyncRoot
        {
            get { return null; }
        }
    }
}