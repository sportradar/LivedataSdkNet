﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using System.Windows;

namespace Sportradar.Demo.GUI.LiveScout.Code
{
    public class AlternationIndexToBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter,
            System.Globalization.CultureInfo culture)
        {
            int result = 0;

            if ((value != null)
                && (!int.TryParse(value.ToString(), out result)))
            {
                result = 0;
            }

            return ((result == 1) ? Application.Current.Resources["RowDarker"] : Application.Current.Resources["RowLighter"]);
        }

        public object ConvertBack(object value, Type targetType, object parameter,
            System.Globalization.CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
