﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.FeedProviders.Common;
using System;
using System.Windows.Data;

namespace Sportradar.Demo.GUI.LiveScout.Code
{
    public class StatsExtractValueConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            string result = "NA";

            try
            {
                if ((value != null) && (parameter != null))
                {
                    int param = System.Convert.ToInt32(parameter);

                    if ((param == 1) || (param == 2))
                    {
                        if (value is HomeAway<int>)
                        {
                            if (param == 1)
                            {
                                result = ((HomeAway<int>)value).Team1.ToString();
                            }
                            else
                            {
                                result = ((HomeAway<int>)value).Team2.ToString();
                            }
                        }
                        else if (value is HomeAway<int?>)
                        {
                            HomeAway<int?> val = (HomeAway<int?>)value;

                            if (param == 1)
                            {
                                if (val.Team1.HasValue)
                                {
                                    result = val.Team1.ToString();
                                }
                            }
                            else
                            {
                                if (val.Team2.HasValue)
                                {
                                    result = val.Team2.ToString();
                                }
                            }
                        }
                    }
                }
            }
            catch
            {
            }

            return result;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
