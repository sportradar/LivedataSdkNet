﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using Sportradar.Demo.GUI.LiveScout.DataProvider;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Models;

namespace Sportradar.Demo.GUI.LiveScout.Code
{
    public class MatchIdToMatchConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if ((value != null) && (value is long))
            {
                long matchId = (long)value;

                MatchModel match;
                if (References.Instance.Matches.TryGetValue(matchId, out match))
                {
                    return match;
                }
            }

            return value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
