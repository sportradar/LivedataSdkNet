﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.Common;
using Merged::Sportradar.SDK.FeedProviders.Common;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Common;
using System;
using System.Windows.Data;

namespace Sportradar.Demo.GUI.LiveScout.Code
{
    public class PropertyValueConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            string baseValue = string.Empty;

            if (value != null)
            {
                if (value is LocalizedString)
                {
                    LocalizedString localizedString = (LocalizedString)value;
                    baseValue = localizedString.GetTranslation(GuiStrings.Instance.CurrentLanguage);
                }
                else if (value is HomeAway<int>)
                {
                    HomeAway<int> homeAwayStats = (HomeAway<int>)value;
                    baseValue = string.Format("{0} : {1}", homeAwayStats.Team1, homeAwayStats.Team2);
                }
                else if (value is DateTime?)
                {
                    DateTime? valDatetime = (DateTime?)value;
                    baseValue = string.Format("{0}", valDatetime.Value.ToString("HH:mm:ss"));
                }
                else
                {
                    baseValue = value.ToString();
                }
            }
            else
            {
                baseValue = "[[null]]";
            }

            return baseValue;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
