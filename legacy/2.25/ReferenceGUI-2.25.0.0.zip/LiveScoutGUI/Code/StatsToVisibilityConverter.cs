﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.FeedProviders.Common;
using System;
using System.Windows;
using System.Windows.Data;

namespace Sportradar.Demo.GUI.LiveScout.Code
{
    public class StatsToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            Visibility result = Visibility.Collapsed;

            if (value != null)
            {
                if (value is HomeAway<int>)
                {
                    result = Visibility.Visible;
                }
                else if (value is HomeAway<int?>)
                {
                    HomeAway<int?> val = (HomeAway<int?>)value;

                    if ((val.Team1 != null) || (val.Team2 != null))
                    {
                        result = Visibility.Visible;
                    }
                }
            }

            return result;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
