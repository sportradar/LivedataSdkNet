﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;
using Sportradar.Demo.GUI.LiveOdds.Code;
using Sportradar.Demo.GUI.LiveOdds.DataProvider;
using System.Threading.Tasks;

namespace Sportradar.Demo.GUI.LiveOdds
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            try
            {
                ChangeTracker.Instance.StartTracking(ConfigurationManager.AppSettings);
            }
            catch (Exception exc)
            {
                exc.ShowError();
                this.Shutdown(1);
            }
        }

        private void Application_Exit(object sender, ExitEventArgs e)
        {
            try
            {
                ChangeTracker.Instance.StopTracking();
            }
            catch (Exception exc)
            {
                exc.ShowError();
                this.Shutdown(1);
            }
        }
    }
}
