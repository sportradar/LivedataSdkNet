﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Enums;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Models;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Sportradar.Demo.GUI.LiveOdds.Forms
{
    /// <summary>
    /// Interaction logic for MatchNotificationDetails.xaml
    /// </summary>
    public partial class MatchNotificationDetails : Window
    {
        private ImprovedObservableCollection<MatchOddsModel> _matchOdds = new ImprovedObservableCollection<MatchOddsModel>();
        private MatchHeaderModel _matchHeader;

        public MatchNotificationDetails(NotificationDisplayModel notification)
        {
            InitializeComponent();
            this.DataContext = this;
            EventArgsGrid.RowDefinitions.Add(new RowDefinition());

            switch (notification.NotificationType)
            {
                case NotificationType.BetCancel:
                    {
                        var eventargs = notification.EventArgs as BetCancelEventArgs;
                        if (eventargs != null)
                        {
                            eventargs.BetCancel.Odds.ForEach(x => _matchOdds.Add(new MatchOddsModel(x)));
                            _matchHeader = new MatchHeaderModel((MatchHeader)eventargs.BetCancel.EventHeader);

                        }

                        break;
                    }
                case NotificationType.BetCancelUndo:
                    {
                        var eventargs = notification.EventArgs as BetCancelUndoEventArgs;
                        if (eventargs != null)
                        {
                            eventargs.BetCancelUndo.Odds.ForEach(x => _matchOdds.Add(new MatchOddsModel(x)));
                            _matchHeader = new MatchHeaderModel((MatchHeader)eventargs.BetCancelUndo.EventHeader);

                        }

                        break;
                    }
                case NotificationType.BetClear:
                    {
                        var eventargs = notification.EventArgs as BetClearEventArgs;
                        if (eventargs != null)
                        {
                            eventargs.BetClear.Odds.ForEach(x => _matchOdds.Add(new MatchOddsModel(x)));
                            _matchHeader = new MatchHeaderModel((MatchHeader)eventargs.BetClear.EventHeader);
                        }
                        break;
                    }
                case NotificationType.BetClearRollback:
                    {
                        var eventargs = notification.EventArgs as BetClearRollbackEventArgs;
                        if (eventargs != null)
                        {
                            eventargs.BetClearRollback.Odds.ForEach(x => _matchOdds.Add(new MatchOddsModel(x)));
                            _matchHeader = new MatchHeaderModel((MatchHeader)eventargs.BetClearRollback.EventHeader);
                        }
                        break;
                    }
                case NotificationType.BetStart:
                    {
                        var eventargs = notification.EventArgs as BetStartEventArgs;
                        if (eventargs != null)
                        {
                            _matchHeader = new MatchHeaderModel((MatchHeader)eventargs.BetStart.EventHeader);
                        }
                        break;
                    }
                case NotificationType.BetStop:
                    {
                        var eventargs = notification.EventArgs as BetStopEventArgs;
                        if (eventargs != null)
                        {
                            _matchHeader = new MatchHeaderModel((MatchHeader)eventargs.BetStop.EventHeader);
                        }
                        break;
                    }
                case NotificationType.OddsChange:
                    {
                        var eventargs = notification.EventArgs as OddsChangeEventArgs;
                        if (eventargs != null)
                        {
                            eventargs.OddsChange.Odds.ForEach(x => _matchOdds.Add(new MatchOddsModel(x)));
                            _matchHeader = new MatchHeaderModel((MatchHeader)eventargs.OddsChange.EventHeader);
                        }
                        break;
                    }
            }
        }

        private int column = 0;
        private void AddCellToEventArgsGrid(string content)
        {
            EventArgsGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
            int idx = EventArgsGrid.Children.Add(new Label { Content = content });

            Label x = EventArgsGrid.Children[idx] as Label;

            x.SetValue(Grid.RowProperty, 0);
            x.SetValue(Grid.ColumnProperty, column);
            column++;

        }

        public ImprovedObservableCollection<MatchOddsModel> MatchOdds
        {
            get
            {
                return _matchOdds;
            }
        }

        public MatchHeaderModel MatchHeader
        {
            get
            {
                return _matchHeader;
            }
        }
    }
}
