﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using Sportradar.Demo.GUI.LiveOdds.Code;
using Sportradar.Demo.GUI.LiveOdds.DataProvider;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Enums;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Models;

namespace Sportradar.Demo.GUI.LiveOdds.Forms
{
    /// <summary>
    /// Interaction logic for MatchNotifications.xaml
    /// </summary>
    public partial class MatchNotifications : Window
    {

        private readonly MainWindow _MainWindow = null;
        private readonly long _MatchId = 0;
        private readonly ListCollectionView _ListCollectionView;
        private ImprovedObservableCollection<NotificationDisplayModel> _notifications;
        private CheckableObservableCollection<NotificationType> _event_filters;

        public MatchNotifications()
        {
            InitializeComponent();
        }


        public MatchNotifications(MainWindow mainWindow, long matchId)
            : this()
        {
            this._MainWindow = mainWindow;
            this._MatchId = matchId;
            _event_filters = new CheckableObservableCollection<NotificationType>();
            if (References.Instance.PerMatchNotifications.TryGetValue(matchId, out _notifications))
            {
                this._ListCollectionView = new ListCollectionView(_notifications);
                _ListCollectionView.Filter = Filter;
                _notifications.CollectionChanged += (sender, args) => RefreshFilters();
                RefreshFilters();
            }
            this.DataContext = this;
            this.Title = matchId.ToString();
        }

        private void RefreshFilters()
        {
            foreach (var notification in _notifications)
            {
                var type = notification.NotificationType;
                if (!_event_filters.Any(x => x.Value == type))
                {
                    _event_filters.Add(type);
                    _event_filters.First(x => x.Value == type).IsChecked = true;
                }
            }

            //ToList to get loose of "Collection was modified; enumeration operation may not execute" exception
            foreach (var eventFilter in _event_filters.ToList())
            {
                if (!_notifications.Any(x => x.NotificationType == eventFilter.Value))
                {
                    _event_filters.Remove(eventFilter);
                }
            }

            _ListCollectionView.Refresh();
            InvalidateVisual();
        }

        private bool Filter(object o)
        {
            var model = o as NotificationDisplayModel;
            if (model != null && model.Message != null)
            {
                var filter = _event_filters.FirstOrDefault(x => x.Value == model.NotificationType);
                if (filter != null && filter.IsChecked == false)
                {
                    return false;
                }
            }

            return true;
        }



        public GuiStrings GuiStrings
        {
            get
            {
                return GuiStrings.Instance;
            }
        }

        public ListCollectionView PerMatchNotifications
        {
            get
            {
                return _ListCollectionView;
            }
        }

        public CheckableObservableCollection<NotificationType> EventFilters
        {
            get
            {
                return _event_filters;
            }
        }

        public long MatchId
        {
            get { return _MatchId; }
        }



        private void btnPerMatchNotificationClearAll(object sender, RoutedEventArgs e)
        {
            try
            {
                ImprovedObservableCollection<NotificationDisplayModel> notifications;
                if (References.Instance.PerMatchNotifications.TryGetValue(MatchId, out notifications))
                {
                    notifications.Clear();
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }

        private void DeleteNotificationCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if (e.Parameter is Guid)
                {
                    Guid notificationId = (Guid)e.Parameter;
                    ImprovedObservableCollection<NotificationDisplayModel> notifications;
                    if (References.Instance.PerMatchNotifications.TryGetValue(MatchId, out notifications))
                    {
                        var notification = notifications.FirstOrDefault(x => x.Id == notificationId);
                        if (notification != null)
                        {
                            notifications.Remove(notification);
                        }
                    }
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }


        private void ViewNotificationDetailsCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if (e.Parameter is Guid)
                {
                    Guid notificationId = (Guid)e.Parameter;
                    ImprovedObservableCollection<NotificationDisplayModel> notifications;
                    if(References.Instance.PerMatchNotifications.TryGetValue(MatchId, out notifications))
                    {
                        var notification = notifications.FirstOrDefault(x => x.Id == notificationId);
                        var window = new MatchNotificationDetails(notification);
                        window.Show();
                    }
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }


        private void FilterChange(object sender, DataTransferEventArgs e)
        {
            PerMatchNotifications.Refresh();
        }
    }
}
