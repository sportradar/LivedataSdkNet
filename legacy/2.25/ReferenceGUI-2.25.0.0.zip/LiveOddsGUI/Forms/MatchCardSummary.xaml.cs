﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Specialized;
using System.Threading;
using System.Windows;
using System.Linq;
using System.Windows.Data;
using Sportradar.Demo.GUI.LiveOdds.Code;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Models;
using System.Collections.ObjectModel;
using Sportradar.Demo.GUI.LiveOdds.DataProvider;

namespace Sportradar.Demo.GUI.LiveOdds.Forms
{
    /// <summary>
    /// Interaction logic for MatchCardSummary.xaml
    /// </summary>
    public partial class MatchCardSummary : Window
    {
        private readonly MainWindow _MainWindow = null;
        private readonly long _MatchId = 0;



        public MatchCardSummary(MainWindow mainWindow, long matchId)
        {
            this.DataContext = this;
            this._MainWindow = mainWindow;
            this._MatchId = matchId;
            InitializeComponent();
            if (ScoreCardSummaryModel.MatchHeader != null)
            {
                var mh = new MatchHeaderModel(ScoreCardSummaryModel.MatchHeader);
                HelperClass.FillGridWithObjectProperties(mh, MatchHeaderGrid, 6);
                if (mh.SetScores != null && mh.SetScores.Count > 0)
                {
                    HelperClass.BuildGridFromStringArray(mh.SetScores.Where(x=>x!=null).ToList(), SetScoresGrid, 1);
                }
                if (mh.Message != null && mh.Message.Count > 0)
                {
                    HelperClass.BuildGridFromStringArray(mh.Message, MessagesGrid, 1);
                }
            }
        }


        public ScoreCardSummaryModel ScoreCardSummaryModel
        {
            get
            {
                ScoreCardSummaryModel result;
                if (References.Instance.MatchScoreCardSummaries.TryGetValue(this._MatchId, out result))
                {
                    return result;
                }

                return null;
            }
        }

        public ListCollectionView LoadedCardSummaryByTime
        {
            get { return new ListCollectionView(CardSummaryByTime); }
        }

        public ListCollectionView LoadedScoreSummaryByTime
        {
            get { return new ListCollectionView(ScoreSummaryByTime); }
        }

        public long MatchId
        {
            get { return _MatchId; }
        }

        private ObservableCollection<CardEntryModel> CardSummaryByTime
        {
            get
            {
                ScoreCardSummaryModel scoreCardSummaryModel = this.ScoreCardSummaryModel;
                if (scoreCardSummaryModel == null)
                {
                    return null;
                }
                return scoreCardSummaryModel.CardSummaryByTime;
            }
        }

        private ObservableCollection<ScoreEntryModel> ScoreSummaryByTime
        {
            get
            {
                ScoreCardSummaryModel scoreCardSummaryModel = this.ScoreCardSummaryModel;
                if (scoreCardSummaryModel == null)
                {
                    return null;
                }
                return scoreCardSummaryModel.ScoreSummaryByTime;
            }
        }

        private void MatchCardSummaryClosing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            try
            {
                if (this._MainWindow != null)
                {
                    MatchCardSummary matchCardSummary;
                    this._MainWindow.LoadedMatchCardSummaries.TryRemove(this._MatchId, out matchCardSummary);
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }

    }
}
