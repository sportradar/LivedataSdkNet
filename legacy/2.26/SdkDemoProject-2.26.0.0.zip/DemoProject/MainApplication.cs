﻿using System;
using System.Collections.Generic;
using System.Configuration;
using log4net;
using log4net.Config;
using Sportradar.SDK.Common.Interfaces;
using Sportradar.SDK.Services.Sdk;
using Sportradar.SDK.Services.SdkConfiguration;

namespace Sportradar.DemoProject
{
    public class MainApplication
    {
        private static readonly ILog _log = LogManager.GetLogger(typeof(MainApplication));

        public static void Main(string[] args)
        {
            var m_sdk = Sdk.Instance;

            XmlConfigurator.Configure();
            m_sdk.Initialize();
            m_sdk.Start();
            var enabled_feeds = new List<IStartable>();

            if (m_sdk.BetPal != null)
            {
                enabled_feeds.Add(new LiveOddsMatchModule(m_sdk.BetPal, "BetPal", TimeSpan.FromHours(12)));
            }
            if (m_sdk.LiveOdds != null)
            {
                enabled_feeds.Add(new LiveOddsMatchModule(m_sdk.LiveOdds, "LiveOdds", TimeSpan.FromHours(12)));
            }
            if (m_sdk.LiveOddsVdr != null)
            {
                enabled_feeds.Add(new LiveOddsRaceModule(m_sdk.LiveOddsVdr, "LiveOddsVdr", TimeSpan.FromHours(2)));
            }
            if (m_sdk.LiveOddsVbl != null)
            {
                enabled_feeds.Add(new LiveOddsMatchModule(m_sdk.LiveOddsVbl, "LiveOddsVbl", TimeSpan.FromHours(2)));
            }
            if (m_sdk.LiveOddsVfc != null)
            {
                enabled_feeds.Add(new LIveOddsWithOutrightsModule(m_sdk.LiveOddsVfc, "LiveOddsVfc", TimeSpan.FromHours(2)));
            }
            if (m_sdk.LiveOddsVfl != null)
            {
                enabled_feeds.Add(new LiveOddsMatchModule(m_sdk.LiveOddsVfl, "LiveOddsVfl", TimeSpan.FromHours(2)));
            }
            if (m_sdk.LiveOddsVhc != null)
            {
                enabled_feeds.Add(new LiveOddsRaceModule(m_sdk.LiveOddsVhc, "LiveOddsVhc", TimeSpan.FromHours(2)));
            }
            if (m_sdk.LiveOddsVto != null)
            {
                enabled_feeds.Add(new LiveOddsMatchModule(m_sdk.LiveOddsVto, "LiveOddsVto", TimeSpan.FromHours(2)));
            }
            if (m_sdk.LivePlex != null)
            {
                enabled_feeds.Add(new LiveOddsMatchModule(m_sdk.LivePlex, "LivePlex", TimeSpan.FromHours(12)));
            }
            if (m_sdk.SoccerRoulette != null)
            {
                enabled_feeds.Add(new LiveOddsMatchModule(m_sdk.SoccerRoulette, "SoccerRoulette", TimeSpan.FromHours(12)));
            }
            if (m_sdk.LiveScout != null)
            {
                var cfm = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                var sdk_section = (SdkConfigurationSection)cfm.GetSection("Sdk");
                enabled_feeds.Add(new LiveScoutModule(m_sdk.LiveScout, "LiveScout", sdk_section.LiveScout.Test));
            }
            if (m_sdk.Lcoo != null)
            {
                enabled_feeds.Add(new LcooModule(m_sdk.Lcoo, "Lcoo"));
            }
            if (m_sdk.OddsCreator != null)
            {
                enabled_feeds.Add(new OddsCreatorModule(m_sdk.OddsCreator, "OddsCreator"));
            }

            enabled_feeds.ForEach(x => x.Start());
            
            Console.ReadLine();

            enabled_feeds.ForEach(x => x.Stop());
            m_sdk.Stop();
        }
    }
}