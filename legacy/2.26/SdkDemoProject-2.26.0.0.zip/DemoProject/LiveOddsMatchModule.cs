﻿using log4net;
using Sportradar.SDK.FeedProviders.LiveOdds.Common;
using Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using System;

namespace Sportradar.DemoProject
{
    public class LiveOddsMatchModule : LiveOddsCommonModule
    {
        private static readonly ILog g_log = LogManager.GetLogger(typeof(LiveOddsMatchModule));
        private readonly ILiveOdds m_live_odds;

        public LiveOddsMatchModule(ILiveOdds live_odds, string feed_name, TimeSpan meta_interval)
            : base(live_odds, feed_name, meta_interval)
        {
            m_live_odds = live_odds;
            m_live_odds.OnScoreCardSummary += ScoreCardSummaryHandler;
            m_live_odds.OnMetaInfo += MetaInfoHandler;
        }

        protected override void ConnectionStableHandler(object sender, EventArgs e)
        {
            base.ConnectionStableHandler(sender, e);
            if (m_live_odds.TestManager != null)
            {
                m_live_odds.TestManager.StartAuto();
            }
        }

        private void MetaInfoHandler(object sender, MetaInfoEventArgs e)
        {
            var meta_data = e.MetaInfo.MetaInfoDataContainer as LiveOddsMetaData;
            if (meta_data != null)
            {
                g_log.InfoFormat("{0}: Received MetaInfo with {1} matches", m_feed_name, meta_data.MatchHeaderInfos.Count);
            }
        }

        private void ScoreCardSummaryHandler(object sender, ScoreCardSummaryEventArgs e)
        {
            g_log.InfoFormat("{0}: Received ScoreCardSummary for event {1}", m_feed_name, e.ScoreCardSummary.EventHeader.Id);
        }
    }
}