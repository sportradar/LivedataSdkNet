﻿using System;
using log4net;
using Sportradar.SDK.FeedProviders.LiveOdds.Common;
using Sportradar.SDK.FeedProviders.LiveOdds.Outrights;

namespace Sportradar.DemoProject
{
    public class LIveOddsWithOutrightsModule : LiveOddsCommonBaseModule
    {
        private static readonly ILog g_log = LogManager.GetLogger(typeof(LIveOddsWithOutrightsModule));
        private readonly ILiveOddsWithOutrights m_live_odds;

        public LIveOddsWithOutrightsModule(ILiveOddsWithOutrights live_odds, string feed_name, TimeSpan meta_interval)
            : base(live_odds, feed_name, meta_interval)
        {
            m_live_odds = live_odds;
            m_live_odds.OnAliveWithOutrights += AliveWithOutrightsHandler;
            m_live_odds.OnMetaInfo += MetaInfoHandler;
            m_live_odds.OnOutrightBetStart += OutrightBetStartHandler;
            m_live_odds.OnOutrightOddsChange += OutrightOddsChangeHandler;
            m_live_odds.OnOutrightBetClear += OutrightBetClearHandler;
            m_live_odds.OnOutrightBetStop += OutrightBetStopHandler;
            m_live_odds.OnOutrightBetCancel += OutrightBetCancelHandler;
            m_live_odds.OnOutrightStatus += OutrightStatusHandler;
        }

        private void AliveWithOutrightsHandler(object sender, AliveWithOutrightsEventArgs e)
        {
            g_log.InfoFormat("{0}: Received alive with {1} events and {2} outrights",
                m_feed_name,
                e.AliveWithOutrights.EventHeaders?.Count ?? 0,
                e.AliveWithOutrights.OutrightHeaders?.Count ?? 0);
        }

        private void MetaInfoHandler(object sender, MetaInfoEventArgs e)
        {
            var meta = e.MetaInfo.MetaInfoDataContainer as MatchAndOutrightMetaData;
            if (meta == null)
            {
                g_log.ErrorFormat("{0}: Unexpected type of MetaInfoDataContainer received. Expected:{1}, Received:{2}", 
                    typeof(MatchAndOutrightMetaData).Name, 
                    e.MetaInfo.MetaInfoDataContainer.GetType().Name);
                return;
            }
            g_log.InfoFormat("{0}: Received MetaInfo with {1} matches and {2} outrights",
                m_feed_name,
                meta.MatchHeaderInfos == null
                    ? 0
                    : meta.MatchHeaderInfos.Count,
                meta.OutrightHeaderInfos == null
                    ? 0
                    : meta.OutrightHeaderInfos.Count);
        }

        private void OutrightBetStartHandler(object sender, OutrightBetStartEventArgs e)
        {
            g_log.InfoFormat("{0}: Received BetStart for event {1}", m_feed_name, e.OutrightBetStart.OutrightHeader.Id);
        }

        private void OutrightOddsChangeHandler(object sender, OutrightOddsChangeEventArgs e)
        {
            g_log.InfoFormat("{0}: Received OddsChange for outright {1} with {2} odds", 
                m_feed_name, 
                e.OutrightOddsChange.OutrightHeader.Id, 
                e.OutrightOddsChange.Odds == null
                    ? 0
                    : e.OutrightOddsChange.Odds.Count);
        }

        private void OutrightBetClearHandler(object sender, OutrightBetClearEventArgs e)
        {
            g_log.InfoFormat("{0}: Received BetClear for outright {1} and odds id {2}", m_feed_name, e.OutrightBetClear.OutrightHeader.Id, e.OutrightBetClear.Odds[0].Id);
        }

        private void OutrightBetStopHandler(object sender, OutrightBetStopEventArgs e)
        {
            g_log.InfoFormat("{0}: Received BetStart for outright {1}", m_feed_name, e.OutrightBetStop.OutrightHeader.Id);
        }

        private void OutrightBetCancelHandler(object sender, OutrightBetCancelEventArgs e)
        {
            g_log.InfoFormat("{0}: Received BetCancel for outright {1} and odds id {2}", m_feed_name, e.OutrightBetCancel.OutrightHeader.Id, e.OutrightBetCancel.Odds[0].Id);
        }

        private void OutrightStatusHandler(object sender, EventDataReceivedEventArgs e)
        {
            g_log.InfoFormat("{0}: Received {1} of current reply messages with reply number {2}", m_feed_name, e.Messages.Count, e.ReplyNr);
        }
    }
}
