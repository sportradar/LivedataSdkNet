﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Common;

namespace Sportradar.Demo.GUI.LiveScout.DataProvider.Models
{
    public class ServerTimeModel : NotifyPropertyChanged
    {
        private DateTime? _ServerTime = null;
        private DateTime? _LocalTime = null;

        public DateTime? ServerTime
        {
            get { return this.GetProperty(ref this._ServerTime); }
            set { this.SetProperty(ref this._ServerTime, value, "ServerTime"); }
        }

        public DateTime? LocalTime
        {
            get { return this.GetProperty(ref this._LocalTime); }
            set { this.SetProperty(ref this._LocalTime, value, "LocalTime"); }
        }
    }
}
