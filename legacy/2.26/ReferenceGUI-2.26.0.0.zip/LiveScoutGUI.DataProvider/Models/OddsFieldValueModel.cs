﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.FeedProviders.LiveScout;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Common;
using System;

namespace Sportradar.Demo.GUI.LiveScout.DataProvider.Models
{
    public class OddsFieldValueModel : NotifyPropertyChanged, IComparable<OddsFieldValueModel>, IEquatable<OddsFieldValueModel>
    {
        public OddsFieldValueModel(string key)
        {
            this.Load(key);
        }

        public void Load(string key)
        {
            if (key == null)
            {
                throw new ArgumentNullException("key");
            }

            this.Key = key;
        }

        private string _Key = null;
        private string _Side = null;
        private string _Description = null;
        private string _Value = null;

        public string Key
        {
            get { return this.GetProperty(ref this._Key); }
            private set { this.SetProperty(ref this._Key, value, "Key"); }
        }
        public string Side
        {
            get { return this.GetProperty(ref this._Side); }
            private set { this.SetProperty(ref this._Side, value, "Side"); }
        }
        public string Description
        {
            get { return this.GetProperty(ref this._Description); }
            private set { this.SetProperty(ref this._Description, value, "Description"); }
        }
        public string Value
        {
            get { return this.GetProperty(ref this._Value); }
            private set { this.SetProperty(ref this._Value, value, "Value"); }
        }

        public int CompareTo(OddsFieldValueModel other)
        {
            if (other == null)
            {
                return -1;
            }

            int result = this.Key.CompareExt(other.Key);
            if (result != 0)
            {
                return result;
            }

            result = this.Description.CompareExt(other.Description);
            if (result != 0)
            {
                return result;
            }

            return this.Side.CompareExt(other.Side);
        }

        public bool Equals(OddsFieldValueModel other)
        {
            return (this.CompareTo(other) == 0);
        }
    }
}