﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.FeedProviders.LiveScout;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Common;
using System;
using System.Collections.ObjectModel;
using System.Linq;

namespace Sportradar.Demo.GUI.LiveScout.DataProvider.Models
{
    public class OddsValueModel : NotifyPropertyChanged, IComparable<OddsValueModel>, IEquatable<OddsValueModel>
    {
        private int _Type = 0;
        private int? _SubType = null;
        private string _Description = null;
        private long _MatchId = 0;
        private int? _GuthMatchId = null;
        private bool _ManualActive = false;
        private DateTime _ValidDate = DateTime.MinValue;
        private string _SpecialOddsValue = null;
        private readonly ObservableCollection<OddsFieldValueModel> _OddsFieldValueModels = new ObservableCollection<OddsFieldValueModel>();

        public int Type
        {
            get { return this.GetProperty(ref this._Type); }
            private set { this.SetProperty(ref this._Type, value, "Type"); }
        }
        public int? SubType
        {
            get { return this.GetProperty(ref this._SubType); }
            private set { this.SetProperty(ref this._SubType, value, "SubType"); }
        }
        public string Description
        {
            get { return this.GetProperty(ref this._Description); }
            private set { this.SetProperty(ref this._Description, value, "Description"); }
        }
        public long MatchId
        {
            get { return this.GetProperty(ref this._MatchId); }
            private set { this.SetProperty(ref this._MatchId, value, "MatchId"); }
        }
        public int? GuthMatchId
        {
            get { return this.GetProperty(ref this._GuthMatchId); }
            private set { this.SetProperty(ref this._GuthMatchId, value, "GuthMatchId"); }
        }
        public bool ManualActive
        {
            get { return this.GetProperty(ref this._ManualActive); }
            private set { this.SetProperty(ref this._ManualActive, value, "ManualActive"); }
        }
        public DateTime ValidDate
        {
            get { return this.GetProperty(ref this._ValidDate); }
            private set { this.SetProperty(ref this._ValidDate, value, "ValidDate"); }
        }
        public string SpecialOddsValue
        {
            get { return this.GetProperty(ref this._SpecialOddsValue); }
            private set { this.SetProperty(ref this._SpecialOddsValue, value, "SpecialOddsValue"); }
        }
        public ObservableCollection<OddsFieldValueModel> Values { get { return this._OddsFieldValueModels; } }

        public int CompareTo(OddsValueModel other)
        {
            if (other == null)
            {
                return -1;
            }

            int result = this.MatchId.CompareTo(other.MatchId);
            if (result != 0)
            {
                return result;
            }
            result = this.Type.CompareTo(other.Type);
            if (result != 0)
            {
                return result;
            }
            result = this.SubType.CompareExt(other.SubType);
            if (result != 0)
            {
                return result;
            }

            return this.Description.CompareExt(other.Description);
        }

        public bool Equals(OddsValueModel other)
        {
            return (this.CompareTo(other) == 0);
        }
    }
}