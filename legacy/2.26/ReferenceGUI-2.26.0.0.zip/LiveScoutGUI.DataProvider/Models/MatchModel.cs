﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using Merged::Sportradar.SDK.Common;
using Merged::Sportradar.SDK.FeedProviders.Common;
using Merged::Sportradar.SDK.FeedProviders.LiveScout;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Common;

namespace Sportradar.Demo.GUI.LiveScout.DataProvider.Models
{
    public class MatchModel : NotifyPropertyChanged, IComparable<MatchModel>, IEquatable<MatchModel>
    {
        public MatchModel(MatchUpdate matchUpdate)
        {
            this.Load(matchUpdate);
        }

        public MatchModel(long matchId)
        {
            this.MatchId = matchId;
        }

        public void Load(MatchUpdate matchUpdate)
        {
            if (matchUpdate == null)
            {
                throw new ArgumentNullException("matchUpdate");
            }

            this.MatchId = ((matchUpdate.MatchHeader == null) ? this.MatchId : matchUpdate.MatchHeader.MatchId);
            this.Start = ((matchUpdate.MatchHeader == null || matchUpdate.MatchHeader.Start == null) ? this.Start : matchUpdate.MatchHeader.Start);
            this.Team1Id = ((matchUpdate.MatchHeader == null || matchUpdate.MatchHeader.Team1 == null || matchUpdate.MatchHeader.Team1.Id == null || matchUpdate.MatchHeader.Team1.Id.Value == 0) ? this.Team1Id : matchUpdate.MatchHeader.Team1.Id.Value);
            this.Team1Name = ((matchUpdate.MatchHeader == null || matchUpdate.MatchHeader.Team1 == null || matchUpdate.MatchHeader.Team1.Name == null) ? this.Team1Name : matchUpdate.MatchHeader.Team1.Name);
            this.Team2Id = ((matchUpdate.MatchHeader == null || matchUpdate.MatchHeader.Team2 == null || matchUpdate.MatchHeader.Team2.Id == null || matchUpdate.MatchHeader.Team2.Id.Value == 0) ? this.Team2Id : matchUpdate.MatchHeader.Team2.Id.Value);
            this.Team2Name = ((matchUpdate.MatchHeader == null || matchUpdate.MatchHeader.Team2 == null || matchUpdate.MatchHeader.Team2.Name == null) ? this.Team2Name : matchUpdate.MatchHeader.Team2.Name);
            this.BetStatus = ((matchUpdate.MatchHeader == null || matchUpdate.MatchHeader.BetStatus == null) ? this.BetStatus : matchUpdate.MatchHeader.BetStatus);
            this.TypeOfFeed = ((matchUpdate.MatchHeader == null || matchUpdate.MatchHeader.TypeOfFeed == null) ? this.TypeOfFeed : matchUpdate.MatchHeader.TypeOfFeed);
            this.Distance = ((matchUpdate.MatchHeader == null || matchUpdate.MatchHeader.Distance == null) ? this.Distance : matchUpdate.MatchHeader.Distance);
            this.ExtraInfo = ((matchUpdate.MatchHeader == null || matchUpdate.MatchHeader.ExtraInfo == null) ? this.ExtraInfo : matchUpdate.MatchHeader.ExtraInfo);
            this.IsDeepCoverage = ((matchUpdate.MatchHeader == null || matchUpdate.MatchHeader.IsDeepCoverage == null) ? this.IsDeepCoverage : matchUpdate.MatchHeader.IsDeepCoverage);
            this.IsTimeRunning = ((matchUpdate.MatchHeader == null || matchUpdate.MatchHeader.IsTimeRunning == null) ? this.IsTimeRunning : matchUpdate.MatchHeader.IsTimeRunning);
            this.CoveredFrom = ((matchUpdate.MatchHeader == null || matchUpdate.MatchHeader.CoveredFrom == null) ? this.CoveredFrom : matchUpdate.MatchHeader.CoveredFrom);
            this.ConnectionStatus = ((matchUpdate.MatchHeader == null || matchUpdate.MatchHeader.ConnectionStatus == null) ? this.ConnectionStatus : matchUpdate.MatchHeader.ConnectionStatus);
            this.WonJumpBall = ((matchUpdate.MatchHeader == null || matchUpdate.MatchHeader.WonJumpBall == null) ? this.WonJumpBall : matchUpdate.MatchHeader.WonJumpBall);
            this.FirstServe = ((matchUpdate.MatchHeader == null || matchUpdate.MatchHeader.FirstServe == null) ? this.FirstServe : matchUpdate.MatchHeader.FirstServe);
            this.FirstServeTieBreak = ((matchUpdate.MatchHeader == null || matchUpdate.MatchHeader.FirstServeTieBreak == null) ? this.FirstServeTieBreak : matchUpdate.MatchHeader.FirstServeTieBreak);
            this.NumberOfSets = ((matchUpdate.MatchHeader == null || matchUpdate.MatchHeader.NumberOfSets == null) ? this.NumberOfSets : matchUpdate.MatchHeader.NumberOfSets);
            this.TieBreakLastSet = ((matchUpdate.MatchHeader == null || matchUpdate.MatchHeader.TieBreakLastSet == null) ? this.TieBreakLastSet : matchUpdate.MatchHeader.TieBreakLastSet);
            this.IsBooked = ((matchUpdate.MatchHeader == null || matchUpdate.MatchHeader.IsBooked == null) ? this.IsBooked : matchUpdate.MatchHeader.IsBooked);
            this.St1Id = ((matchUpdate.MatchHeader == null || matchUpdate.MatchHeader.St1Id == null) ? this.St1Id : matchUpdate.MatchHeader.St1Id);
            this.St2Id = ((matchUpdate.MatchHeader == null || matchUpdate.MatchHeader.St2Id == null) ? this.St2Id : matchUpdate.MatchHeader.St2Id);
            this.SportId = ((matchUpdate.Sport == null || matchUpdate.Sport.Id == null || matchUpdate.Sport.Id.Value == 0) ? this.SportId : matchUpdate.Sport.Id.Value);
            this.SportName = ((matchUpdate.Sport == null || matchUpdate.Sport.Name == null) ? this.SportName : matchUpdate.Sport.Name);
            this.IsTieBreak = ((matchUpdate.IsTieBreak == null) ? this.IsTieBreak : matchUpdate.IsTieBreak);
            this.RedCards = ((matchUpdate.RedCards == null) ? this.RedCards : matchUpdate.RedCards);
            this.YellowCards = ((matchUpdate.YellowCards == null) ? this.YellowCards : matchUpdate.YellowCards);
            this.Corners = ((matchUpdate.Corners == null) ? this.Corners : matchUpdate.Corners);
            this.Serve = ((matchUpdate.Serve == Team.UNDEFINED) ? this.Serve : matchUpdate.Serve);
            this.DangerousAttacks = ((matchUpdate.DangerousAttacks == null) ? this.DangerousAttacks : matchUpdate.DangerousAttacks);
            this.Penalties = ((matchUpdate.Penalties == null) ? this.Penalties : matchUpdate.Penalties);
            this.ShotsOffTarget = ((matchUpdate.ShotsOffTarget == null) ? this.ShotsOffTarget : matchUpdate.ShotsOffTarget);
            this.ShotsOnTarget = ((matchUpdate.ShotsOnTarget == null) ? this.ShotsOnTarget : matchUpdate.ShotsOnTarget);
            this.Throwins = ((matchUpdate.Throwins == null) ? this.Throwins : matchUpdate.Throwins);
            this.GoalKicks = ((matchUpdate.GoalKicks == null) ? this.GoalKicks : matchUpdate.GoalKicks);
            this.FreeKicks = ((matchUpdate.FreeKicks == null) ? this.FreeKicks : matchUpdate.FreeKicks);
            this.ShotsBlocked = ((matchUpdate.ShotsBlocked == null) ? this.ShotsBlocked : matchUpdate.ShotsBlocked);
            this.GoalkeeperSaves = ((matchUpdate.GoalkeeperSaves == null) ? this.GoalkeeperSaves : matchUpdate.GoalkeeperSaves);
            this.Offsides = ((matchUpdate.Offsides == null) ? this.Offsides : matchUpdate.Offsides);
            this.Injuries = ((matchUpdate.Injuries == null) ? this.Injuries : matchUpdate.Injuries);
            this.Suspensions = ((matchUpdate.Suspensions == null) ? this.Suspensions : matchUpdate.Suspensions);
            this.FreeThrows = ((matchUpdate.FreeThrows == null) ? this.FreeThrows : matchUpdate.FreeThrows);
            this.DirectFoulsPeriod = ((matchUpdate.DirectFoulsPeriod == null) ? this.DirectFoulsPeriod : matchUpdate.DirectFoulsPeriod);
            this.DirectFreeKicks = ((matchUpdate.DirectFreeKicks == null) ? this.DirectFreeKicks : matchUpdate.DirectFreeKicks);
            this.Possession = ((matchUpdate.Possession == null) ? this.Possession : matchUpdate.Possession);
            this.PossessionTeam = ((matchUpdate.PossessionTeam == Team.UNDEFINED) ? this.PossessionTeam : matchUpdate.PossessionTeam);
            this.SurfaceType = ((matchUpdate.SurfaceType == SurfaceType.UNDEFINED) ? this.SurfaceType : matchUpdate.SurfaceType);
            this.WeatherConditions = ((matchUpdate.WeatherConditions == WeatherConditions.UNDEFINED) ? this.WeatherConditions : matchUpdate.WeatherConditions);
            this.PitchConditions = ((matchUpdate.PitchConditions == PitchConditions.UNDEFINED) ? this.PitchConditions : matchUpdate.PitchConditions);
            this.MatchStatus = ((matchUpdate.MatchStatus == ScoutMatchStatus.UNDEFINED) ? this.MatchStatus : matchUpdate.MatchStatus);
            this.MatchStatusStart = ((matchUpdate.MatchStatusStart == DateTime.MinValue) ? this.MatchStatusStart : matchUpdate.MatchStatusStart);
            this.CategoryId = ((matchUpdate.Category == null || matchUpdate.Category.Id == null || matchUpdate.Category.Id.Value == 0) ? this.CategoryId : matchUpdate.Category.Id.Value);
            this.CategoryName = ((matchUpdate.Category == null || matchUpdate.Category.Name == null) ? this.CategoryName : matchUpdate.Category.Name);
            this.TournamentId = ((matchUpdate.Tournament == null || matchUpdate.Tournament.Id == null || matchUpdate.Tournament.Id.Value == 0) ? this.TournamentId : matchUpdate.Tournament.Id.Value);
            this.TournamentName = ((matchUpdate.Tournament == null || matchUpdate.Tournament.Name == null) ? this.TournamentName : matchUpdate.Tournament.Name);
            this.KickoffTeam = ((matchUpdate.KickoffTeam == null) ? this.KickoffTeam : matchUpdate.KickoffTeam);

            if ((matchUpdate.Score != null)
                && (matchUpdate.Score.Count > 0))
            {
                foreach (var entry in matchUpdate.Score)
                {
                    var scoreModel = this._Scores.SingleOrDefault(sm => sm.ScoreType == entry.Key);
                    if (scoreModel == null)
                    {
                        this._Scores.InsertInOrder(new ScoreModel(entry.Key, entry.Value));
                    }
                    else
                    {
                        scoreModel.Load(entry.Key, entry.Value);
                    }
                }
            }
            if ((matchUpdate.Events != null)
                && (matchUpdate.Events.Count > 0))
            {
                foreach (var entry in matchUpdate.Events)
                {
                    var scountEventModel = this._ScountEvents.SingleOrDefault(se => se.Id == entry.Id);
                    if (scountEventModel == null)
                    {
                        this._ScountEvents.InsertInOrder(new ScoutEventModel(entry));
                    }
                    else
                    {
                        scountEventModel.Load(entry);
                    }
                }
            }
        }

        private long _MatchId = 0;
        private DateTime? _Start = null;
        private long _Team1Id = 0;
        private LocalizedString _Team1Name = null;
        private long _Team2Id = 0;
        private LocalizedString _Team2Name = null;
        private MatchBetStatus? _BetStatus = null;
        private ScoutFeedType? _TypeOfFeed = null;
        private int? _Distance = null;
        private int? _ExtraInfo = null;
        private bool? _IsDeepCoverage = null;
        private bool? _IsTimeRunning = null;
        private Coverage? _CoveredFrom = null;
        private bool? _ConnectionStatus = null;
        private Team? _WonJumpBall = null;
        private Team? _FirstServe = null;
        private Team? _FirstServeTieBreak = null;
        private int? _NumberOfSets = null;
        private bool? _TieBreakLastSet = null;
        private bool? _IsBooked = null;
        private int? _St1Id = null;
        private int? _St2Id = null;
        private long _SportId = 0;
        private LocalizedString _SportName = null;
        private bool? _IsTieBreak = null;
        private HomeAway<int> _RedCards = null;
        private HomeAway<int> _YellowCards = null;
        private HomeAway<int> _YellowRedCards = null;
        private HomeAway<int> _Corners = null;
        private Team _Serve = Team.UNDEFINED;
        private HomeAway<int> _DangerousAttacks = null;
        private HomeAway<int> _Penalties = null;
        private HomeAway<int> _ShotsOffTarget = null;
        private HomeAway<int> _ShotsOnTarget = null;
        private HomeAway<int> _Throwins = null;
        private HomeAway<int> _GoalKicks = null;
        private HomeAway<int> _FreeKicks = null;
        private HomeAway<int> _ShotsBlocked = null;
        private HomeAway<int> _GoalkeeperSaves = null;
        private HomeAway<int> _Offsides = null;
        private HomeAway<int> _Injuries = null;
        private Suspensions _Suspensions = null;
        private HomeAway<int> _FreeThrows = null;
        private HomeAway<int> _DirectFoulsPeriod = null;
        private HomeAway<int> _DirectFreeKicks = null;
        private HomeAway<int?> _Possession = null;
        private Team _PossessionTeam = Team.UNDEFINED;
        private SurfaceType _SurfaceType = SurfaceType.UNDEFINED;
        private WeatherConditions _WeatherConditions = WeatherConditions.UNDEFINED;
        private PitchConditions _PitchConditions = PitchConditions.UNDEFINED;
        private ScoutMatchStatus _MatchStatus = ScoutMatchStatus.UNDEFINED;
        private DateTime _MatchStatusStart = DateTime.MinValue;
        private long _CategoryId = 0;
        private LocalizedString _CategoryName = null;
        private long _TournamentId = 0;
        private LocalizedString _TournamentName = null;
        private Team? _KickoffTeam = null;
        private readonly ObservableCollection<ScoreModel> _Scores = new ObservableCollection<ScoreModel>();
        private readonly ObservableCollection<ScoutEventModel> _ScountEvents = new ObservableCollection<ScoutEventModel>();

        public long MatchId
        {
            get { return this.GetProperty(ref this._MatchId); }
            private set { this.SetProperty(ref this._MatchId, value, "MatchId"); }
        }
        public DateTime? Start
        {
            get { return this.GetProperty(ref this._Start); }
            private set { this.SetProperty(ref this._Start, value, "Start"); }
        }
        public long Team1Id
        {
            get { return this.GetProperty(ref this._Team1Id); }
            private set { this.SetProperty(ref this._Team1Id, value, "Team1Id"); }
        }
        public LocalizedString Team1Name
        {
            get { return this.GetProperty(ref this._Team1Name); }
            private set { this.SetProperty(ref this._Team1Name, value, "Team1Name"); }
        }
        public long Team2Id
        {
            get { return this.GetProperty(ref this._Team2Id); }
            private set { this.SetProperty(ref this._Team2Id, value, "Team2Id"); }
        }
        public LocalizedString Team2Name
        {
            get { return this.GetProperty(ref this._Team2Name); }
            private set { this.SetProperty(ref this._Team2Name, value, "Team2Name"); }
        }

        public MatchBetStatus? BetStatus
        {
            get { return this.GetProperty(ref this._BetStatus); }           
            private set { this.SetProperty(ref this._BetStatus, value, "BetStatus"); }
        }
        public ScoutFeedType? TypeOfFeed
        {
            get { return this.GetProperty(ref this._TypeOfFeed); }
            private set { this.SetProperty(ref this._TypeOfFeed, value, "TypeOfFeed"); }
        }
        public int? Distance
        {
            get { return this.GetProperty(ref this._Distance); }
            private set { this.SetProperty(ref this._Distance, value, "Distance"); }
        }
        public int? ExtraInfo
        {
            get { return this.GetProperty(ref this._ExtraInfo); }
            private set { this.SetProperty(ref this._ExtraInfo, value, "ExtraInfo"); }
        }
        public bool? IsDeepCoverage
        {
            get { return this.GetProperty(ref this._IsDeepCoverage); }
            private set { this.SetProperty(ref this._IsDeepCoverage, value, "IsDeepCoverage"); }
        }
        public bool? IsTimeRunning
        {
            get { return this.GetProperty(ref this._IsTimeRunning); }
            private set { this.SetProperty(ref this._IsTimeRunning, value, "IsTimeRunning"); }
        }
        public Coverage? CoveredFrom
        {
            get { return this.GetProperty(ref this._CoveredFrom); }
            private set { this.SetProperty(ref this._CoveredFrom, value, "CoveredFrom"); }
        }
        public bool? ConnectionStatus
        {
            get { return this.GetProperty(ref this._ConnectionStatus); }
            private set { this.SetProperty(ref this._ConnectionStatus, value, "ConnectionStatus"); }
        }
        public Team? WonJumpBall
        {
            get { return this.GetProperty(ref this._WonJumpBall); }
            private set { this.SetProperty(ref this._WonJumpBall, value, "WonJumpBall"); }
        }
        public Team? FirstServe
        {
            get { return this.GetProperty(ref this._FirstServe); }
            private set { this.SetProperty(ref this._FirstServe, value, "FirstServe"); }
        }
        public Team? FirstServeTieBreak
        {
            get { return this.GetProperty(ref this._FirstServeTieBreak); }
            private set { this.SetProperty(ref this._FirstServeTieBreak, value, "FirstServeTieBreak"); }
        }
        public int? NumberOfSets
        {
            get { return this.GetProperty(ref this._NumberOfSets); }
            private set { this.SetProperty(ref this._NumberOfSets, value, "NumberOfSets"); }
        }
        public bool? TieBreakLastSet
        {
            get { return this.GetProperty(ref this._TieBreakLastSet); }
            private set { this.SetProperty(ref this._TieBreakLastSet, value, "TieBreakLastSet"); }
        }
        public bool? IsBooked
        {
            get { return this.GetProperty(ref this._IsBooked); }
            set { this.SetProperty(ref this._IsBooked, value, "IsBooked"); }
        }
        public int? St1Id
        {
            get { return this.GetProperty(ref this._St1Id); }
            private set { this.SetProperty(ref this._St1Id, value, "St1Id"); }
        }
        public int? St2Id
        {
            get { return this.GetProperty(ref this._St2Id); }
            private set { this.SetProperty(ref this._St2Id, value, "St2Id"); }
        }
        public long SportId
        {
            get { return this.GetProperty(ref this._SportId); }
            private set { this.SetProperty(ref this._SportId, value, "SportId"); }
        }
        public LocalizedString SportName
        {
            get { return this.GetProperty(ref this._SportName); }
            private set { this.SetProperty(ref this._SportName, value, "SportName"); }
        }
        public bool? IsTieBreak
        {
            get { return this.GetProperty(ref this._IsTieBreak); }
            private set { this.SetProperty(ref this._IsTieBreak, value, "IsTieBreak"); }
        }
        public HomeAway<int> RedCards
        {
            get { return this.GetProperty(ref this._RedCards); }
            private set { this.SetProperty(ref this._RedCards, value, "RedCards"); }
        }
        public HomeAway<int> YellowCards
        {
            get { return this.GetProperty(ref this._YellowCards); }
            private set { this.SetProperty(ref this._YellowCards, value, "YellowCards"); }
        }
        public HomeAway<int> Corners
        {
            get { return this.GetProperty(ref this._Corners); }
            private set { this.SetProperty(ref this._Corners, value, "Corners"); }
        }
        public Team Serve
        {
            get { return this.GetProperty(ref this._Serve); }
            private set { this.SetProperty(ref this._Serve, value, "Serve"); }
        }
        public HomeAway<int> DangerousAttacks
        {
            get { return this.GetProperty(ref this._DangerousAttacks); }
            private set { this.SetProperty(ref this._DangerousAttacks, value, "DangerousAttacks"); }
        }
        public HomeAway<int> Penalties
        {
            get { return this.GetProperty(ref this._Penalties); }
            private set { this.SetProperty(ref this._Penalties, value, "Penalties"); }
        }
        public HomeAway<int> ShotsOffTarget
        {
            get { return this.GetProperty(ref this._ShotsOffTarget); }
            private set { this.SetProperty(ref this._ShotsOffTarget, value, "ShotsOffTarget"); }
        }
        public HomeAway<int> ShotsOnTarget
        {
            get { return this.GetProperty(ref this._ShotsOnTarget); }
            private set { this.SetProperty(ref this._ShotsOnTarget, value, "ShotsOnTarget"); }
        }
        public HomeAway<int> Throwins
        {
            get { return this.GetProperty(ref this._Throwins); }
            private set { this.SetProperty(ref this._Throwins, value, "Throwins"); }
        }
        public HomeAway<int> GoalKicks
        {
            get { return this.GetProperty(ref this._GoalKicks); }
            private set { this.SetProperty(ref this._GoalKicks, value, "GoalKicks"); }
        }
        public HomeAway<int> FreeKicks
        {
            get { return this.GetProperty(ref this._FreeKicks); }
            private set { this.SetProperty(ref this._FreeKicks, value, "FreeKicks"); }
        }
        public HomeAway<int> ShotsBlocked
        {
            get { return this.GetProperty(ref this._ShotsBlocked); }
            private set { this.SetProperty(ref this._ShotsBlocked, value, "ShotsBlocked"); }
        }
        public HomeAway<int> GoalkeeperSaves
        {
            get { return this.GetProperty(ref this._GoalkeeperSaves); }
            private set { this.SetProperty(ref this._GoalkeeperSaves, value, "GoalkeeperSaves"); }
        }
        public HomeAway<int> Offsides
        {
            get { return this.GetProperty(ref this._Offsides); }
            private set { this.SetProperty(ref this._Offsides, value, "Offsides"); }
        }
        public HomeAway<int> Injuries
        {
            get { return this.GetProperty(ref this._Injuries); }
            private set { this.SetProperty(ref this._Injuries, value, "Injuries"); }
        }
        public Suspensions Suspensions
        {
            get { return this.GetProperty(ref this._Suspensions); }
            private set { this.SetProperty(ref this._Suspensions, value, "Suspensions"); }
        }
        public HomeAway<int> FreeThrows
        {
            get { return this.GetProperty(ref this._FreeThrows); }
            private set { this.SetProperty(ref this._FreeThrows, value, "FreeThrows"); }
        }
        public HomeAway<int> DirectFoulsPeriod
        {
            get { return this.GetProperty(ref this._DirectFoulsPeriod); }
            private set { this.SetProperty(ref this._DirectFoulsPeriod, value, "DirectFoulsPeriod"); }
        }
        public HomeAway<int> DirectFreeKicks
        {
            get { return this.GetProperty(ref this._DirectFreeKicks); }
            private set { this.SetProperty(ref this._DirectFreeKicks, value, "DirectFreeKicks"); }
        }
        public HomeAway<int?> Possession
        {
            get { return this.GetProperty(ref this._Possession); }
            private set { this.SetProperty(ref this._Possession, value, "Possession"); }
        }
        public Team PossessionTeam
        {
            get { return this.GetProperty(ref this._PossessionTeam); }
            private set { this.SetProperty(ref this._PossessionTeam, value, "PossessionTeam"); }
        }
        public SurfaceType SurfaceType
        {
            get { return this.GetProperty(ref this._SurfaceType); }
            private set { this.SetProperty(ref this._SurfaceType, value, "SurfaceType"); }
        }
        public WeatherConditions WeatherConditions
        {
            get { return this.GetProperty(ref this._WeatherConditions); }
            private set { this.SetProperty(ref this._WeatherConditions, value, "WeatherConditions"); }
        }
        public PitchConditions PitchConditions
        {
            get { return this.GetProperty(ref this._PitchConditions); }
            private set { this.SetProperty(ref this._PitchConditions, value, "PitchConditions"); }
        }
        public ScoutMatchStatus MatchStatus
        {
            get { return this.GetProperty(ref this._MatchStatus); }
            private set { this.SetProperty(ref this._MatchStatus, value, "ScoutMatchStatus"); }
        }
        public DateTime MatchStatusStart
        {
            get { return this.GetProperty(ref this._MatchStatusStart); }
            private set { this.SetProperty(ref this._MatchStatusStart, value, "MatchStatusStart"); }
        }
        public long CategoryId
        {
            get { return this.GetProperty(ref this._CategoryId); }
            private set { this.SetProperty(ref this._CategoryId, value, "CategoryId"); }
        }
        public LocalizedString CategoryName
        {
            get { return this.GetProperty(ref this._CategoryName); }
            private set { this.SetProperty(ref this._CategoryName, value, "CategoryName"); }
        }
        public long TournamentId
        {
            get { return this.GetProperty(ref this._TournamentId); }
            private set { this.SetProperty(ref this._TournamentId, value, "TournamentId"); }
        }
        public LocalizedString TournamentName
        {
            get { return this.GetProperty(ref this._TournamentName); }
            private set { this.SetProperty(ref this._TournamentName, value, "TournamentName"); }
        }
        public Team? KickoffTeam
        {
            get { return this.GetProperty(ref this._KickoffTeam); }
            private set { this.SetProperty(ref this._KickoffTeam, value, "KickoffTeam"); }
        }
        public ObservableCollection<ScoreModel> Scores { get { return this._Scores; } }
        public ObservableCollection<ScoutEventModel> ScountEvents { get { return this._ScountEvents; } }

        public int CompareTo(MatchModel other)
        {
            if (other == null)
            {
                return -1;
            }

            return this.MatchId.CompareTo(other.MatchId);
        }

        public bool Equals(MatchModel other)
        {
            return (this.CompareTo(other) == 0);
        }
    }
}
