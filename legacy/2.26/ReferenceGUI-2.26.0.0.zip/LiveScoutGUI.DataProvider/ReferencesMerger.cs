﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using log4net;
using Merged::Sportradar.SDK.Common;
using Merged::Sportradar.SDK.FeedProviders.LiveScout;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Common;
using Merged::Sportradar.SDK.Services.QueueStats;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Threading;

namespace Sportradar.Demo.GUI.LiveScout.DataProvider
{
    /// <summary>
    /// Takes care of merging data from events and wraps SDK
    /// calls for ChangeTracker 
    /// </summary>
    public class ReferencesMerger
    {
        private ReferencesMerger()
        {
        }

        private readonly ILog _Logger = LogManager.GetLogger(typeof(ReferencesMerger));

        private readonly Dispatcher _Dispatcher = Application.Current.Dispatcher;

        private readonly static Lazy<ReferencesMerger> _Instance = new Lazy<ReferencesMerger>(() => new ReferencesMerger(), true);

        public static ReferencesMerger Instance { get { return _Instance.Value; } }

        #region --- Public methods ---

        /// <summary>
        /// Helper method to show MessageBox.
        /// </summary>
        /// <param name="exc"></param>
        public void ShowError(Exception exc)
        {
            MessageBox.Show(
                string.Format(
                    "{0}{1}{1}{2}{1}{1}{3}",
                    GuiStrings.Instance.UnexpectedError,
                    Environment.NewLine,
                    exc.Message,
                    exc.StackTrace),
                GuiStrings.Instance.Error,
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }

        /// <summary>
        /// Merges data from ScoutInfo event
        /// </summary>
        /// <param name="matchId"></param>
        /// <param name="scoutInfos"></param>
        public void MergeScoutInfo(long matchId, IList<ScoutInfo> scoutInfos)
        {
            _Logger.InfoFormat(
                "MergeScoutInfo: matchId {0}",
                matchId);

            this.MergeScoutInfoDispatcherThread(matchId, scoutInfos);
        }

        /// <summary>
        /// Merges data from MatchUpdate event
        /// </summary>
        /// <param name="matchUpdate"></param>
        public void MergeMatchUpdate(MatchUpdate matchUpdate)
        {
            _Logger.InfoFormat(
                "MergeMatchUpdate: matchId {0}",
                ((matchUpdate == null) || (matchUpdate.MatchHeader == null)) ? 0 : matchUpdate.MatchHeader.MatchId);

            this.MergeMatchUpdateDispatcherThread(matchUpdate);
        }

        /// <summary>
        /// Merges data from MatchStop event
        /// </summary>
        /// <param name="matchId"></param>
        /// <param name="reason"></param>
        public void MergeMatchStop(long matchId, string reason)
        {
            _Logger.InfoFormat(
                "MergeMatchStop: match id {0}, reason {1}",
                matchId, reason);

            this.MergeMatchStopDispatcherThread(matchId, reason);
        }

        /// <summary>
        /// Merges data from MatchList event
        /// </summary>
        /// <param name="matchUpdates"></param>
        public void MergeMatchList(IList<MatchUpdate> matchUpdates)
        {
            _Logger.InfoFormat(
                "MergeMatchList: {0} match updates",
                (matchUpdates == null) ? 0 : matchUpdates.Count);

            this.MergeMatchListDispatcherThread(matchUpdates);
        }

        /// <summary>
        /// Clears loaded matches
        /// </summary>
        public void ClearLoadedMatches()
        {
            _Logger.Info("ClearLoadedMatches");

            this.ClearLoadedMatchesDispatcherThread();
        }

        /// <summary>
        /// Marks match as subscibed
        /// </summary>
        /// <param name="matchId"></param>
        public void SubscribeMatch(long matchId)
        {
            _Logger.InfoFormat(
                "SubscribeMatch: {0}",
                matchId);

            this.SubscribeMatchDispatcherThread(matchId);
        }

        /// <summary>
        /// Marks match as unsubscibed
        /// </summary>
        /// <param name="matchId"></param>
        public void UnsubscribeMatch(long matchId)
        {
            _Logger.InfoFormat(
                "UnsubscribeMatch: {0}",
                matchId);

            this.UnsubscribeMatchDispatcherThread(matchId);
        }

        /// <summary>
        /// Merges data from queue stats
        /// </summary>
        /// <param name="stats"></param>
        public void MergeDispatcherQueueStats(IList<ClientQueueStats> stats)
        {
            _Logger.Info("MergeDispatcherQueueStats");

            this.MergeDispatcherQueueStatsDispatcherThread(stats);
        }

        /// <summary>
        /// Merges notification
        /// </summary>
        /// <param name="matchId"></param>
        /// <param name="localTimestamp"></param>
        /// <param name="serverTimestamp"></param>
        /// <param name="msg"></param>
        public void MergeNotification(long matchId, DateTime localTimestamp, DateTime? serverTimestamp, string msg)
        {
            _Logger.InfoFormat(
                "MergeNotification: matchId: {0}, local timestamp: {1}, server timestamp: {2}, message: {3}",
                matchId, localTimestamp, serverTimestamp, msg);

            this.MergeNotificationDispatcherThread(matchId, localTimestamp, serverTimestamp, msg);
        }

        /// <summary>
        /// Merges match as booked
        /// </summary>
        /// <param name="matchId"></param>
        public void MergeMatchAsBooked(long matchId)
        {
            _Logger.InfoFormat(
                "MergeMatchAsBooked: matchId: {0}",
                matchId);

            this.MergeMatchAsBookedDispatcherThread(matchId);
        }

        /// <summary>
        /// Merges ServerTime
        /// </summary>
        /// <param name="serverTime"></param>
        public void MergeServerTime(DateTime? serverTime)
        {
            this.MergeServerTimeDispatcherThread(serverTime);
        }

        #endregion

        #region --- Private methods ---

        private void MergeScoutInfoDispatcherThread(long matchId, IList<ScoutInfo> scoutInfos)
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                _Logger.DebugFormat(
                    "MergeScoutInfoDispatcherThread: enqueue: matchId {0}",
                    matchId);

                this.InvokeInDispatcherThread(() => this.MergeScoutInfoDispatcherThread(matchId, scoutInfos));
                return;
            }

            _Logger.DebugFormat(
                    "MergeScoutInfoDispatcherThread: process: matchId {0}",
                    matchId);

            ObservableCollection<ScoutInfoModel> scoutInfoModels;
            if (!References.Instance.ScoutInfosPerMatch.TryGetValue(matchId, out scoutInfoModels))
            {
                return;
            }

            if ((scoutInfos != null)
                && (scoutInfos.Count > 0))
            {
                foreach (var scoutInfo in scoutInfos)
                {
                    if (scoutInfo == null)
                    {
                        continue;
                    }

                    ScoutInfoModel scoutInfoModel = new ScoutInfoModel(scoutInfo);
                    int index = scoutInfoModels.IndexOf(scoutInfoModel);
                    if (index < 0)
                    {
                        scoutInfoModels.Add(scoutInfoModel);
                    }
                    else
                    {
                        scoutInfoModels[index].Load(scoutInfo);
                    }
                }
            }
        }

        private void MergeMatchUpdateDispatcherThread(MatchUpdate matchUpdate)
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                _Logger.DebugFormat(
                    "MergeMatchUpdateDispatcherThread: enqueue: matchId {0}",
                    ((matchUpdate == null) || (matchUpdate.MatchHeader == null)) ? 0 : matchUpdate.MatchHeader.MatchId);

                this.InvokeInDispatcherThread(() => this.MergeMatchUpdateDispatcherThread(matchUpdate));
                return;
            }

            _Logger.DebugFormat(
                "MergeMatchUpdateDispatcherThread: process: matchId {0}",
                ((matchUpdate == null) || (matchUpdate.MatchHeader == null)) ? 0 : matchUpdate.MatchHeader.MatchId);

            if ((matchUpdate == null)
                || (matchUpdate.MatchHeader == null))
            {
                return;
            }

            this.UpdateMatch(matchUpdate.MatchHeader.MatchId, matchUpdate, false);
        }

        private void MergeMatchStopDispatcherThread(long matchId, string reason)
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                _Logger.DebugFormat(
                    "MergeMatchStopDispatcherThread: enqueue: match id {0}, reason {1}",
                    matchId, reason);

                this.InvokeInDispatcherThread(() => this.MergeMatchStopDispatcherThread(matchId, reason));
                return;
            }

            _Logger.DebugFormat(
                "MergeMatchStopDispatcherThread: process: match id {0}, reason {1}",
                matchId, reason);
        }

        private void MergeMatchListDispatcherThread(IList<MatchUpdate> matchUpdates)
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                _Logger.DebugFormat(
                    "MergeMatchListDispatcherThread: enqueue: {0} match updates",
                    (matchUpdates == null) ? 0 : matchUpdates.Count);

                this.InvokeInDispatcherThread(() => this.MergeMatchListDispatcherThread(matchUpdates));
                return;
            }

            _Logger.DebugFormat(
                "MergeMatchListDispatcherThread: process: {0} match updates",
                (matchUpdates == null) ? 0 : matchUpdates.Count);

            if ((matchUpdates == null) || (matchUpdates.Count == 0))
            {
                return;
            }

            foreach (var matchUpdate in matchUpdates)
            {
                if ((matchUpdate == null)
                    || (matchUpdate.MatchHeader == null))
                {
                    continue;
                }

                long matchId = matchUpdate.MatchHeader.MatchId;

                this.UpdateMatch(matchId, matchUpdate, true);
                if (!References.Instance.LoadedMatchIds.Contains(matchId))
                {
                    References.Instance.LoadedMatchIds.Add(matchId);
                }
            }
        }

        private void ClearLoadedMatchesDispatcherThread()
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                _Logger.Debug("ClearLoadedMatchesDispatcherThread: enqueue");

                this.InvokeInDispatcherThread(() => this.ClearLoadedMatchesDispatcherThread());
                return;
            }

            _Logger.Debug("ClearLoadedMatchesDispatcherThread: process");

            References.Instance.LoadedMatchIds.Clear();
            var matchesToBeDeleted = References.Instance.Matches.Keys.Where(k => !References.Instance.SubscribedMatchIds.Contains(k)).ToArray();
            foreach (var matchToBeDeleted in matchesToBeDeleted)
            {
                this.RemoveMatch(matchToBeDeleted);
            }
        }

        private void SubscribeMatchDispatcherThread(long matchId)
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                _Logger.DebugFormat(
                    "SubscribeMatchDispatcherThread: enqueue: {0}",
                    matchId);

                this.InvokeInDispatcherThread(() => this.SubscribeMatchDispatcherThread(matchId));
                return;
            }

            _Logger.DebugFormat(
                    "SubscribeMatchDispatcherThread: process: {0}",
                    matchId);

            this.AddMatch(matchId);
            if (!References.Instance.SubscribedMatchIds.Contains(matchId))
            {
                References.Instance.SubscribedMatchIds.Add(matchId);
            }
        }

        private void UnsubscribeMatchDispatcherThread(long matchId)
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                _Logger.DebugFormat(
                    "UnsubscribeMatchDispatcherThread: enqueue: {0}",
                    matchId);

                this.InvokeInDispatcherThread(() => this.UnsubscribeMatchDispatcherThread(matchId));
                return;
            }

            _Logger.DebugFormat(
                    "UnsubscribeMatchDispatcherThread: process: {0}",
                    matchId);

            if (References.Instance.SubscribedMatchIds.Contains(matchId))
            {
                References.Instance.SubscribedMatchIds.Remove(matchId);

                if (!References.Instance.LoadedMatchIds.Contains(matchId))
                {
                    this.RemoveMatch(matchId);
                }
            }
        }

        private void MergeDispatcherQueueStatsDispatcherThread(IList<ClientQueueStats> stats)
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                _Logger.Debug("MergeDispatcherQueueStatsDispatcherThread: enqueue");

                this.InvokeInDispatcherThread(() => this.MergeDispatcherQueueStatsDispatcherThread(stats));
                return;
            }

            _Logger.Debug("MergeDispatcherQueueStatsDispatcherThread: process");

            References.Instance.DispatcherQueueStatsModel.Load(stats);
        }

        private void MergeNotificationDispatcherThread(long matchId, DateTime localTimestamp, DateTime? serverTimestamp, string msg)
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                _Logger.DebugFormat(
                    "MergeNotificationDispatcherThread: enqueue: matchId: {0}, local timestamp: {1}, server timestamp: {2}, message: {3}",
                    matchId, localTimestamp, serverTimestamp, msg);

                this.InvokeInDispatcherThread(() => this.MergeNotificationDispatcherThread(matchId, localTimestamp, serverTimestamp, msg));
                return;
            }

            _Logger.DebugFormat(
                "MergeNotificationDispatcherThread: process: matchId: {0}, local timestamp: {1}, server timestamp: {2}, message: {3}",
                matchId, localTimestamp, serverTimestamp, msg);

            if (!References.Instance.NotificationsPerMatch.ContainsKey(matchId))
            {
                return;
            }

            References.Instance.NotificationsPerMatch[matchId].InsertInOrder(new NotificationModel(localTimestamp, serverTimestamp, msg));
        }

        private void MergeMatchAsBookedDispatcherThread(long matchId)
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                _Logger.DebugFormat(
                    "MergeMatchAsBookedDispatcherThread: enqueue: matchId: {0}",
                    matchId);

                this.InvokeInDispatcherThread(() => this.MergeMatchAsBookedDispatcherThread(matchId));
                return;
            }

            _Logger.DebugFormat(
                    "MergeMatchAsBookedDispatcherThread: process: matchId: {0}",
                    matchId);

            if (References.Instance.Matches.ContainsKey(matchId))
            {
                References.Instance.Matches[matchId].IsBooked = true;
            }
        }

        private void UpdateMatch(long matchId, MatchUpdate matchUpdate, bool insertIfMissing)
        {
            if (References.Instance.Matches.ContainsKey(matchId))
            {
                References.Instance.Matches[matchId].Load(matchUpdate);
            }
            else if (insertIfMissing)
            {
                References.Instance.Matches.Add(matchId, new MatchModel(matchUpdate));
            }
        }

        private void AddMatch(long matchId)
        {
            this.AddMatch(matchId, new MatchModel(matchId));
        }

        private void AddMatch(long matchId, MatchModel matchModel)
        {
            if ((matchModel != null)
                && (matchModel.SportName != null)
                && (!string.IsNullOrWhiteSpace(matchModel.SportName.International))
                && (!References.Instance.Sports.Any(fi => fi.ItemId == matchModel.SportId)))
            {
                References.Instance.Sports.Add(new FilterItemModel(matchModel.SportId, matchModel.SportName));
            }
            if ((matchModel != null)
                && (matchModel.CategoryName != null)
                && (!string.IsNullOrWhiteSpace(matchModel.CategoryName.International))
                && (!References.Instance.Categories.Any(fi => fi.ItemId == matchModel.CategoryId)))
            {
                References.Instance.Categories.Add(new FilterItemModel(matchModel.CategoryId, matchModel.CategoryName));
            }
            if ((matchModel != null)
                && (matchModel.TournamentName != null)
                && (!string.IsNullOrWhiteSpace(matchModel.TournamentName.International))
                && (!References.Instance.Tournaments.Any(fi => fi.ItemId == matchModel.TournamentId)))
            {
                References.Instance.Tournaments.Add(new FilterItemModel(matchModel.TournamentId, matchModel.TournamentName));
            }

            if (!References.Instance.Matches.ContainsKey(matchId))
            {
                References.Instance.Matches.Add(matchId, matchModel);
            }
            if (!References.Instance.OddsValuesPerMatch.ContainsKey(matchId))
            {
                References.Instance.OddsValuesPerMatch.Add(matchId, new ObservableCollection<OddsValueModel>());
            }
            if (!References.Instance.ScoutInfosPerMatch.ContainsKey(matchId))
            {
                References.Instance.ScoutInfosPerMatch.Add(matchId, new ObservableCollection<ScoutInfoModel>());
            }
            if (!References.Instance.NotificationsPerMatch.ContainsKey(matchId))
            {
                References.Instance.NotificationsPerMatch.Add(matchId, new ObservableCollection<NotificationModel>());
            }
        }

        private void RemoveMatch(long matchId)
        {
            if (References.Instance.NotificationsPerMatch.ContainsKey(matchId))
            {
                References.Instance.NotificationsPerMatch.Remove(matchId);
            }
            if (References.Instance.ScoutInfosPerMatch.ContainsKey(matchId))
            {
                References.Instance.ScoutInfosPerMatch.Remove(matchId);
            }
            if (References.Instance.OddsValuesPerMatch.ContainsKey(matchId))
            {
                References.Instance.OddsValuesPerMatch.Remove(matchId);
            }
            if (References.Instance.Matches.ContainsKey(matchId))
            {
                References.Instance.Matches.Remove(matchId);
            }
        }

        private void MergeServerTimeDispatcherThread(DateTime? serverTime)
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                this.InvokeInDispatcherThread(() => this.MergeServerTimeDispatcherThread(serverTime));
                return;
            }

            References.Instance.ServerTimeModel.ServerTime = serverTime;
            References.Instance.ServerTimeModel.LocalTime = DateTime.Now;
        }

        private bool CheckDispatcherThreadAccess()
        {
            return this._Dispatcher.CheckAccess();
        }

        private void InvokeInDispatcherThread(Action action)
        {
            this._Dispatcher.Invoke(action, DispatcherPriority.Normal);
        }

        #endregion
    }
}
