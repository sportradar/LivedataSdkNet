﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;

namespace Sportradar.Demo.GUI.LiveOdds.Code
{
    public static class Extensions
    {
        public static bool ShowQuestion(this string questionMsg)
        {
            var result = MessageBox.Show(questionMsg, GuiStrings.Instance.Question, MessageBoxButton.YesNo, MessageBoxImage.Question);
            return (result == MessageBoxResult.Yes);
        }

        public static bool ShowInfo(this string infoMsg)
        {
            MessageBox.Show(infoMsg, GuiStrings.Instance.Info, MessageBoxButton.OK, MessageBoxImage.Information);
            return true;
        }

        public static bool ShowError(this string errorMsg)
        {
            MessageBox.Show(errorMsg, GuiStrings.Instance.Error, MessageBoxButton.OK, MessageBoxImage.Error);
            return true;
        }

        public static bool ShowError(this Exception exc)
        {
            MessageBox.Show(
                string.Format(
                    "{0}{1}{1}{2}{1}{1}{3}",
                    GuiStrings.Instance.UnexpectedError,
                    Environment.NewLine,
                    exc.Message,
                    exc.StackTrace),
                GuiStrings.Instance.Error,
                MessageBoxButton.OK,
                MessageBoxImage.Error);

            return true;
        }

        public static long[] ToArrayOfLong(this string input)
        {
            List<long> result = new List<long>();

            string[] values = (input ?? string.Empty).Split(",".ToArray());
            foreach (var value in values)
            {
                long id;
                if (long.TryParse(value.Trim(), out id))
                {
                    result.Add(id);
                }
            }

            return (result.Count == 0) ? null : result.ToArray();
        }

    }
}
