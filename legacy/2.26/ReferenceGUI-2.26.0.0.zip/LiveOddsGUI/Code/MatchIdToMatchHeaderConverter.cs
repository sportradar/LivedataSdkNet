﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Models;
using Sportradar.Demo.GUI.LiveOdds.DataProvider;

namespace Sportradar.Demo.GUI.LiveOdds.Code
{
    public class MatchIdToMatchHeaderConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if ((value != null) && (value is long))
            {
                long matchId = (long)value;

                MatchHeaderModel match;
                if (References.Instance.MatchHeaders.TryGetValue(matchId, out match))
                {
                    return match;
                }
            }

            return value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
