﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using Sportradar.Demo.GUI.LiveOdds.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Models;

namespace Sportradar.Demo.GUI.LiveOdds.Code
{
    public class BetTypeConverter  : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (values.Length ==2)
            {
                var bettype = values[0] as MatchOddsModel;
                var oddsfield = values[1] as OddsFieldValueModel;
                if (bettype != null && oddsfield != null)
                {
                    return new OddsBetTypeDataHolder(bettype, oddsfield);
                }

            }
            if (values.Length==1)
            {
                var bettype = values[0] as MatchOddsModel;
                if (bettype != null)
                {
                    return new OddsBetTypeDataHolder(bettype, null);
                }
            }
            return null;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
