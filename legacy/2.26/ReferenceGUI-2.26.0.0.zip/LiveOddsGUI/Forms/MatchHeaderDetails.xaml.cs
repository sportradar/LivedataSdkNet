﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Models;
using System.Windows;

namespace Sportradar.Demo.GUI.LiveOdds.Forms
{
    /// <summary>
    /// Interaction logic for MatchHeaderDetails.xaml
    /// </summary>
    public partial class MatchHeaderDetails : Window
    {
        private readonly MatchHeaderModel _matchHeader;

        public MatchHeaderDetails(MatchHeader matchHeader)
        {
            _matchHeader = new MatchHeaderModel(matchHeader);
            InitializeComponent();
            this.DataContext = this;
            HelperClass.FillGridWithObjectProperties(_matchHeader, HeaderDetailsGrid, 4);
        }

        public MatchHeaderModel MatchHeader
        {
            get { return _matchHeader; }
        }

    }
}
