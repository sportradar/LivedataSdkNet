﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Models;
using System.Windows;

namespace Sportradar.Demo.GUI.LiveOdds.Forms
{
    /// <summary>
    /// Interaction logic for MatchInfoDetails.xaml
    /// </summary>
    public partial class MatchInfoDetails : Window
    {
        private readonly MatchInfoModel _matchInfo;

        public MatchInfoDetails(MatchInfo matchInfo)
        {
            _matchInfo = new MatchInfoModel(matchInfo);
            InitializeComponent();
            this.DataContext = this;
            HelperClass.FillGridWithObjectProperties(_matchInfo, PropertiesGrid, 4);
        }

        public MatchInfoModel MatchInfo
        {
            get { return _matchInfo; }
        }
    }
}
