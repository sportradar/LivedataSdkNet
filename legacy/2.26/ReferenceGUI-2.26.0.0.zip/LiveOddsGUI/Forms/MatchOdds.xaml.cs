﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;

using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using Sportradar.Demo.GUI.LiveOdds.Code;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Models;
using System.Collections.ObjectModel;
using Sportradar.Demo.GUI.LiveOdds.DataProvider;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds;

namespace Sportradar.Demo.GUI.LiveOdds.Forms
{
    /// <summary>
    /// Interaction logic for MatchOdds.xaml
    /// </summary>
    public partial class MatchOdds : Window
    {
        private readonly long _MatchId;
        private readonly ListCollectionView _LoadedMatchOdds;

        public MatchOdds()
        {
            InitializeComponent();
        }

        public MatchOdds(long matchId)
            : this()
        {
            this._MatchId = matchId;

            ImprovedObservableCollection<MatchOddsModel> matchOdds;
            OnlyActive = true;
            References.Instance.MatchOdds.TryGetValue(this._MatchId, out matchOdds);
            if (matchOdds != null)
            {
                this._LoadedMatchOdds = new ListCollectionView(matchOdds);
                _LoadedMatchOdds.Filter = Filter;
                matchOdds.CollectionChanged += (sender, args) => _LoadedMatchOdds.Refresh();
            }
            this.DataContext = this;

        }

        private bool Filter(object o)
        {
            if (!OnlyActive) return true;

            var odd = o as MatchOddsModel;
            if (odd != null)
            {
                return odd.Active;
            }
            return false;
        }

        private void FilterChange(object sender, DataTransferEventArgs e)
        {
            _LoadedMatchOdds.Refresh();
        }

        public bool OnlyActive { get; set; }

        public GuiStrings GuiStrings
        {
            get { return GuiStrings.Instance; }
        }

        public ListCollectionView LoadedMatchOdds
        {
            get { return this._LoadedMatchOdds; }
        }

        public long MatchId
        {
            get { return _MatchId; }
        }

        private void ExpandCollapseRowDetails(object sender, MouseButtonEventArgs e)
        {
            var row = (DataGridRow)sender;
            if (row.DetailsVisibility == Visibility.Visible)
            {
                row.DetailsVisibility = Visibility.Collapsed;
            }
            else
            {
                row.DetailsVisibility = Visibility.Visible;
            }
        }

        private void CollapseAll(object sender, RoutedEventArgs e)
        {
            foreach (var item in OddsDataGrid.Items)
            {
                var row = OddsDataGrid.ItemContainerGenerator.ContainerFromItem(item) as DataGridRow;
                if (null != row)
                {
                    row.DetailsVisibility = Visibility.Collapsed;
                }
            }
        }
    }
}
