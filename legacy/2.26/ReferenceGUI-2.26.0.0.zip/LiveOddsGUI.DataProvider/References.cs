﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using log4net;
using Sportradar.Demo.GUI.LiveOdds.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Models;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider
{
    /// <summary>
    /// Contains object references (kind of cache)
    /// </summary>
    public class References
    {
        private References()
        {
        }

        private readonly ILog _Logger = LogManager.GetLogger(typeof(References));

        private readonly static Lazy<References> _Instance = new Lazy<References>(() => new References(), true);

        /// <summary>
        /// Instance of <see cref="References"/> class
        /// </summary>
        public static References Instance { get { return _Instance.Value; } }




        private readonly ImprovedObservableCollection<NotificationDisplayModel> _GlobalNotifications = new ImprovedObservableCollection<NotificationDisplayModel>();

        private readonly Dictionary<long, ImprovedObservableCollection<NotificationDisplayModel>> _PerMatchNotifications = new Dictionary<long, ImprovedObservableCollection<NotificationDisplayModel>>();

        private readonly ImprovedObservableCollection<long> _SubscribedMatchIds = new ImprovedObservableCollection<long>();

        private readonly ImprovedObservableCollection<long> _LoadedMatchIds = new ImprovedObservableCollection<long>();

        private readonly Dictionary<long, MatchHeaderModel> _MatchHeaders = new Dictionary<long, MatchHeaderModel>();

        private readonly Dictionary<long, MatchInfoModel> _MatchInfos = new Dictionary<long, MatchInfoModel>();

        private readonly Dictionary<long, ScoreCardSummaryModel> _MatchScoreCardSummaries = new Dictionary<long, ScoreCardSummaryModel>();

        private readonly Dictionary<long, ImprovedObservableCollection<MatchOddsModel>> _MatchOdds = new Dictionary<long, ImprovedObservableCollection<MatchOddsModel>>();

        private readonly DispatcherQueueStatsModel _DispatcherQueueStatsModel = new DispatcherQueueStatsModel();

        private readonly ImprovedObservableCollection<FilterElement> _MatchFiltersBySport = new ImprovedObservableCollection<FilterElement>();

        private readonly ImprovedObservableCollection<FilterElement> _MatchFiltersByCategory = new ImprovedObservableCollection<FilterElement>();

        private readonly ImprovedObservableCollection<FilterElement> _MatchFiltersByTournament = new ImprovedObservableCollection<FilterElement>();

        private readonly ImprovedObservableCollection<FilterNameCombo> _MatchFiltersCombinations = new ImprovedObservableCollection<FilterNameCombo>();

        private readonly MatchFilterChanged _MatchFilterChanged = new MatchFilterChanged();

        private readonly LanguagesHandler _LanguagesHandler = new LanguagesHandler();

        private readonly ServerTimeModel _ServerTimeModel = new ServerTimeModel();

        /// <summary>
        /// Contains notifications about alive, score card summary, meta info and on queue limit events
        /// </summary>
        public ImprovedObservableCollection<NotificationDisplayModel> GlobalNotifications { get { return this._GlobalNotifications; } }

        /// <summary>
        /// Contains notifications about bet start, bet stop, bet clear, bet clear rollback,
        /// bet cancel ,bet cancel undone and odds change events
        /// </summary>
        public Dictionary<long, ImprovedObservableCollection<NotificationDisplayModel>> PerMatchNotifications { get { return this._PerMatchNotifications; } }


        /// <summary>
        /// Collection of all the match ids
        /// </summary>
        public ImprovedObservableCollection<long> LoadedMatchIds { get { return this._LoadedMatchIds; } }

        /// <summary>
        /// Dictionary of match headers for all the matches. Key is match id
        /// </summary>
        public Dictionary<long, MatchHeaderModel> MatchHeaders { get { return this._MatchHeaders; } }

        /// <summary>
        /// Dictionary of match infos for all the matches. Key is match id
        /// </summary>
        public Dictionary<long, MatchInfoModel> MatchInfos { get { return this._MatchInfos; } }

        /// <summary>
        /// Dictionary of match score card summaries for all the matches. Key is match id
        /// </summary>
        public Dictionary<long, ScoreCardSummaryModel> MatchScoreCardSummaries { get { return this._MatchScoreCardSummaries; } }

        /// <summary>
        /// Dictionary of all the odds for all the matches. Key is match id
        /// </summary>
        public Dictionary<long, ImprovedObservableCollection<MatchOddsModel>> MatchOdds { get { return this._MatchOdds; } }

        /// <summary>
        /// Contains queues statistics
        /// </summary>
        public DispatcherQueueStatsModel DispatcherQueueStatsModel { get { return this._DispatcherQueueStatsModel; } }

        /// <summary>
        /// Collection of all sport names currently in matchlist. Enables filtering by sport name
        /// </summary>
        public ImprovedObservableCollection<FilterElement> AllSportFilters { get { return this._MatchFiltersBySport; } }

        /// <summary>
        /// Collection of all categories currently in matchlist. Enables filtering by category
        /// </summary>
        public ImprovedObservableCollection<FilterElement> AllCategoryFilters { get { return this._MatchFiltersByCategory; } }

        /// <summary>
        /// Collection of all tournaments currently in matchlist. Enables filtering by tournament
        /// </summary>
        public ImprovedObservableCollection<FilterElement> AllTournamentFilters { get { return this._MatchFiltersByTournament; } }


        /// <summary>
        /// Collection of all filter combinations. Used to display right subfilters when parent filter is chosen. 
        /// </summary>
        public ImprovedObservableCollection<FilterNameCombo> MatchFiltersCombinations { get { return this._MatchFiltersCombinations; } }

        /// <summary>
        /// For updating the GUI when filters change
        /// </summary>
        public MatchFilterChanged MatchFilterChanged { get { return this._MatchFilterChanged; } }

        /// <summary>
        /// Contains all available languages for translations 
        /// </summary>
        public LanguagesHandler LanguagesHandler { get { return _LanguagesHandler; } }

        /// <summary>
        /// Contains local and server time to be displayed in GUI
        /// </summary>
        public ServerTimeModel ServerTimeModel { get { return _ServerTimeModel; } }
    }
}
