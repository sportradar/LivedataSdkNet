﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/

extern alias Merged;
using System.Collections.Generic;
using log4net;
using Merged::Sportradar.SDK.Common.Interfaces;
using Merged::Sportradar.SDK.FeedProviders.Common;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds;
using Merged::Sportradar.SDK.Services.Sdk;
using Merged::Sportradar.SDK.Services.SdkConfiguration;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.Common;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Enums;
using System;
using System.Collections.Specialized;
using System.Threading.Tasks;
using System.Timers;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider
{

    /// <summary>
    /// Main data singleton class. It hooks on instance of SDK and subscribes to all possible LiveOdds events.
    /// Event handlers merge all received data for the GUI
    /// Enables calling all possible SDK requests with wrapped SDK method.
    /// </summary>
    public class ChangeTracker
    {
        private readonly static Lazy<ChangeTracker> _Instance = new Lazy<ChangeTracker>(() => new ChangeTracker(), true);

        private readonly ILog _Logger = LogManager.GetLogger(typeof(ChangeTracker));

        private readonly Timer _Timer;

        private ILiveOdds _oddsItf;

        private ChangeTracker()
        {
            //Timer to refresh queue statistics
            this._Timer = new Timer
            {
                AutoReset = true,
                Enabled = false,
                Interval = (1000 * 1)
            };
        }

        private void StartTimer()
        {
            this._Timer.Elapsed += TimerElapsed;
            this._Timer.Start();
        }

        private void TimerElapsed(object sender, ElapsedEventArgs e)
        {
            if (!Sdk.Instance.IsInitialized)
            {
                return;
            }

            var stats = Sdk.Instance.QueueStats;
            if (stats != null)
            {
                ReferencesMerger.Instance.MergeDispatcherQueueStats(stats);
            }

            ReferencesMerger.Instance.MergeServerTime(_oddsItf.ServerTime);
        }


        /// <summary>
        /// Gets the instance of ChangeTracker class.
        /// </summary>
        public static ChangeTracker Instance { get { return _Instance.Value; } }

        public delegate void ScoreCardEventDelegate(long matchid);

        /// <summary>
        /// Event to enable waiting for ScoreCardSummary reply 
        /// </summary>
        public event ScoreCardEventDelegate ScoreCardEvent;

        /// <summary>
        /// Triggered when SDK connects to server
        /// </summary>
        public event ConnectionProviderDelegates.ConnectionDelegate OnConnected;

        /// <summary>
        /// Triggered when connection is closed
        /// </summary>
        public event ConnectionProviderDelegates.ConnectionDelegate OnDisconnected;

        /// <summary>
        /// Connection status
        /// </summary>
        public bool Connected { get; private set; }

        #region --- ILiveOdds, ILiveFeeds ---

        /// <summary>
        /// Starts instance of SDK and LiveOdds provider. Also subscribes to all LiveOdds events
        /// </summary>
        /// <exception cref="DataProviderException">Failed to initialize LiveOdds provider.</exception>
        public void StartTracking(NameValueCollection app_config)
        {
            _Logger.Info("StartTracking");

            Sdk.Instance.Initialize(AppConfigFactory.FromSection("Sdk"));

            //Starts SDK
            Sdk.Instance.Start();

            //Starts timer that refreshes queue statistics
            StartTimer();

            //Sdk.Instance.QueueStats
            Sdk.Instance.OnQueueLimits += OnQueueLimits;


            var str = app_config["OddsType"] == null ? null : Convert.ToString(app_config["OddsType"]).ToUpperInvariant();

            switch (str)
            {
                case "VFL":
                    _Logger.Info("Using VFL LO");
                    _oddsItf = Sdk.Instance.LiveOddsVfl;
                    break;
                case "BETPAL":
                    _Logger.Info("Using BetPal LO");
                    _oddsItf = Sdk.Instance.BetPal;
                    break;
                default:
                    _Logger.Info("Using plain LO");
                    _oddsItf = Sdk.Instance.LiveOdds;
                    break;
            }

            if (_oddsItf != null)
            {

                //Subscribes to all events
                //Event handlers log event and pass event arguments
                //to ReferencesMerger which takes care of merging data
                _oddsItf.OnAlive += OnLiveOddsOnAliveReceived;
                _oddsItf.OnFeedError += LiveOddsOnFeedErrorOccured;
                _oddsItf.OnBetCancel += LiveOddsOnMatchBetCancelled;
                _oddsItf.OnBetCancelUndo += LiveOddsOnMatchBetCancelUndo;
                _oddsItf.OnBetClear += LiveOddsOnMatchBetCleared;
                _oddsItf.OnBetClearRollback += LiveOddsOnMatchBetClearRollbacked;
                _oddsItf.OnBetStart += LiveOddsOnBetStarted;
                _oddsItf.OnBetStop += LiveOddsOnBetStopped;
                _oddsItf.OnMetaInfo += LiveOddsOnMetaInfoReceived;
                _oddsItf.OnOddsChange += LiveOddsOnOddsChanged;
                _oddsItf.OnScoreCardSummary += LiveOddsOnScoreCardSummaryReceived;
                _oddsItf.OnConnectionStable += _oddsItf_OnConnectionStable;
                
                //We wrap OnConnected & OnDisconnected events with our own
                var x = ((Merged::Sportradar.SDK.FeedProviders.LiveOdds.Internal.LiveOddsFeedProvider) _oddsItf).ProtoProvider;
                x.OnConnected += (t) =>
                {
                    Connected = true;
                    if (OnConnected != null)
                    {
                        OnConnected(null);
                    }
                };
                x.OnDisconnected += (t) =>
                {
                    Connected = false;
                    if (OnDisconnected != null)
                    {
                        OnDisconnected(null);
                    }
                };

                //Starts LiveOdds provider
                _oddsItf.Start();
                ReferencesMerger.Instance.PeriodicallyReadAvailableTranslations(_oddsItf.AvailableTranslations);

            }
            else
            {
                throw new DataProviderException("Failed to initialize LiveOdds provider.");
            }
        }

        void _oddsItf_OnConnectionStable(object sender, EventArgs e)
        {
            if (_oddsItf.TestManager != null)
            {
                _oddsItf.TestManager.StartAuto();
                _oddsItf.GetEventList(DateTime.Today, DateTime.Today.AddDays(1), true);
            }
        }

        /// <summary>
        /// Stops the LiveOdds provider and SDK. Also unsubscribes from all LiveOdds events
        /// </summary>
        public void StopTracking()
        {
            _Logger.Info("StopTracking");

            if (_oddsItf != null)
            {
                _oddsItf.Stop();

                _oddsItf.OnAlive -= OnLiveOddsOnAliveReceived;
                _oddsItf.OnFeedError -= LiveOddsOnFeedErrorOccured;
                _oddsItf.OnBetCancel -= LiveOddsOnMatchBetCancelled;
                _oddsItf.OnBetCancelUndo -= LiveOddsOnMatchBetCancelUndo;
                _oddsItf.OnBetClear -= LiveOddsOnMatchBetCleared;
                _oddsItf.OnBetClearRollback -= LiveOddsOnMatchBetClearRollbacked;
                _oddsItf.OnBetStart -= LiveOddsOnBetStarted;
                _oddsItf.OnBetStop -= LiveOddsOnBetStopped;
                _oddsItf.OnMetaInfo -= LiveOddsOnMetaInfoReceived;
                _oddsItf.OnOddsChange -= LiveOddsOnOddsChanged;
                _oddsItf.OnScoreCardSummary -= LiveOddsOnScoreCardSummaryReceived;
            }

            Sdk.Instance.OnQueueLimits -= OnQueueLimits;

            Sdk.Instance.Stop();
        }

        /// <summary>
        /// Register specific bet types within the given match.
        /// Can register all odds for a Match, an entire odds type or just one Oddsfield of an odds type
        /// </summary>
        /// <param name="matchBetTypes">>List of matches and bet types to register</param>
        public void RegisterBetTypes(RegisterUnregisterBetType[] matchBetTypes)
        {
            _Logger.InfoFormat("RegisterBetTypes: count: {0}", (matchBetTypes == null) ? 0 : matchBetTypes.Length);

            _oddsItf.RegisterBetTypes(matchBetTypes);
        }


        /// <summary>
        /// Unregister specific bet types within the given match.
        /// Can unregister all odds for a Match, an entire odds type or just one Oddsfield of an odds type
        /// </summary>
        /// <param name="matchBetTypes">>List of matches and bet types to unregister</param>
        public void UnregisterBetTypes(RegisterUnregisterBetType[] matchBetTypes)
        {
            _Logger.InfoFormat("UnregisterBetTypes: count: {0}", (matchBetTypes == null) ? 0 : matchBetTypes.Length);

            _oddsItf.UnregisterBetTypes(matchBetTypes);
        }

        /// <summary>
        /// Requests the current match status. This includes odds, activation of odds and match status for the match requested,
        /// current bet status and all bet clearing messages before the timestamp.
        /// </summary>
        /// <param name="matchId">Match id</param>
        /// <param name="from">Match status on particular time (leave null for current match status)</param>
        public void GetCurrentMatchStatus(long matchId, DateTime? from)
        {
            _Logger.InfoFormat("GetCurrentMatchStatus: matchId: {0} startDate: {1}", matchId, from);

            _oddsItf.GetEventStatus(matchId, from, false);
        }

        /// <summary>
        /// Requests a list of all cards and scores for a match.
        /// </summary>
        /// <param name="matchId">Match id</param>
        public void GetScoreAndCardSummary(long matchId)
        {
            _Logger.InfoFormat("GetScoreAndCardSummary: matchId {0}", matchId);

            _oddsItf.GetScoreAndCardSummary(matchId);
        }

        /// <summary>
        /// Request meta-information about all matches in a given interval. The maximum interval is 10 days.
        /// If no matches are specified, all matches started 24 hours in the past, and 7 days in the future are returned. 
        /// The response message includes teams playing, match date and time, TV channel names and sport/category/tournament for every match.
        /// </summary>
        /// <param name="startDate">Start of time interval</param>
        /// <param name="endDate">End of time interval</param>
        /// <param name="matchIds">Return meta info only for the matches specified.</param>
        /// <param name="includeAvailable">if set to <c>true</c> include matches that are available for booking but not booked yet.</param>
        public void GetMatchList(DateTime? startDate, DateTime? endDate, long[] matchIds, bool includeAvailable)
        {
            _Logger.InfoFormat("GetMatchList: startDate: {0} endDate: {1} includeAvailable {2}", startDate, endDate, includeAvailable);

            if (startDate != null || endDate != null)
            {
                _oddsItf.GetEventList(startDate, endDate, includeAvailable);
            }
            else
            {
                _oddsItf.GetEventList(matchIds);    
            }
        }

        /// <summary>
        /// Subscribe to specified match.
        /// </summary>
        /// <param name="matchId">Match id</param>
        /// <remarks>
        /// SDK enables subscription to multiple matches at once
        /// but for the needs of GUI we only need one at once
        /// </remarks>
        public void SubscribeToMatch(long matchId)
        {
            _Logger.InfoFormat("SubscribeToMatch: matchId: {0}", matchId);

            _oddsItf.Subscribe(new[] { matchId });
        }

        /// <summary>
        /// Unsubscribes from the specified match. After this no more events associated with these match will be sent..
        /// </summary>
        /// <param name="matchId">Match id</param>
        public void UnsubscribeFromMatch(long matchId)
        {
            _Logger.InfoFormat("UnsubscribeFromMatch: matchId: {0}", matchId);

            _oddsItf.Unsubscribe(new[] { matchId });
            ReferencesMerger.Instance.UnsubscribeMatch(matchId);
        }

        /// <summary>
        /// Book the specified match.
        /// </summary>
        /// <param name="matchId">Match id</param>
        /// <remarks>
        /// SDK enables booking to multiple matches at once
        /// but for the needs of GUI we only need one at once
        /// </remarks>
        /// <para>
        /// Note that booking matches will have a cost depending on the type of agreement you have with Sportradar.
        /// </para>
        public void BookMatch(long matchId)
        {
            _Logger.InfoFormat("BookMatch: matchId: {0}", matchId);
            _oddsItf.BookEvents(new[] { matchId });
        }


        /// <summary>
        /// Clears persistent store
        /// </summary> 
        public void ClearState()
        {
            _Logger.InfoFormat("ClearState");
            _oddsItf.ClearState();
        }

        #endregion

        #region --- Event handlers ---

        private void OnQueueLimits(object sender, QueueLimitEventArgs eventArgs)
        {
            _Logger.InfoFormat(
                "OnQueueLimits: queue_name {0}",
                eventArgs.QueueName);

            // release SDK thread ASAP
            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeGlobalNotifications(
                    NotificationType.QueueLimitReached,
                    NotificationSeverity.Error,
                    string.Format("OnQueueLimits: queue_name {0}", eventArgs.QueueName),
                    eventArgs))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);
        }

        private void OnLiveOddsOnAliveReceived(object sender, AliveEventArgs eventArgs)
        {
            var eventHeaders = eventArgs.Alive.EventHeaders;
            _Logger.InfoFormat(
                "OnLiveOddsOnAliveReceived: count: {0}",
                (eventHeaders == null) ? 0 : eventHeaders.Count);

            // release SDK thread ASAP
            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeGlobalNotifications(
                NotificationType.Alive,
                NotificationSeverity.Info,
                string.Format("Alive message received: Match count: {0}", (eventHeaders == null) ? 0 : eventHeaders.Count),
                eventArgs))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);

            if (eventHeaders != null)
            {
                foreach (var matchheader in eventHeaders)
                {
                    ReferencesMerger.Instance.SubscribeMatch(matchheader.Id);
                }
            }
        }

        private void LiveOddsOnScoreCardSummaryReceived(object sender, ScoreCardSummaryEventArgs eventArgs)
        {
            _Logger.Info("LiveOddsOnScoreCardSummaryReceived");

            // release SDK thread ASAP
            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeGlobalNotifications(
                    NotificationType.ScoreCardSummary,
                    NotificationSeverity.Info,
                    "Score and card summary received",
                    eventArgs))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);

            Task.Factory.StartNew(() =>
                                      {
                                          ReferencesMerger.Instance.MergeScoreCardSummary(eventArgs.ScoreCardSummary);
                                          if (ScoreCardEvent != null)
                                          {
                                              ScoreCardEvent(eventArgs.ScoreCardSummary.EventHeader.Id);
                                          }
                                      })
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);
        }

        private void LiveOddsOnOddsChanged(object sender, OddsChangeEventArgs eventArgs)
        {
            var eventHeader = (MatchHeader)eventArgs.OddsChange.EventHeader;
            _Logger.InfoFormat(
                "LiveOddsOnOddsChanged: match_id: {0}",
                eventHeader.Id);

            // release SDK thread ASAP
            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergePerMatchNotifications(
                    NotificationType.OddsChange,
                    NotificationSeverity.Info,
                    eventArgs,
                    string.Format("Odds change received"),
                    eventHeader.Id))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);

            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeMatchOdds(eventHeader.Id, eventHeader, eventArgs.OddsChange.Odds))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);
        }

        private void LiveOddsOnMetaInfoReceived(object sender, MetaInfoEventArgs eventArgs)
        {
            LiveOddsMetaData liveOddsMetaInfo = (LiveOddsMetaData)eventArgs.MetaInfo.MetaInfoDataContainer;
            var matchHeaderInfos = liveOddsMetaInfo.MatchHeaderInfos;
            _Logger.InfoFormat(
                "LiveOddsOnMetaInfoReceived: count: {0}",
                (matchHeaderInfos == null) ? 0 : matchHeaderInfos.Count);

            // release SDK thread ASAP
            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeGlobalNotifications(
                    NotificationType.MetaInfo,
                    NotificationSeverity.Info,
                    string.Format("Meta info: Match count: {0}", (matchHeaderInfos == null) ? 0 : matchHeaderInfos.Count),
                    eventArgs))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);

            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeMatchInfos(matchHeaderInfos))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);
        }

        private void LiveOddsOnBetStopped(object sender, BetStopEventArgs eventArgs)
        {
            var betStop = eventArgs.BetStop;
            _Logger.InfoFormat(
                "LiveOddsOnBetStopped: match_id: {0}",
                betStop.EventHeader.Id);

            // release SDK thread ASAP
            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergePerMatchNotifications(
                    NotificationType.BetStop,
                    NotificationSeverity.Info,
                    eventArgs,
                    string.Format("Bet stop received"),
                    betStop.EventHeader.Id))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);

            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeMatch(betStop.EventHeader.Id, (MatchHeader)betStop.EventHeader))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);
        }

        private void LiveOddsOnBetStarted(object sender, BetStartEventArgs eventArgs)
        {
            var betStart = eventArgs.BetStart;
            _Logger.InfoFormat(
                "LiveOddsOnBetStarted: match_id: {0}",
                betStart.EventHeader.Id);

            // release SDK thread ASAP
            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergePerMatchNotifications(
                    NotificationType.BetStart,
                    NotificationSeverity.Info,
                    eventArgs,
                    string.Format("Bet start received"),
                    betStart.EventHeader.Id))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);

            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeMatch(betStart.EventHeader.Id, (MatchHeader)betStart.EventHeader))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);
        }

        private void LiveOddsOnMatchBetClearRollbacked(object sender, BetClearRollbackEventArgs eventArgs)
        {
            var betClearRollback = eventArgs.BetClearRollback;
            _Logger.InfoFormat(
                "LiveOddsOnMatchBetClearRollbacked: match_id: {0}",
                betClearRollback.EventHeader.Id);

            // release SDK thread ASAP
            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergePerMatchNotifications(
                    NotificationType.BetClearRollback,
                    NotificationSeverity.Info,
                    eventArgs,
                    string.Format("Bet clear rollback received"),
                    betClearRollback.EventHeader.Id))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);

            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeMatchOdds(betClearRollback.EventHeader.Id, (MatchHeader) betClearRollback.EventHeader, betClearRollback.Odds))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);
        }

        private void LiveOddsOnMatchBetCleared(object sender, BetClearEventArgs eventArgs)
        {
            var betClear = eventArgs.BetClear;
            _Logger.InfoFormat(
                "LiveOddsOnMatchBetCleared: match_id: {0}",
                betClear.EventHeader.Id);

            // release SDK thread ASAP
            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergePerMatchNotifications(
                    NotificationType.BetClear,
                    NotificationSeverity.Info,
                    eventArgs,
                    string.Format("Bet clear received"),
                    betClear.EventHeader.Id))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);

            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeMatchOdds(betClear.EventHeader.Id, (MatchHeader) betClear.EventHeader, betClear.Odds))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);
        }

        private void LiveOddsOnMatchBetCancelUndo(object sender, BetCancelUndoEventArgs eventArgs)
        {
            var betCancelUndone = eventArgs.BetCancelUndo;
            _Logger.InfoFormat(
                "LiveOddsOnMatchBetCancelUndo: match_id: {0}",
                betCancelUndone.EventHeader.Id);

            // release SDK thread ASAP
            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergePerMatchNotifications(
                    NotificationType.BetCancelUndo,
                    NotificationSeverity.Info,
                    eventArgs,
                    string.Format("Bet cancel undone received"),
                    betCancelUndone.EventHeader.Id))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);

            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeMatchOdds(betCancelUndone.EventHeader.Id, (MatchHeader) betCancelUndone.EventHeader, betCancelUndone.Odds))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);
        }

        private void LiveOddsOnMatchBetCancelled(object sender, BetCancelEventArgs eventArgs)
        {
            _Logger.InfoFormat(
                "LiveOddsOnMatchBetCancelled: match_id: {0}",
                eventArgs.BetCancel.EventHeader.Id);

            // release SDK thread ASAP
            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergePerMatchNotifications(
                    NotificationType.BetCancel,
                    NotificationSeverity.Info,
                    eventArgs,
                    string.Format("Bet cancel received"),
                    eventArgs.BetCancel.EventHeader.Id))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);

            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeMatchOdds(eventArgs.BetCancel.EventHeader.Id, (MatchHeader) eventArgs.BetCancel.EventHeader, eventArgs.BetCancel.Odds))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);
        }

        private void LiveOddsOnFeedErrorOccured(object sender, FeedErrorEventArgs eventArgs)
        {
            _Logger.InfoFormat(
                "LiveOddsOnFeedErrorOccured: ErrorCause: {0}, ErrorSeverity: {1}, msg: {2}",
                eventArgs.Cause, eventArgs.Severity, eventArgs.ErrorMessage);

            // release SDK thread ASAP
            Task.Factory.StartNew(() => ReferencesMerger.Instance.MergeLiveOddsOnFeedErrorOccured(NotificationType.Error, NotificationSeverity.Error, eventArgs))
                .ContinueWith((task) => ReferencesMerger.Instance.ShowError(task.Exception.InnerException), TaskContinuationOptions.OnlyOnFaulted);
        }

        #endregion

    }
}
