﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.Common;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Models
{
    public class ScoreEntryModel : Base.CardEntryModel, IComparable<ScoreEntryModel>, IEquatable<ScoreEntryModel>
    {
        public ScoreEntryModel(ScoreEntry scoreEntry)
        {
            this.Load(scoreEntry);
        }

        public void Load(ScoreEntry scoreEntry)
        {
            if (scoreEntry == null)
            {
                throw new ArgumentNullException("scoreEntry");
            }

            this.Load(scoreEntry as BaseScoreCardEntry);

            this.Type = scoreEntry.Type;
            this.HomeScore = scoreEntry.Score.Team1;
            this.AwayScore = scoreEntry.Score.Team2;
        }

        private OddsScoreType _Type = 0;

        public OddsScoreType Type
        {
            get { return this.GetProperty(ref this._Type); }
            private set { this.SetProperty(ref this._Type, value, "Type"); }
        }

        private double _AwayScore;

        public double AwayScore
        {
            get { return this.GetProperty(ref this._AwayScore); }
            private set { this.SetProperty(ref this._AwayScore, value, "AwayScore"); }
        }

        private double _HomeScore;

        public double HomeScore
        {
            get { return this.GetProperty(ref this._HomeScore); }
            private set { this.SetProperty(ref this._HomeScore, value, "HomeScore"); }
        }

        public bool Equals(ScoreEntryModel other)
        {
            return (this.CompareTo(other) == 0);
        }

        public int CompareTo(ScoreEntryModel other)
        {
            if (other == null)
            {
                return -1;
            }
            else
            {
                int result = this.Time.CompareTo(other.Time);
                if (result != 0)
                {
                    return result;
                }
                if (this.Id.HasValue && other.Id.HasValue)
                {
                    return this.Id.Value.CompareTo(other.Id.Value);
                }
                else if (this.Id.HasValue)
                {
                    return -1;
                }
                else if (other.Id.HasValue)
                {
                    return 1;
                }
                result = this.Type.CompareTo(other.Type);
                if (result != 0)
                {
                    return result;
                }
                result = this.AffectedTeam.CompareTo(other.AffectedTeam);
                if (result != 0)
                {
                    return result;
                }
                result = this.AffectedPlayer.CompareExt(other.AffectedPlayer);
                if (result != 0)
                {
                    return result;
                }
                return this.Cancelled.CompareTo(other.Cancelled);
            }
        }
    }
}
