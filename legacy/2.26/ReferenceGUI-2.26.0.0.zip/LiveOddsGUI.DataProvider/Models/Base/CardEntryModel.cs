﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.FeedProviders.Common;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.Common;
using System;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Models.Base
{
    public abstract class CardEntryModel : NotifyPropertyChanged
    {
        protected void Load(BaseScoreCardEntry baseScoreCardEntry)
        {
            if (baseScoreCardEntry == null)
            {
                throw new ArgumentNullException("baseScoreCardEntry");
            }

            this.AffectedPlayer = (baseScoreCardEntry.AffectedPlayer == null) ? this.AffectedPlayer : baseScoreCardEntry.AffectedPlayer;
            this.AffectedTeam = (baseScoreCardEntry.AffectedTeam == Team.UNDEFINED) ? this.AffectedTeam : baseScoreCardEntry.AffectedTeam;
            this.Cancelled = baseScoreCardEntry.Cancelled;
            this.Id = (baseScoreCardEntry.Id == null) ? this.Id : baseScoreCardEntry.Id;
            this.Time = baseScoreCardEntry.Time;
        }

        private string _AffectedPlayer = null;
        private Team _AffectedTeam = Team.UNDEFINED;
        private bool _Cancelled = false;
        private long? _Id = null;
        private long _Time = 0;

        public string AffectedPlayer
        {
            get { return this.GetProperty(ref this._AffectedPlayer); }
            private set { this.SetProperty(ref this._AffectedPlayer, value, "AffectedPlayer"); }
        }
        public Team AffectedTeam
        {
            get { return this.GetProperty(ref this._AffectedTeam); }
            private set { this.SetProperty(ref this._AffectedTeam, value, "AffectedTeam"); }
        }
        public bool Cancelled
        {
            get { return this.GetProperty(ref this._Cancelled); }
            private set { this.SetProperty(ref this._Cancelled, value, "Cancelled"); }
        }
        public long? Id
        {
            get { return this.GetProperty(ref this._Id); }
            private set { this.SetProperty(ref this._Id, value, "Id"); }
        }
        public long Time
        {
            get { return this.GetProperty(ref this._Time); }
            private set { this.SetProperty(ref this._Time, value, "Time"); }
        }
    }
}
