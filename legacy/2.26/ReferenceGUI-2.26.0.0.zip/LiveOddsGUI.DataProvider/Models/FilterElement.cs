﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Models
{
    public class FilterElement : NotifyPropertyChanged
    {
        public FilterElement(LocalizedString name, bool ischecked)
        {
            this.IsChecked = true;
            this.Name = name;
        }

        private LocalizedString _Name = null;
        private bool _IsChecked = false;

        public LocalizedString Name
        {
            get { return this.GetProperty(ref this._Name); }
            private set { this.SetProperty(ref this._Name, value, "Name"); }
        }
        public bool IsChecked
        {
            get { return this.GetProperty(ref this._IsChecked); }
            set { this.SetProperty(ref this._IsChecked, value, "IsChecked"); }
        }
    }
}