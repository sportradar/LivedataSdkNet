﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.Common;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using System.Collections.Generic;

namespace Sportradar.Demo.GUI.LiveOdds.Models
{
    public class BetValueModel : NotifyPropertyChanged
    {
        private LocalizedString _Name;
        private ImprovedObservableCollection<EventOddsField> _Outcomes;

        public BetValueModel(LocalizedString name, IDictionary<string, EventOddsField> dict)
        {
            _Outcomes = new ImprovedObservableCollection<EventOddsField>();
            _Name = name;
            foreach (var outcome in dict)
            {
                _Outcomes.Add(outcome.Value);
            }
        }


        public LocalizedString Name
        {
            get { return this.GetProperty(ref this._Name); }
            private set { this.SetProperty(ref this._Name, value, "Name"); }
        }

        public ImprovedObservableCollection<EventOddsField> Outcomes
        {
            get { return _Outcomes; }
        }

    }
}
