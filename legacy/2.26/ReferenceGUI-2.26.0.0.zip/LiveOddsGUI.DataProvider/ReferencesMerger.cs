﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using log4net;
using Merged::Sportradar.SDK.FeedProviders.Common;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Common;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Enums;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Timers;
using System.Windows;
using System.Windows.Threading;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider
{
    /// <summary>
    /// Takes care of merging data from events and wraps SDK calls for ChangeTracker
    /// </summary>
    public class ReferencesMerger
    {
        private readonly static Lazy<ReferencesMerger> _Instance = new Lazy<ReferencesMerger>(() => new ReferencesMerger(), true);

        private ReferencesMerger()
        {
        }

        private readonly ILog _Logger = LogManager.GetLogger(typeof(ReferencesMerger));

        private readonly Dispatcher _Dispatcher = Application.Current.Dispatcher;


        /// <summary>
        /// Instance of <see cref="ReferencesMerger"/> class
        /// </summary>
        public static ReferencesMerger Instance { get { return _Instance.Value; } }

        /// <summary>
        /// Triggered when filters update
        /// </summary>
        public event FiltersChanged FiltersChanged;

        #region --- Public methods ---


        /// <summary>
        /// Shows exception details in new message box
        /// </summary>
        /// <param name="exc">Exception</param>
        public void ShowError(Exception exc)
        {
            MessageBox.Show(
                string.Format(
                    "{0}{1}{1}{2}{1}{1}{3}",
                    GuiStrings.Instance.UnexpectedError,
                    Environment.NewLine,
                    exc.Message,
                    exc.StackTrace),
                GuiStrings.Instance.Error,
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }


        /// <summary>
        /// Clear all info about all matches that user didn't subscribe to
        /// </summary>
        public void ClearLoadedMatches()
        {
            _Logger.Info("ClearLoadedMatches");

            this.ClearLoadedMatchesDispatcherThread();
        }


        /// <summary>
        /// Subscribes to a match
        /// </summary>
        public void SubscribeMatch(long matchId)
        {
            _Logger.InfoFormat(
                "SubscribeMatch: {0}",
                matchId);

            this.SubscribeMatchDispatcherThread(matchId);
        }

        /// <summary>
        /// Unsubscribes from a match
        /// </summary>
        public void UnsubscribeMatch(long matchId)
        {
            _Logger.InfoFormat(
                "UnsubscribeMatch: {0}",
                matchId);

            this.UnsubscribeMatchDispatcherThread(matchId);
        }


        /// <summary>
        /// Inserts error notification details to collection containing global notifications
        /// </summary>
        public void MergeLiveOddsOnFeedErrorOccured(NotificationType notificationType, NotificationSeverity notificationSeverity, FeedErrorEventArgs eventArgs)
        {
            _Logger.InfoFormat(
                "MergeLiveOddsOnFeedErrorOccured: ErrorCause: {0}, ErrorSeverity: {1}, msg: {2}",
                eventArgs.Cause, eventArgs.Severity, eventArgs.ErrorMessage);

            this.MergeLiveOddsOnFeedErrorOccuredDispatcherThread(notificationType, notificationSeverity, eventArgs);
        }


        /// <summary>
        /// Updates odds and match header for specific match
        /// Creates all collection/dictionary entries if they
        /// don't already exist for specified match 
        /// </summary>
        public void MergeMatchOdds(long matchId, MatchHeader matchHeader, List<EventOdds> matchOdds)
        {
            _Logger.Info("MergeMatchOdds");

            this.MergeMatchOddsDispatcherThread(matchId, matchHeader, matchOdds);
        }

        /// <summary>
        /// Updates match header for specific match
        /// Creates all collection/dictionary entries if they
        /// don't already exist for specified match 
        /// </summary>
        public void MergeMatch(long matchId, MatchHeader matchHeader)
        {
            _Logger.Info("MergeMatch");

            this.MergeMatchDispatcherThread(matchId, matchHeader);
        }

        /// <summary>
        /// Updates match infos for all matches in the event
        /// Creates all collection/dictionary entries if they
        /// don't already exist for all the  specified matches 
        /// </summary>
        public void MergeMatchInfos(IList<MatchHeaderInfo> matchHeaderInfos)
        {
            _Logger.Info("MergeMatchInfos");

            this.MergeMatchInfosDispatcherThread(matchHeaderInfos);
        }

        /// <summary>
        /// Updates score card summary for specific match
        /// Creates all collection/dictionary entries if they
        /// don't already exist for all the  specified matches 
        /// </summary>
        public void MergeScoreCardSummary(ScoreCardSummary scoreCardSummary)
        {
            _Logger.Info("MergeScoreCardSummary");

            this.MergeScoreCardSummaryDispatcherThread(scoreCardSummary);
        }


        /// <summary>
        /// Inserts notifications details to collection containing global notifications
        /// </summary>
        public void MergeGlobalNotifications(
            NotificationType notificationType,
            NotificationSeverity notificationSeverity,
            string notificationMessage,
            EventArgs eventArgs)
        {
            _Logger.InfoFormat(
                "MergeGlobalNotifications: NotificationType: {0} , NotificationSeverity: {1}, msg: {2}",
               notificationType, notificationSeverity, notificationMessage);

            this.MergeGlobalNotificationsDispatcherThread(notificationType, notificationSeverity, eventArgs, notificationMessage);
        }



        /// <summary>
        /// Inserts notifications details to collection containing per match notifications 
        /// </summary>
        public void MergePerMatchNotifications(
            NotificationType notificationType,
            NotificationSeverity notificationSeverity,
            EventArgs eventArgs,
            string notificationMessage,
            long matchid)
        {
            _Logger.InfoFormat(
                "MergePerMatchNotifications: NotificationSeverity: {0}, msg: {1}",
                notificationSeverity, notificationMessage);

            this.MergePerMatchNotificationsDispatcherThread(notificationType, notificationSeverity, eventArgs, notificationMessage, matchid);
        }


        /// <summary>
        /// Updates queue statistics
        /// </summary>
        public void MergeDispatcherQueueStats(IList<Merged::Sportradar.SDK.Services.QueueStats.ClientQueueStats> stats)
        {
            _Logger.Info("MergeDispatcherQueueStats");

            this.MergeDispatcherQueueStatsDispatcherThread(stats);
        }

        /// <summary>
        /// Updates server time with new value
        /// </summary>
        /// <param name="serverTime">New time</param>
        public void MergeServerTime(DateTime? serverTime)
        {
            this.MergeServerTimeDispatcherThread(serverTime);
        }

        /// <summary>
        /// Clears all <see cref="References"/> objects
        /// </summary>
        public void ClearAll()
        {
            References.Instance.LoadedMatchIds.Clear();
            References.Instance.MatchHeaders.Clear();
            References.Instance.MatchInfos.Clear();
            References.Instance.MatchOdds.Clear();
            References.Instance.MatchScoreCardSummaries.Clear();
            References.Instance.PerMatchNotifications.Clear();
            References.Instance.MatchFiltersCombinations.Clear();
            References.Instance.AllTournamentFilters.Clear();
            References.Instance.AllCategoryFilters.Clear();
            References.Instance.AllSportFilters.Clear();

        }

        #endregion


        #region --- Private methods ---




        private void MergeLiveOddsOnFeedErrorOccuredDispatcherThread(NotificationType notificationType, NotificationSeverity notificationSeverity, FeedErrorEventArgs eventArgs)
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                _Logger.DebugFormat(
                    "MergeLiveOddsOnFeedErrorOccuredDispatcherThread: enqueue: ErrorCause: {0}, ErrorSeverity: {1}, msg: {2}",
                    eventArgs.Cause, eventArgs.Severity, eventArgs.ErrorMessage);

                this.InvokeInDispatcherThread(() => this.MergeLiveOddsOnFeedErrorOccuredDispatcherThread(notificationType, notificationSeverity, eventArgs));
                return;
            }

            _Logger.DebugFormat(
                    "MergeLiveOddsOnFeedErrorOccuredDispatcherThread: process: ErrorCause: {0}, ErrorSeverity: {1}, msg: {2}",
                    eventArgs.Cause, eventArgs.Severity, eventArgs.ErrorMessage);

            References.Instance.GlobalNotifications.InsertInOrder(new NotificationDisplayModel(notificationType, notificationSeverity, eventArgs, eventArgs.ErrorMessage));
        }

        private void ClearLoadedMatchesDispatcherThread()
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                _Logger.Debug("ClearLoadedMatchesDispatcherThread: enqueue");

                this.InvokeInDispatcherThread(() => this.ClearLoadedMatchesDispatcherThread());
                return;
            }

            _Logger.Debug("ClearLoadedMatchesDispatcherThread: process");
            References.Instance.LoadedMatchIds.Clear();
        }

        private void SubscribeMatchDispatcherThread(long matchId)
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                _Logger.DebugFormat(
                    "SubscribeMatchDispatcherThread: enqueue: {0}",
                    matchId);

                this.InvokeInDispatcherThread(() => this.SubscribeMatchDispatcherThread(matchId));
                return;
            }

            _Logger.DebugFormat(
                    "SubscribeMatchDispatcherThread: process: {0}",
                    matchId);

            this.AddMatch(matchId);
        }

        private void UnsubscribeMatchDispatcherThread(long matchId)
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                _Logger.DebugFormat(
                    "UnsubscribeMatchDispatcherThread: enqueue: {0}",
                    matchId);

                this.InvokeInDispatcherThread(() => this.UnsubscribeMatchDispatcherThread(matchId));
                return;
            }

            _Logger.DebugFormat(
                    "UnsubscribeMatchDispatcherThread: process: {0}",
                    matchId);

        }

        private void MergeMatchOddsDispatcherThread(long matchId, MatchHeader matchHeader, List<EventOdds> matchOdds)
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                _Logger.Debug("MergeMatchOddsDispatcherThread: enqueue");

                this.InvokeInDispatcherThread(() => this.MergeMatchOddsDispatcherThread(matchId, matchHeader, matchOdds));
                return;
            }

            _Logger.Debug("MergeMatchOddsDispatcherThread: process");

            if (matchHeader != null)
            {
                if (matchId != matchHeader.Id)
                {
                    throw new ArgumentException("MatchId and MatchHeader. MatchId do not match.");
                }

                this.AddMatch(matchId);

                var foundMatchHeader = References.Instance.MatchHeaders.FirstOrDefault(kv => kv.Key == matchId);
                if (foundMatchHeader.Value != null)
                {
                    foundMatchHeader.Value.Load(matchHeader);
                }
            }

            if (matchOdds != null)
            {
                this.AddMatch(matchId);

                var foundOddsCollection = References.Instance.MatchOdds.FirstOrDefault(kv => kv.Key == matchId);
                if (foundOddsCollection.Value != null)
                {
                    foreach (var matchOdd in matchOdds)
                    {
                        if (matchOdd == null)
                        {
                            continue;
                        }

                        var foundOdds = foundOddsCollection.Value.FirstOrDefault(mom => mom.Id == matchOdd.Id);
                        if (foundOdds == null)
                        {
                            foundOddsCollection.Value.InsertInOrder(new MatchOddsModel(matchOdd));
                        }
                        else
                        {
                            foundOdds.Load(matchOdd);
                        }
                    }
                }
            }
        }

        private void MergeMatchDispatcherThread(long matchId, MatchHeader matchHeader)
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                _Logger.Debug("MergeMatchDispatcherThread: enqueue");

                this.InvokeInDispatcherThread(() => this.MergeMatchDispatcherThread(matchId, matchHeader));
                return;
            }

            _Logger.Debug("MergeMatchDispatcherThread: process");

            if (matchHeader != null)
            {
                if (matchId != matchHeader.Id)
                {
                    throw new ArgumentException("MatchId and MatchHeader.MatchId do not match.");
                }

                this.AddMatch(matchId);

                var foundMatchHeader = References.Instance.MatchHeaders.FirstOrDefault(kv => kv.Key == matchId);
                if (foundMatchHeader.Value != null)
                {
                    foundMatchHeader.Value.Load(matchHeader);
                }
            }
        }

        private void MergeMatchInfosDispatcherThread(IList<MatchHeaderInfo> matchHeaderInfos)
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                _Logger.Debug("MergeMatchInfosDispatcherThread: enqueue");

                this.InvokeInDispatcherThread(() => this.MergeMatchInfosDispatcherThread(matchHeaderInfos));
                return;
            }

            _Logger.Debug("MergeMatchInfosDispatcherThread: process");

            foreach (var matchHeaderInfo in matchHeaderInfos)
            {
                if (matchHeaderInfo == null || matchHeaderInfo.MatchHeader == null)
                {
                    continue;
                }

                this.AddMatch(matchHeaderInfo.MatchHeader.Id);

                var foundMatchHeader = References.Instance.MatchHeaders.FirstOrDefault(kv => kv.Key == matchHeaderInfo.MatchHeader.Id);
                if (foundMatchHeader.Value != null)
                {
                    foundMatchHeader.Value.Load(matchHeaderInfo.MatchHeader);
                }

                if (matchHeaderInfo.MatchInfo != null)
                {
                    var foundMatchInfo = References.Instance.MatchInfos.FirstOrDefault(kv => kv.Key == matchHeaderInfo.MatchHeader.Id);
                    if (foundMatchInfo.Value != null)
                    {
                        foundMatchInfo.Value.Load(matchHeaderInfo.MatchInfo);

                        if ((foundMatchInfo.Value.SportId != 0)
                            && (foundMatchInfo.Value.SportName != null))
                        {
                            var name = foundMatchInfo.Value.SportName;
                            if (name != null)
                            {
                                if (References.Instance.AllSportFilters.SingleOrDefault(mf => mf.Name == name) == null)
                                {
                                    References.Instance.AllSportFilters.Add(new FilterElement(name, true));
                                }
                            }
                        }
                        if ((foundMatchInfo.Value.CategoryId != 0)
                            && (foundMatchInfo.Value.CategoryName != null))
                        {
                            var name = foundMatchInfo.Value.CategoryName;
                            if (name != null)
                            {
                                if (References.Instance.AllCategoryFilters.SingleOrDefault(mf => mf.Name == name) == null)
                                {
                                    References.Instance.AllCategoryFilters.Add(new FilterElement(name, true));
                                }
                            }
                        }
                        if ((foundMatchInfo.Value.TournamentId != 0)
                            && (foundMatchInfo.Value.TournamentName != null))
                        {
                            var name = foundMatchInfo.Value.TournamentName;
                            if (name != null)
                            {
                                if (References.Instance.AllTournamentFilters.SingleOrDefault(mf => mf.Name == name) == null)
                                {
                                    References.Instance.AllTournamentFilters.Add(new FilterElement(name, true));
                                }
                            }
                        }
                        if (foundMatchInfo.Value.SportName != null &&
                            foundMatchInfo.Value.CategoryName != null &&
                            foundMatchInfo.Value.TournamentName != null)
                        {

                            var SportName = foundMatchInfo.Value.SportName;
                            var CategoryName = foundMatchInfo.Value.CategoryName;
                            var TournamentName = foundMatchInfo.Value.TournamentName;
                            var combo = new FilterNameCombo(SportName, CategoryName, TournamentName);

                            if (References.Instance.MatchFiltersCombinations.Any(x => x.Sport == combo.Sport && x.Category == combo.Category && x.Tournament == combo.Tournament) == false)
                            {
                                References.Instance.MatchFiltersCombinations.Add(combo);
                            }
                        }
                    }
                }
            }
        }

        private void MergeScoreCardSummaryDispatcherThread(ScoreCardSummary scoreCardSummary)
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                _Logger.Debug("MergeScoreCardSummaryDispatcherThread: enqueue");

                this.InvokeInDispatcherThread(() => this.MergeScoreCardSummaryDispatcherThread(scoreCardSummary));
                return;
            }

            _Logger.Debug("MergeScoreCardSummaryDispatcherThread: process");

            var foundScoreCardSummary = References.Instance.MatchScoreCardSummaries.FirstOrDefault(kv => kv.Key == scoreCardSummary.EventHeader.Id);
            if (foundScoreCardSummary.Value != null)
            {
                foundScoreCardSummary.Value.Load(scoreCardSummary);
            }
        }


        private void MergeGlobalNotificationsDispatcherThread(NotificationType notificationType, NotificationSeverity notificationSeverity, EventArgs eventArgs, string notificationMessage)
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                _Logger.DebugFormat(
                    "MergeGlobalNotificationsDispatcherThread: enqueue: NotificationType : {0} , NotificationSeverity: {1}, msg: {2}",
                    notificationType, notificationSeverity, notificationMessage);

                this.InvokeInDispatcherThread(() => this.MergeGlobalNotificationsDispatcherThread(notificationType, notificationSeverity, eventArgs, notificationMessage));
                return;
            }

            _Logger.DebugFormat(
                    "MergeGlobalNotificationsDispatcherThread: enqueue: NotificationType : {0} , NotificationSeverity: {1}, msg: {2}",
                    notificationType, notificationSeverity, notificationMessage);

            References.Instance.GlobalNotifications.InsertInOrder(new NotificationDisplayModel(notificationType, notificationSeverity, eventArgs, notificationMessage));
        }


        private void MergePerMatchNotificationsDispatcherThread(NotificationType notificationType, NotificationSeverity notificationSeverity, EventArgs eventArgs, string notificationMessage, long matchid)
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                _Logger.DebugFormat(
                    "MergePerMatchNotificationsDispatcherThread: enqueue: NotificationType: {0}, NotificationSeverity: {1}, eventArgs : {2}, msg: {3}",
                    notificationSeverity, notificationMessage, eventArgs, notificationMessage);

                this.InvokeInDispatcherThread(() => this.MergePerMatchNotificationsDispatcherThread(notificationType, notificationSeverity, eventArgs, notificationMessage, matchid));
                return;
            }

            SubscribeMatch(matchid);

            _Logger.DebugFormat(
                    "MergePerMatchNotificationsDispatcherThread: process: NotificationType: {0}, NotificationSeverity: {1}, eventArgs : {2}, msg: {3}",
                    notificationSeverity, notificationMessage, eventArgs, notificationMessage);

            ImprovedObservableCollection<NotificationDisplayModel> notifications;
            var new_notification = new NotificationDisplayModel(notificationType, notificationSeverity, eventArgs, notificationMessage, matchid);
            if (References.Instance.PerMatchNotifications.TryGetValue(matchid, out notifications))
            {
                notifications.InsertInOrder(new_notification);
            }
        }



        private void MergeDispatcherQueueStatsDispatcherThread(IList<Merged::Sportradar.SDK.Services.QueueStats.ClientQueueStats> stats)
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                _Logger.Debug("MergeDispatcherQueueStatsDispatcherThread: enqueue");

                this.InvokeInDispatcherThread(() => this.MergeDispatcherQueueStatsDispatcherThread(stats));
                return;
            }

            _Logger.Debug("MergeDispatcherQueueStatsDispatcherThread: process");

            References.Instance.DispatcherQueueStatsModel.Load(stats);
        }

        private void MergeServerTimeDispatcherThread(DateTime? serverTime)
        {
            if (!this.CheckDispatcherThreadAccess())
            {
                this.InvokeInDispatcherThread(() => this.MergeServerTimeDispatcherThread(serverTime));
                return;
            }

            References.Instance.ServerTimeModel.ServerTime = serverTime;
            References.Instance.ServerTimeModel.LocalTime = DateTime.Now;
        }


        /// <summary>
        /// Creates default/empty (with only Match Id information) entry 
        /// for every per match data instance
        /// </summary>
        private void AddMatch(long matchId)
        {
            if (!References.Instance.MatchHeaders.ContainsKey(matchId))
            {
                References.Instance.MatchHeaders.Add(matchId, new MatchHeaderModel(matchId));
            }
            if (!References.Instance.MatchInfos.ContainsKey(matchId))
            {
                References.Instance.MatchInfos.Add(matchId, new MatchInfoModel(matchId));
            }
            if (!References.Instance.MatchOdds.ContainsKey(matchId))
            {
                References.Instance.MatchOdds.Add(matchId, new ImprovedObservableCollection<MatchOddsModel>());
            }
            if (!References.Instance.MatchScoreCardSummaries.ContainsKey(matchId))
            {
                References.Instance.MatchScoreCardSummaries.Add(matchId, new ScoreCardSummaryModel(matchId));
            }
            if (!References.Instance.LoadedMatchIds.Contains(matchId))
            {
                References.Instance.LoadedMatchIds.Add(matchId);
            }
            ImprovedObservableCollection<NotificationDisplayModel> notifications;
            if (!References.Instance.PerMatchNotifications.TryGetValue(matchId, out notifications))
            {
                notifications = new ImprovedObservableCollection<NotificationDisplayModel>();
                References.Instance.PerMatchNotifications.Add(matchId, notifications);
            }
        }


        private void RemoveMatch(long matchId)
        {
            if (References.Instance.LoadedMatchIds.Contains(matchId))
            {
                References.Instance.LoadedMatchIds.Remove(matchId);
            }
            if (References.Instance.MatchScoreCardSummaries.ContainsKey(matchId))
            {
                References.Instance.MatchScoreCardSummaries.Remove(matchId);
            }
            if (References.Instance.MatchOdds.ContainsKey(matchId))
            {
                References.Instance.MatchOdds.Remove(matchId);
            }
            if (References.Instance.MatchInfos.ContainsKey(matchId))
            {
                References.Instance.MatchInfos.Remove(matchId);
            }
            if (References.Instance.MatchHeaders.ContainsKey(matchId))
            {
                References.Instance.MatchHeaders.Remove(matchId);
            }
            References.Instance.PerMatchNotifications.Remove(matchId);
        }

        private bool CheckDispatcherThreadAccess()
        {
            return this._Dispatcher.CheckAccess();
        }

        private void InvokeInDispatcherThread(Action action)
        {
            this._Dispatcher.Invoke(action, DispatcherPriority.Normal);
        }

        private Timer _Read_Languages_Timer;

        public void PeriodicallyReadAvailableTranslations(string[] availableTranslations)
        {
            _Read_Languages_Timer = new Timer
            {
                AutoReset = true,
                Enabled = true,
                Interval = 2000
            };
            _Read_Languages_Timer.Elapsed += (sender, args) =>
                InvokeInDispatcherThread(() =>
                                             {
                                                 var languages = References.Instance.LanguagesHandler.AllLanguages;
                                                 languages.AddNewDeleteOldExcept(availableTranslations);
                                                 languages.Add("International");
                                             });
        }
        #endregion
    }

    public delegate void FiltersChanged();
}
