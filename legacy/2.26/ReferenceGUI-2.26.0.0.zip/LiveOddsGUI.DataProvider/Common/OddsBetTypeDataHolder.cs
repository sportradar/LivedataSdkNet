﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Sportradar.Demo.GUI.LiveOdds.DataProvider.Models;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using Merged::Sportradar.SDK.FeedProviders.LiveOdds.Common;

namespace Sportradar.Demo.GUI.LiveOdds.Common
{
    public class OddsBetTypeDataHolder
    {
        public OddsBetTypeDataHolder(MatchOddsModel matchOdds, OddsFieldValueModel oddsFieldValue)
        {
            OddsBetType = matchOdds.Type;
            OddsBetSubtype = matchOdds.SubType;
            if (oddsFieldValue != null)
            {
                OddsFieldType = oddsFieldValue.Type;
                HasOddsField = true;
            }

        }

        public EventOddsType OddsBetType { get; set; }

        public long? OddsBetSubtype { get; set; }

        public string OddsFieldType { get; set; }

        public bool HasOddsField { get; set; }
    }
}
