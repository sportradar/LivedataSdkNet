﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Common
{
    public class ImprovedObservableCollection<T> : ObservableCollection<T>, INotifyCollectionChanged
    {
        public ImprovedObservableCollection()
        {
        }
        public ImprovedObservableCollection(IEnumerable<T> items)
        {
            AddRange(items);
        }

        public void AddRange(IEnumerable<T> items)
        {
            BeginEdit();
            foreach (T item in items)
            {
                Add(item);
            }
            EndEdit();
        }

        public void AddNew(IEnumerable<T> items)
        {
            BeginEdit();
            foreach (T item in items)
            {
                if (!Contains(item))
                {
                    Add(item);
                }
            }
            EndEdit();
        }

        public void DeleteAllExcept(IEnumerable<T> items_to_keep)
        {
            BeginEdit();
            foreach (var contained_item in Items.ToList())
            {
                if (!items_to_keep.Contains(contained_item))
                {
                    Remove(contained_item);
                }
            }
            EndEdit();
        }

        public void AddNewDeleteOldExcept(IEnumerable<T> items_to_keep)
        {
            AddNew(items_to_keep);
            DeleteAllExcept(items_to_keep);
        }


        public bool IsEditing { get; private set; }

        public void BeginEdit()
        {
            if (!IsEditing)
                IsEditing = true;
        }

        public void EndEdit()
        {
            if (IsEditing)
            {
                IsEditing = false;
                OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
            }
        }

        protected override void OnCollectionChanged(NotifyCollectionChangedEventArgs e)
        {
            base.OnCollectionChanged(e);
            if (CollectionChanged != null && !IsEditing)
            {
                CollectionChanged(this, e);
            }
        }

        public new event NotifyCollectionChangedEventHandler CollectionChanged;

        event NotifyCollectionChangedEventHandler INotifyCollectionChanged.CollectionChanged
        {
            add { CollectionChanged += value; }
            remove { CollectionChanged -= value; }
        }
    } 
}
