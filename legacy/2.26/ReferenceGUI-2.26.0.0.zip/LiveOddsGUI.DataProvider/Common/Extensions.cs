﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Common
{
    /// <summary>
    /// Extension methods
    /// </summary>
    public static class Extensions
    {
        public static void InsertInOrder<T>(this ObservableCollection<T> collection, T item) where T : IComparable<T>
        {
            int index = Array.BinarySearch<T>(collection.ToArray(), item);

            if (index < 0)
            {
                collection.Insert(~index, item);
            }
            else
            {
                collection[index] = item;
            }
        }

        public static void Sort<T>(this ObservableCollection<T> collection) where T : IComparable<T>
        {
            List<T> lst = collection.ToList();

            lst.Sort();

            collection.Clear();
            foreach (var item in lst)
            {
                collection.Add(item);
            }
        }

        public static int CompareExt(this string value1, string value2)
        {
            if ((value1 == null) && (value2 == null))
            {
                return 0;
            }
            if (value2 == null)
            {
                return -1;
            }
            if (value1 == null)
            {
                return 1;
            }

            return string.Compare(value1, value2, true);
        }

        public static int CompareExt<T>(this Nullable<T> value1, Nullable<T> value2) where T : struct, IComparable<T>
        {
            if ((!value1.HasValue) && (!value2.HasValue))
            {
                return 0;
            }
            if (!value2.HasValue)
            {
                return -1;
            }
            if (!value1.HasValue)
            {
                return 1;
            }

            return value1.Value.CompareTo(value2.Value);
        }
    }
}
