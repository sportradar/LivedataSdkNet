/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Text;
using System.Windows.Data;


namespace Sportradar.Demo.GUI.LiveOdds.DataProvider.Common
{
    /// <summary>
    /// ImprovedObservableCollection containg list of checked items
    /// </summary>
    public class CheckableObservableCollection<T> : ImprovedObservableCollection<CheckWrapper<T>>
    {
        private ListCollectionView _selected;

        public CheckableObservableCollection()
        {
            _selected = new ListCollectionView(this);
            _selected.Filter = checkObject => ((CheckWrapper<T>) checkObject).IsChecked;
        }

        public void Add(T item)
        {
            this.Add(new CheckWrapper<T>(this) { Value = item });
        }

        public ListCollectionView CheckedItems
        {
            get { return _selected; }
        }

        internal void Refresh()
        {
            _selected.Refresh();
        }

    }


}
