﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using Sportradar.Demo.GUI.LiveScout.DataProvider;
using Sportradar.Demo.GUI.LiveScout.Code;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Common;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Models;
using System.Collections.Specialized;
using System.ComponentModel;

namespace Sportradar.Demo.GUI.LiveScout.Forms
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private readonly ConcurrentDictionary<long, Window> _OpenedMatchEventsWindows = new ConcurrentDictionary<long, Window>();
        private readonly ConcurrentDictionary<long, Window> _OpenedMatchOddsSuggestionsWindows = new ConcurrentDictionary<long, Window>();
        private readonly ConcurrentDictionary<long, Window> _OpenedMatchStatisticsWindows = new ConcurrentDictionary<long, Window>();
        private readonly ConcurrentDictionary<long, Window> _OpenedMatchInfoWindows = new ConcurrentDictionary<long, Window>();

        private readonly ListCollectionView _LoadedMatchesView = null;

        public MainWindow()
        {
            InitializeComponent();

            this._LoadedMatchesView = new ListCollectionView(
                new ObservableCollectionFromObservableCollection<MatchModel, long>(
                    this.LoadedMatchIds,
                    (matchModel) => (matchModel == null) ? long.MinValue : matchModel.MatchId,
                    (matchId) => 
                    {
                        MatchModel match;
                        if (References.Instance.Matches.TryGetValue(matchId, out match))
                        {
                            return match;
                        }

                        return null;
                    }));
            this._LoadedMatchesView.GroupDescriptions.Add(new PropertyGroupDescription("SportId"));

            this.DataContext = this;

            this.RefreshMatches(this, new RoutedEventArgs());

            References.Instance.ServerTimeModel.PropertyChanged += ServerTimeModelPropertyChanged;
        }

        private string SplitString(string p)
        {
            List<char> result = new List<char>();

            if (p != null)
            {
                foreach (var ch in p)
                {
                    if (char.IsUpper(ch))
                    {
                        result.Add(' ');
                    }
                    result.Add(ch);
                }
            }

            return (new string(result.ToArray())).Trim();
        }

        public DateTime? ServerTime
        {
            get { return References.Instance.ServerTimeModel.ServerTime; }
        }

        public DateTime? LocalTime
        {
            get { return References.Instance.ServerTimeModel.LocalTime; }
        }


        public GuiStrings GuiStrings { get { return GuiStrings.Instance; } }
        public ObservableCollection<long> SubscribedMatchIds { get { return References.Instance.SubscribedMatchIds; } }
        public ObservableCollection<long> LoadedMatchIds { get { return References.Instance.LoadedMatchIds; } }
        public ListCollectionView LoadedMatchesView { get { return this._LoadedMatchesView; } }
        public ObservableCollection<CollectedQueueStatsModel> DispatcherQueueStats { get { return References.Instance.DispatcherQueueStatsModel.Queues; } }

        private void RefreshMatches(object sender, RoutedEventArgs e)
        {
            try
            {
                // release GUI thread ASAP
                Task.Factory.StartNew(() => ChangeTracker.Instance.Refresh(true))
                    .ContinueWith((task) => task.Exception.InnerException.ShowError(), TaskContinuationOptions.OnlyOnFaulted);
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }

        private void SubscribeMatchCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if ((e.Parameter != null)
                    && (e.Parameter is long))
                {
                    long matchId = (long)e.Parameter;

                    // release GUI thread ASAP
                    Task.Factory.StartNew(() => ChangeTracker.Instance.SubscribeToMatch(matchId))
                        .ContinueWith((task) => task.Exception.InnerException.ShowError(), TaskContinuationOptions.OnlyOnFaulted);
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }

        private void UnsubscribeMatchCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if ((e.Parameter != null)
                    && (e.Parameter is long))
                {
                    long matchId = (long)e.Parameter;

                    this.CloseChildWindows(matchId);

                    // release GUI thread ASAP
                    Task.Factory.StartNew(() =>
                    {
                        ChangeTracker.Instance.UnsubscribeFromMatch(matchId);
                    })
                    .ContinueWith((task) => task.Exception.InnerException.ShowError(), TaskContinuationOptions.OnlyOnFaulted);
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }

        private void ViewMatchEventsWindowCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if ((e.Parameter != null)
                    && (e.Parameter is long))
                {
                    long matchId = (long)e.Parameter;

                    this.OpenChildWindow<MatchEventsWindow>(matchId, this._OpenedMatchEventsWindows);
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }

        private void ViewMatchInfoWindowCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if ((e.Parameter != null)
                    && (e.Parameter is long))
                {
                    long matchId = (long)e.Parameter;

                    this.OpenChildWindow<MatchInfoWindow>(matchId, this._OpenedMatchInfoWindows);
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }

        private void ViewMatchOddsSuggestionsWindowCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if ((e.Parameter != null)
                    && (e.Parameter is long))
                {
                    long matchId = (long)e.Parameter;

                    this.OpenChildWindow<MatchOddsSuggestionsWindow>(matchId, this._OpenedMatchOddsSuggestionsWindows);
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }

        private void ViewMatchStatisticsWindowCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if ((e.Parameter != null)
                    && (e.Parameter is long))
                {
                    long matchId = (long)e.Parameter;

                    this.OpenChildWindow<MatchStatisticsWindow>(matchId, this._OpenedMatchStatisticsWindows);
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }

        private void BookMatchCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if ((e.Parameter != null)
                    && (e.Parameter is long))
                {
                    long matchId = (long)e.Parameter;

                    // release GUI thread ASAP
                    Task.Factory.StartNew(() => ChangeTracker.Instance.BookMatch(matchId) )
                    .ContinueWith((task) => task.Exception.InnerException.ShowError(), TaskContinuationOptions.OnlyOnFaulted);
                }
            }
            catch (Exception exc)
            {
                exc.ShowError();
            }
        }

        private void OpenChildWindow<TChildWindow>(long matchId, ConcurrentDictionary<long, Window> childWindows) where TChildWindow : ChildWindowBase, new()
        {
            childWindows.AddOrUpdate(
                matchId,
                (matchIdParam) =>
                {
                    var childWindow = new TChildWindow();
                    childWindow.SetMatchId(matchId);
                    childWindow.SetChildWindows(childWindows);
                    childWindow.WindowState = this.WindowState;
                    childWindow.Show();

                    return childWindow;
                },
                (oldMatchIdParam, oldChildWindow) =>
                {
                    oldChildWindow.Activate();
                    return oldChildWindow;
                });
        }

        private void CloseChildWindows(long matchId)
        {
            Window window;
            if (this._OpenedMatchEventsWindows.TryRemove(matchId, out window))
            {
                window.Close();
            }
            if (this._OpenedMatchInfoWindows.TryRemove(matchId, out window))
            {
                window.Close();
            }
            if (this._OpenedMatchOddsSuggestionsWindows.TryRemove(matchId, out window))
            {
                window.Close();
            }
            if (this._OpenedMatchStatisticsWindows.TryRemove(matchId, out window))
            {
                window.Close();
            }
        }

        protected void OnPropertyChanged(params string[] propNames)
        {
            var propertyChanged = this.PropertyChanged;
            if (propertyChanged != null)
            {
                foreach (var propName in propNames)
                {
                    if (propName == null)
                    {
                        continue;
                    }

                    propertyChanged(this, new PropertyChangedEventArgs(propName));
                }
            }
        }

        private void ServerTimeModelPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if ((e != null) && ((e.PropertyName == "ServerTime") || (e.PropertyName == "LocalTime")))
            {
                this.OnPropertyChanged(e.PropertyName);
            }
        }

    }
}
