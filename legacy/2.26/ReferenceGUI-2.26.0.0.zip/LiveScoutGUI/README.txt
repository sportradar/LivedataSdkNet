﻿
This is the front-end project of LiveOdds GUI. 

Main form is MainWindow which contains match list and monitoring / statistics tabs. 

In "Matches" tab we display matches (including not booked) grouped by sport. 
By clicking the sport header line we can expand or collapse matches belonging to given sport. 
By clicking on match line more match properties are shown.

Every match line contains 6 buttons:
- Subscribe / Unsubscribe: available if match is booked. By clicking it we can subscribe (unsubscribe)
to (from) match. When subscribed, we receive events and more data for given match.

- Book: available if match is not booked. Match needs to be booked if we want to subscribe to it.

- Events: opens new window with match events. To receive events we must be subscribed to match otherwise
no event is shown in window (empty grid).

- Odds: opens new window with match odds suggestions. To receive odds suggestions we must be subscribed to
match otherwise no data is shown in window (empty grid).

- Stats: opens new window with graphical view of match stats. To receive stats we must be subscribed to
match otherwise no data is shown in window.

- Info: opens new window with match infos. These are app logs regarding given match (timestamp and message, eg.
Full feed received, etc).

In "Monitoring/Statistics" tab we display statistics for all dispatcher and error recovery queues.