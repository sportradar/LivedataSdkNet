﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace Sportradar.Demo.GUI.LiveScout.Code
{
    public class InverseBoolConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter,
            System.Globalization.CultureInfo culture)
        {
            bool result = true;

            if (value != null)
            {
                if (value is bool)
                {
                    result = (bool)value;
                }
                else if (value is bool?)
                {
                    result = (((bool?)value).HasValue && ((bool?)value).Value);
                }
            }

            return !result;
        }

        public object ConvertBack(object value, Type targetType, object parameter,
            System.Globalization.CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
