﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.FeedProviders.Common;
using System;
using System.Windows;
using System.Windows.Data;

namespace Sportradar.Demo.GUI.LiveScout.Code
{
    public class TeamSideToTextAlignmentConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if ((value != null) && (value is Team))
            {
                Team team = (Team)value;

                if (team == Team.AWAY)
                {
                    return TextAlignment.Right;
                }
                else if (team == Team.HOME)
                {
                    return TextAlignment.Left;
                }
            }

            return TextAlignment.Center;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
