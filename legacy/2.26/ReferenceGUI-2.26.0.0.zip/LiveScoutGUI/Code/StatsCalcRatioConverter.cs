﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.FeedProviders.Common;
using System;
using System.Windows.Data;

namespace Sportradar.Demo.GUI.LiveScout.Code
{
    public class StatsCalcRatioConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            double result = 0;

            try
            {
                if ((value != null) && (parameter != null))
                {
                    int param = System.Convert.ToInt32(parameter);

                    if ((param == 1) || (param == 2))
                    {
                        if (value is HomeAway<int>)
                        {
                            HomeAway<int> val = (HomeAway<int>)value;

                            if ((val.Team1 != 0) || (val.Team2 != 0))
                            {
                                double sum = val.Team1 + val.Team2;

                                if (param == 1)
                                {
                                    result = Math.Round(val.Team1 / sum, 4);
                                }
                                else
                                {
                                    result = Math.Round(val.Team2 / sum, 4);
                                }
                            }
                        }
                        else if (value is HomeAway<int?>)
                        {
                            HomeAway<int?> val = (HomeAway<int?>)value;

                            if ((val.Team1 != null && val.Team1 != 0) || (val.Team2 != null && val.Team2 != 0))
                            {
                                double sum = (val.Team1 ?? 0) + (val.Team2 ?? 0);

                                if (param == 1)
                                {
                                    result = Math.Round((val.Team1 ?? 0) / sum, 4);
                                }
                                else
                                {
                                    result = Math.Round((val.Team2 ?? 0) / sum, 4);
                                }
                            }
                        }
                    }
                }
            }
            catch
            {
            }

            return result;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
