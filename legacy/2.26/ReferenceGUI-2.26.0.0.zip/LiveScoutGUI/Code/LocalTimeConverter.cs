﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace Sportradar.Demo.GUI.LiveScout.Code
{
    public class LocalTimeConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value != null)
            {
                if (value is DateTime)
                {
                    if ((DateTime)value != DateTime.MinValue)
                    {
                        return ((DateTime)value).ToLocalTime().ToString("G", culture);
                    }
                }
                else if (value is DateTime? && ((DateTime?)value).HasValue)
                {
                    if (((DateTime?)value).Value != DateTime.MinValue)
                    {
                        return ((DateTime?)value).Value.ToLocalTime().ToString("G", culture);
                    }
                }
            }

            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
