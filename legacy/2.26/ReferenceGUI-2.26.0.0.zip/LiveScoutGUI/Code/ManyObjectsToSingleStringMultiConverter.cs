﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
extern alias Merged;
using Merged::Sportradar.SDK.Common;
using Merged::Sportradar.SDK.FeedProviders.Common;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Common;
using System;
using System.Windows.Data;

namespace Sportradar.Demo.GUI.LiveScout.Code
{
    public class ManyObjectsToSingleStringMultiConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            string result = string.Empty;

            if (values != null)
            {
                foreach (var value in values)
                {
                    if (value == null)
                    {
                        continue;
                    }

                    string stringValue = string.Empty;

                    if (value is LocalizedString)
                    {
                        LocalizedString localizedString = (LocalizedString)value;
                        stringValue = localizedString.GetTranslation(GuiStrings.Instance.CurrentLanguage);
                    }
                    else if (value is HomeAway<int>)
                    {
                        HomeAway<int> homeAwayStats = (HomeAway<int>)value;
                        stringValue = string.Format("{0} : {1}", homeAwayStats.Team1, homeAwayStats.Team2);
                    }
                    else
                    {
                        stringValue = value.ToString();
                    }

                    if (!string.IsNullOrWhiteSpace(stringValue))
                    {
                        result += (" " + stringValue.Trim());
                    }
                }
            }

            return result.Trim();
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
