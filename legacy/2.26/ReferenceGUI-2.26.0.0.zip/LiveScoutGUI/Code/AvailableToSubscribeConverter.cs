﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Models;
using Sportradar.Demo.GUI.LiveScout.DataProvider;

namespace Sportradar.Demo.GUI.LiveScout.Code
{
    public class AvailableToSubscribeConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if ((values != null) && (values.Length > 0) && (values[0] is long))
            {
                long matchId = (long)values[0];

                if (References.Instance.SubscribedMatchIds.Contains(matchId))
                {
                    return System.Windows.Visibility.Hidden;
                }
                else
                {
                    return System.Windows.Visibility.Visible;
                }
            }

            return System.Windows.Visibility.Collapsed;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
