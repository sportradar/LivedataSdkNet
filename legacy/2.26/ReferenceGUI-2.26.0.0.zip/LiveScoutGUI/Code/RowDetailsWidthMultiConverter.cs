﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using System.Windows;
using System.Windows.Controls;

namespace Sportradar.Demo.GUI.LiveScout.Code
{
    public class RowDetailsWidthMultiConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            double result = 0;

            if((values != null)
                && (values.Length > 2)
                && (values[0] is double)
                && (values[1] is DataGrid)
                && (values[2] is ScrollViewer))
            {
                DataGrid dataGrid = (DataGrid)values[1];
                ScrollViewer scrollViewer = (ScrollViewer)values[2];

                double columnsWidth = dataGrid.Columns.Sum(c => c.ActualWidth);
                double actualWidth = dataGrid.ActualWidth;
                if (scrollViewer.ComputedVerticalScrollBarVisibility == Visibility.Visible)
                {
                    actualWidth -= 35.0;
                }
                else
                {
                    actualWidth -= 20.0;
                }

                result = (actualWidth > columnsWidth) ? actualWidth : columnsWidth;
            }

            return result;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {
            return null;
        }
    }
}
