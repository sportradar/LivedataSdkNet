﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using Sportradar.Demo.GUI.LiveScout.DataProvider;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Common;

namespace Sportradar.Demo.GUI.LiveScout.Code
{
    public class SportIdToSportNameConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter,
            System.Globalization.CultureInfo culture)
        {
            string result = null;

            long id;
            if ((value != null)
                && long.TryParse(value.ToString(), out id))
            {
                var match = References.Instance.Matches.FirstOrDefault(m => m.Value.SportId == id);
                if (match.Value != null)
                {
                    var localizedString = match.Value.SportName;
                    if (localizedString != null)
                    {
                        result = localizedString.GetTranslation(GuiStrings.Instance.CurrentLanguage);
                    }
                }
            }

            return result;
        }

        public object ConvertBack(object value, Type targetType, object parameter,
            System.Globalization.CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
