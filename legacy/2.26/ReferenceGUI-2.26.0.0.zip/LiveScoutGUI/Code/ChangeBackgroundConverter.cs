﻿/***************************************************************   
 * Copyright (c) 2012, Sportradar AG                           *
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using Sportradar.Demo.GUI.LiveScout.DataProvider.Common;
using System.Windows;

namespace Sportradar.Demo.GUI.LiveScout.Code
{
    public class ChangeBackgroundConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            object result = null;

            object value = ((values != null && values.Length > 0) ? values[0] : null);
            if ((value != null)
                && (value is NotifyPropertyChanged))
            {
                if ((parameter != null)
                    && (parameter is string))
                {
                    if (((NotifyPropertyChanged)value).GetIsChanged((string)parameter))
                    {
                        result = Application.Current.Resources["LightCoral"];
                    }
                }
            }

            return result;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}